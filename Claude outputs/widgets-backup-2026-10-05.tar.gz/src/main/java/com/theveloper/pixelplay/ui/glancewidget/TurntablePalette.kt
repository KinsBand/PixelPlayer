package com.theveloper.pixelplay.ui.glancewidget

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import androidx.core.content.ContextCompat
import com.theveloper.pixelplay.data.model.PlayerInfo
import com.theveloper.pixelplay.data.preferences.WidgetAccentSource
import com.theveloper.pixelplay.data.preferences.WidgetAppearance

/**
 * The colours the drawn widgets (turntable, cassette, CD) use.
 *
 * Plain `Int` colours rather than Glance `ColorProvider`s, because most of them end up inside
 * a [android.graphics.Canvas]: a bitmap is already rasterised by the time the launcher decides
 * whether it is showing a light or dark home screen, so the day/night choice is made here, up
 * front, from the widget's own configuration.
 *
 * This deliberately holds only the *accent* side of the look — surfaces, bubbles, text. What
 * an object is made of (black vinyl, silver polycarbonate, cassette plastic) is decided by its
 * renderer and does not follow the album: a real record is black whatever is printed on its
 * label, and that is what makes the label read as the focal point.
 */
data class TurntablePalette(
    /** Behind the content when the background style is solid. */
    val surface: Int,
    val onSurface: Int,
    val onSurfaceVariant: Int,
    /** The play bubble, and anything that should carry the track's colour. */
    val accent: Int,
    val onAccent: Int,
    /** The favourite bubble and secondary controls. */
    val secondary: Int,
    val onSecondary: Int,
    /** An outline that reads on both the surface and the wallpaper. */
    val outline: Int,
    val night: Boolean,
) {
    // Names the widgets were written against.
    val playBadgeBackground: Int get() = accent
    val playBadgeIcon: Int get() = onAccent
    val favoriteBadgeBackground: Int get() = secondary
    val favoriteBadgeIcon: Int get() = onSecondary
    val title: Int get() = onSurface
    val artist: Int get() = onSurfaceVariant

    /** Label colour when a track has no artwork, and the glyph drawn on it. */
    val label: Int get() = accent
    val labelGlyph: Int get() = onAccent

    companion object {

        /**
         * The reference palette the turntable was designed around: a pale lavender play
         * bubble and a soft pink favourite bubble, on a deep indigo surface.
         */
        private const val REF_SURFACE = 0xFF1B0A33.toInt()
        private const val REF_ON_SURFACE = 0xFFEDE7FA.toInt()
        private const val REF_ON_SURFACE_VARIANT = 0xFFB9AEDA.toInt()
        private const val REF_PLAY_BG = 0xFFE4E4FB.toInt()
        private const val REF_PLAY_ICON = 0xFF3B49DF.toInt()
        private const val REF_FAV_BG = 0xFFFCDCE6.toInt()
        private const val REF_FAV_ICON = 0xFFB5297A.toInt()

        fun resolve(
            context: Context,
            appearance: WidgetAppearance,
            playerInfo: PlayerInfo,
        ): TurntablePalette {
            val night = isNightMode(context)
            return when (appearance.accentSource) {
                WidgetAccentSource.ALBUM_ART -> fromAlbumArt(playerInfo, night)
                WidgetAccentSource.MATERIAL_YOU -> fromSystem(context, night)
                WidgetAccentSource.FIXED -> fixed(appearance.fixedAccentColor, night)
            }
        }

        /**
         * A widget's own `Configuration` reflects the launcher's light/dark state, so this is
         * the one place the day/night decision can honestly be made for a rasterised image.
         */
        fun isNightMode(context: Context): Boolean =
            (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES

        private fun fromAlbumArt(playerInfo: PlayerInfo, night: Boolean): TurntablePalette {
            val theme = playerInfo.themeColors ?: return reference(night)
            val onSurface = if (night) theme.darkTitle else theme.lightTitle
            return TurntablePalette(
                surface = if (night) theme.darkSurfaceContainer else theme.lightSurfaceContainer,
                onSurface = onSurface,
                onSurfaceVariant = if (night) theme.darkArtist else theme.lightArtist,
                accent = if (night) theme.darkPlayPauseBackground else theme.lightPlayPauseBackground,
                onAccent = if (night) theme.darkPlayPauseIcon else theme.lightPlayPauseIcon,
                secondary = if (night) theme.darkPrevNextBackground else theme.lightPrevNextBackground,
                onSecondary = if (night) theme.darkPrevNextIcon else theme.lightPrevNextIcon,
                outline = onSurface,
                night = night,
            )
        }

        private fun fromSystem(context: Context, night: Boolean): TurntablePalette {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return reference(night)
            fun color(resId: Int) = ContextCompat.getColor(context, resId)

            val onSurface = color(
                if (night) android.R.color.system_neutral1_100 else android.R.color.system_neutral1_900,
            )
            return TurntablePalette(
                surface = color(
                    if (night) android.R.color.system_neutral1_900 else android.R.color.system_neutral1_50,
                ),
                onSurface = onSurface,
                onSurfaceVariant = color(
                    if (night) android.R.color.system_neutral2_200 else android.R.color.system_neutral2_700,
                ),
                accent = color(
                    if (night) android.R.color.system_accent1_200 else android.R.color.system_accent1_100,
                ),
                onAccent = color(android.R.color.system_accent1_800),
                secondary = color(
                    if (night) android.R.color.system_accent3_700 else android.R.color.system_accent3_100,
                ),
                onSecondary = color(
                    if (night) android.R.color.system_accent3_100 else android.R.color.system_accent3_800,
                ),
                outline = onSurface,
                night = night,
            )
        }

        /**
         * One colour the user picked. It is the surface, as on the other widgets; the bubbles
         * are pale tints of it so they read as the same family. Identical by day and night —
         * the point of choosing a fixed colour is that it does not change.
         */
        private fun fixed(color: Int, night: Boolean): TurntablePalette {
            val light = ColorMath.isLight(color)
            val onSurface = if (light) 0xFF15131A.toInt() else 0xFFF4F1FA.toInt()
            val tint = if (light) ColorMath.blend(color, 0xFF000000.toInt(), 0.72f)
            else ColorMath.blend(color, 0xFFFFFFFF.toInt(), 0.86f)
            val onTint = if (light) ColorMath.blend(color, 0xFFFFFFFF.toInt(), 0.2f)
            else ColorMath.blend(color, 0xFF000000.toInt(), 0.15f)
            return TurntablePalette(
                surface = color,
                onSurface = onSurface,
                onSurfaceVariant = ColorMath.withAlpha(onSurface, 0.72f),
                accent = tint,
                onAccent = onTint,
                secondary = ColorMath.blend(tint, 0xFFFCDCE6.toInt(), 0.35f),
                onSecondary = onTint,
                outline = onSurface,
                night = night,
            )
        }

        private fun reference(night: Boolean) = TurntablePalette(
            surface = REF_SURFACE,
            onSurface = REF_ON_SURFACE,
            onSurfaceVariant = REF_ON_SURFACE_VARIANT,
            accent = REF_PLAY_BG,
            onAccent = REF_PLAY_ICON,
            secondary = REF_FAV_BG,
            onSecondary = REF_FAV_ICON,
            outline = REF_ON_SURFACE_VARIANT,
            night = night,
        )
    }
}

/** Small colour helpers for code that works in packed ARGB `Int`s. */
internal object ColorMath {

    fun alpha(c: Int): Int = (c ushr 24) and 0xFF
    fun red(c: Int): Int = (c shr 16) and 0xFF
    fun green(c: Int): Int = (c shr 8) and 0xFF
    fun blue(c: Int): Int = c and 0xFF

    fun argb(a: Int, r: Int, g: Int, b: Int): Int =
        (a.coerceIn(0, 255) shl 24) or (r.coerceIn(0, 255) shl 16) or
            (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    /** [color] with its alpha replaced by [fraction] of opaque. */
    fun withAlpha(color: Int, fraction: Float): Int =
        ((fraction.coerceIn(0f, 1f) * 255f).toInt() shl 24) or (color and 0x00FFFFFF)

    /** Linear blend of two opaque colours; [t] = 0 gives [from], 1 gives [to]. */
    fun blend(from: Int, to: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        fun mix(a: Int, b: Int) = (a + (b - a) * k).toInt()
        return argb(
            mix(alpha(from), alpha(to)),
            mix(red(from), red(to)),
            mix(green(from), green(to)),
            mix(blue(from), blue(to)),
        )
    }

    /** Perceived luminance in 0..1 (Rec. 601 weights, which is plenty for a light/dark call). */
    fun luminance(color: Int): Float =
        (0.299f * red(color) + 0.587f * green(color) + 0.114f * blue(color)) / 255f

    fun isLight(color: Int): Boolean = luminance(color) > 0.55f

    /** Same hue and saturation, with lightness pushed to [targetLuminance]. */
    fun atLuminance(color: Int, targetLuminance: Float): Int {
        val current = luminance(color)
        return if (current < targetLuminance) {
            val t = if (current >= 1f) 0f else (targetLuminance - current) / (1f - current)
            blend(color or 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), t)
        } else {
            val t = if (current <= 0f) 0f else 1f - targetLuminance / current
            blend(color or 0xFF000000.toInt(), 0xFF000000.toInt(), t)
        }
    }
}
