package com.theveloper.pixelplay.presentation.screens.settings

import android.graphics.Bitmap
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.theveloper.pixelplay.R
import com.theveloper.pixelplay.data.model.PlayerInfo
import com.theveloper.pixelplay.data.preferences.CassetteLabel
import com.theveloper.pixelplay.data.preferences.CassetteShell
import com.theveloper.pixelplay.data.preferences.DiscPresentation
import com.theveloper.pixelplay.data.preferences.SpinSettings
import com.theveloper.pixelplay.data.preferences.WidgetAccentSource
import com.theveloper.pixelplay.data.preferences.WidgetAppearance
import com.theveloper.pixelplay.data.preferences.WidgetBackgroundStyle
import com.theveloper.pixelplay.data.preferences.WidgetConfig
import com.theveloper.pixelplay.data.preferences.WidgetKind
import com.theveloper.pixelplay.data.preferences.WidgetProgressStyle
import com.theveloper.pixelplay.data.preferences.WidgetSpinMode
import com.theveloper.pixelplay.ui.glancewidget.CassetteWidget
import com.theveloper.pixelplay.ui.glancewidget.DiscRenderer
import com.theveloper.pixelplay.ui.glancewidget.TurntablePalette
import com.theveloper.pixelplay.ui.glancewidget.TurntableRenderer
import com.theveloper.pixelplay.ui.glancewidget.WidgetLayoutMath
import com.theveloper.pixelplay.ui.glancewidget.WidgetLayoutMath.TransportSlot
import com.theveloper.pixelplay.ui.glancewidget.artworkKey
import com.theveloper.pixelplay.ui.glancewidget.resolveTurntableArtwork
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Live previews for the Visual Widgets screen.
 *
 * The turntable and CD previews are not mock-ups: they ask the widgets' own renderers for the
 * exact layers the home screen shows, and only the rotation is done differently — Compose can
 * animate, so the turning layer spins under a `graphicsLayer` instead of being re-rasterised.
 * The cassette preview stacks the widget's own vector layers.
 *
 * The other widgets are Compose approximations (Glance layouts cannot be hosted in an app),
 * but they now honour everything the settings page offers — accent colours, every control,
 * favourite, progress, and the grid's caption and heart — so a switch that changes the widget
 * visibly changes the preview too, and the other way round.
 */

/** Cell proportions each widget is previewed at, in home-screen cells. */
private val PREVIEW_CELLS: Map<WidgetKind, Pair<Int, Int>> = mapOf(
    WidgetKind.ADAPTIVE to (4 to 2),
    WidgetKind.BAR_4X1 to (4 to 1),
    WidgetKind.CONTROL_4X2 to (4 to 2),
    WidgetKind.GRID_2X2 to (2 to 2),
    WidgetKind.TURNTABLE to (2 to 2),
    WidgetKind.CASSETTE to (4 to 2),
    WidgetKind.DISC to (2 to 2),
)

/** One home-screen cell, at preview scale. */
private val PREVIEW_CELL = 42.dp

/**
 * A horizontally scrolling strip of every widget, with the selected one outlined. Doubles as
 * the picker.
 */
@Composable
internal fun WidgetPreviewStrip(
    configs: Map<WidgetKind, WidgetConfig>,
    playerInfo: PlayerInfo,
    selectedKind: WidgetKind,
    onSelect: (WidgetKind) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 4.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            WidgetKind.entries.forEach { kind ->
                val (cw, ch) = PREVIEW_CELLS.getValue(kind)
                WidgetPreviewCard(
                    kind = kind,
                    config = configs[kind] ?: WidgetConfig(kind = kind),
                    playerInfo = playerInfo,
                    width = PREVIEW_CELL * cw,
                    height = PREVIEW_CELL * ch,
                    selected = kind == selectedKind,
                    onClick = { onSelect(kind) },
                )
            }
        }
        Text(
            text = stringResource(R.string.settings_widgets_preview_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
    }
}

/**
 * The selected widget, large, on a wallpaper-like stage: the fixed top of the Widgets page.
 * The stage is always two cells tall so switching widgets never moves what's below it.
 */
@Composable
internal fun WidgetMainPreview(
    kind: WidgetKind,
    config: WidgetConfig,
    playerInfo: PlayerInfo,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
        val cell = minOf((maxWidth - 48.dp) / 4, 68.dp)
        Surface(
            shape = RoundedCornerShape(28.dp),
            // Stands in for a wallpaper, so transparent backgrounds are visibly transparent.
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.fillMaxWidth().height(cell * 2 + 40.dp),
        ) {
            Box(contentAlignment = Alignment.Center) {
                androidx.compose.animation.AnimatedContent(
                    targetState = kind,
                    label = "widgetMainPreview",
                ) { shown ->
                    val (w, h) = PREVIEW_CELLS.getValue(shown)
                    Box(Modifier.width(cell * w).height(cell * h), contentAlignment = Alignment.Center) {
                        WidgetPreview(
                            kind = shown,
                            config = if (shown == kind) config else WidgetConfig(kind = shown),
                            playerInfo = playerInfo,
                        )
                    }
                }
            }
        }
    }
}

/** A fixed row of widget names under the main preview: picks which widget is being edited. */
@Composable
internal fun WidgetKindSelector(
    selectedKind: WidgetKind,
    onSelect: (WidgetKind) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        WidgetKind.entries.forEach { kind ->
            val selected = kind == selectedKind
            Surface(
                onClick = { onSelect(kind) },
                shape = CircleShape,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh,
                contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
            ) {
                Text(
                    text = stringResource(kind.labelRes),
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
                )
            }
        }
    }
}

@Composable
private fun WidgetPreviewCard(
    kind: WidgetKind,
    config: WidgetConfig,
    playerInfo: PlayerInfo,
    width: Dp,
    height: Dp,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val border = if (selected) {
        BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
    } else {
        BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            border = border,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .clickable(onClick = onClick),
        ) {
            Box(
                modifier = Modifier.padding(12.dp).width(width).height(height),
                contentAlignment = Alignment.Center,
            ) {
                WidgetPreview(kind = kind, config = config, playerInfo = playerInfo)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = stringResource(kind.labelRes),
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.width(width),
        )
    }
}

@Composable
private fun WidgetPreview(kind: WidgetKind, config: WidgetConfig, playerInfo: PlayerInfo) {
    when (kind) {
        WidgetKind.TURNTABLE -> VinylPreview(config, playerInfo)
        WidgetKind.DISC -> DiscPreview(config, playerInfo)
        WidgetKind.CASSETTE -> CassettePreview(config, playerInfo)
        else -> ContentWidgetPreview(kind, config, playerInfo)
    }
}

// -------------------------------------------------------------------------------------
// Shared: the widget's background, and its colours
// -------------------------------------------------------------------------------------

/** Solid, transparent or outlined, with the chosen radius — as `widgetSurface` draws it. */
@Composable
private fun Modifier.previewSurface(appearance: WidgetAppearance, colors: PreviewColors, radius: Dp? = null): Modifier {
    val shape = RoundedCornerShape(radius ?: appearance.cornerRadiusDp.dp)
    return when (appearance.backgroundStyle) {
        WidgetBackgroundStyle.SOLID -> this.clip(shape).background(colors.surface)
        WidgetBackgroundStyle.TRANSPARENT -> this
        WidgetBackgroundStyle.OUTLINED -> this.border(1.dp, colors.onSurface.copy(alpha = 0.7f), shape)
    }
}

/** The colours a widget resolves for its accent source, as plain Compose colours. */
private data class PreviewColors(
    val surface: Color,
    val onSurface: Color,
    val onSurfaceVariant: Color,
    val play: Color,
    val onPlay: Color,
    val button: Color,
    val onButton: Color,
)

@Composable
private fun previewColors(appearance: WidgetAppearance, playerInfo: PlayerInfo): PreviewColors {
    val dark = isSystemInDarkTheme()
    val scheme = MaterialTheme.colorScheme
    val theme = playerInfo.themeColors
    return when {
        appearance.accentSource == WidgetAccentSource.FIXED -> {
            val surface = Color(appearance.fixedAccentColor)
            val light = surface.red * 0.299f + surface.green * 0.587f + surface.blue * 0.114f > 0.5f
            val on = if (light) Color(0xFF12121A) else Color(0xFFF2EFFA)
            val container = Color(
                red = surface.red + (on.red - surface.red) * 0.16f,
                green = surface.green + (on.green - surface.green) * 0.16f,
                blue = surface.blue + (on.blue - surface.blue) * 0.16f,
            )
            PreviewColors(surface, on, on.copy(alpha = 0.7f), on, surface, container, on)
        }
        appearance.accentSource == WidgetAccentSource.ALBUM_ART && theme != null -> PreviewColors(
            surface = Color(if (dark) theme.darkSurfaceContainer else theme.lightSurfaceContainer),
            onSurface = Color(if (dark) theme.darkTitle else theme.lightTitle),
            onSurfaceVariant = Color(if (dark) theme.darkArtist else theme.lightArtist),
            play = Color(if (dark) theme.darkPlayPauseBackground else theme.lightPlayPauseBackground),
            onPlay = Color(if (dark) theme.darkPlayPauseIcon else theme.lightPlayPauseIcon),
            button = Color(if (dark) theme.darkPrevNextBackground else theme.lightPrevNextBackground),
            onButton = Color(if (dark) theme.darkPrevNextIcon else theme.lightPrevNextIcon),
        )
        else -> PreviewColors(
            surface = scheme.surfaceContainer,
            onSurface = scheme.onSurface,
            onSurfaceVariant = scheme.onSurfaceVariant,
            play = scheme.primaryContainer,
            onPlay = scheme.onPrimaryContainer,
            button = scheme.secondaryContainer,
            onButton = scheme.onSecondaryContainer,
        )
    }
}

/** The current artwork, as a bitmap, or `null`. */
@Composable
private fun rememberArtwork(playerInfo: PlayerInfo, px: Int): Bitmap? {
    val context = LocalContext.current
    val key = artworkKey(playerInfo)
    return remember(key, px) { resolveTurntableArtwork(context, playerInfo, px) }
}

// -------------------------------------------------------------------------------------
// Turntable and CD
// -------------------------------------------------------------------------------------

/**
 * The turning layer's angle, as a lambda read inside a `graphicsLayer` so a spinning preview
 * costs a layer update per frame, not a recomposition. Constant when not turning, which also
 * avoids leaving an infinite animation running behind a still disc.
 */
@Composable
private fun rememberSpinAngle(spin: SpinSettings): () -> Float {
    if (spin.mode == WidgetSpinMode.OFF) return { 0f }
    val transition = rememberInfiniteTransition(label = "spin")
    val turnMillis = (60_000f / spin.rpm.coerceAtLeast(0.5f)).toInt().coerceAtLeast(500)
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = if (spin.clockwise) 360f else -360f,
        animationSpec = infiniteRepeatable(tween(turnMillis, easing = LinearEasing), RepeatMode.Restart),
        label = "spinAngle",
    )
    return { angle }
}

@Composable
private fun VinylPreview(config: WidgetConfig, playerInfo: PlayerInfo) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val options = config.turntable
    val palette = remember(config.appearance, playerInfo.themeColors, context) {
        TurntablePalette.resolve(context, config.appearance, playerInfo)
    }
    StageBox(config, playerInfo) { stage ->
        val stagePx = with(density) { stage.toPx() }.toInt().coerceIn(48, TurntableRenderer.MAX_RENDER_PX)
        val placement = WidgetLayoutMath.vinylPlacement(options.discScale, options.showTonearm)
        val spec = remember(stagePx, options, palette, playerInfo.songTitle, artworkKey(playerInfo)) {
            TurntableRenderer.VinylSpec(
                sizePx = stagePx,
                placement = placement,
                style = options.style,
                labelFraction = options.labelScale,
                showGrooves = options.showGrooves,
                showSheen = options.showSheen,
                showTonearm = options.showTonearm,
                accent = palette.accent,
                onAccent = palette.onAccent,
                artworkKey = artworkKey(playerInfo),
                title = playerInfo.songTitle,
            )
        }
        val art = rememberArtwork(playerInfo, (spec.radiusPx * 2f).toInt())
        val base = remember(spec, art) { TurntableRenderer.renderBase(spec) { TurntableRenderer.prepareArtwork(art, (spec.radiusPx * 2).toInt()) } }
        val under = remember(spec) { TurntableRenderer.renderUnderlay(spec) }
        val progress = WidgetLayoutMath.progress(playerInfo.currentPositionMs, playerInfo.totalDurationMs)
        // The preview always turns, so it shows the arm in play rather than at rest.
        val over = remember(spec, (progress * 100).toInt()) { TurntableRenderer.renderOverlay(spec, progress, isPlaying = true) }
        SpinLayers(stage, placement, under, base, over, rememberSpinAngle(options.spin))
        PreviewBubbles(
            stage = stage,
            placement = placement,
            favouriteAngle = if (options.showTonearm) -135f else -45f,
            showPlay = options.showBadges,
            showFavourite = config.effectiveContent.showFavorite,
            palette = palette,
            isPlaying = playerInfo.isPlaying,
            isFavorite = playerInfo.isFavorite,
        )
    }
}

@Composable
private fun DiscPreview(config: WidgetConfig, playerInfo: PlayerInfo) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val options = config.disc
    val palette = remember(config.appearance, playerInfo.themeColors, context) {
        TurntablePalette.resolve(context, config.appearance, playerInfo)
    }
    StageBox(config, playerInfo) { stage ->
        val stagePx = with(density) { stage.toPx() }.toInt().coerceIn(48, DiscRenderer.MAX_RENDER_PX)
        val spec = remember(stagePx, options, palette, playerInfo.songTitle, artworkKey(playerInfo)) {
            DiscRenderer.DiscSpec(
                sizePx = stagePx,
                face = options.face,
                presentation = options.presentation,
                discScale = options.discScale,
                accent = palette.accent,
                artworkKey = artworkKey(playerInfo),
                title = playerInfo.songTitle,
            )
        }
        val art = rememberArtwork(playerInfo, (spec.radiusPx * 2f).toInt())
        val progress = WidgetLayoutMath.progress(playerInfo.currentPositionMs, playerInfo.totalDurationMs)
        val artProvider = { TurntableRenderer.prepareArtwork(art, (spec.radiusPx * 2).toInt()) }
        val base = remember(spec, art, (progress * 100).toInt()) { DiscRenderer.renderBase(spec, progress, artProvider) }
        val under = remember(spec) { DiscRenderer.renderUnderlay(spec) }
        val over = remember(spec, art) { DiscRenderer.renderOverlay(spec, artProvider) }
        SpinLayers(stage, spec.placement, under, base, over, rememberSpinAngle(options.spin))
        when (options.presentation) {
            DiscPresentation.DISC -> PreviewBubbles(
                stage, spec.placement, -45f, options.showBadges, config.effectiveContent.showFavorite,
                palette, playerInfo.isPlaying, playerInfo.isFavorite,
            )
            DiscPresentation.JEWEL_CASE -> CornerBubbles(
                stage, 0.85f to 0.85f, 0.14f to 0.14f, 0.62f,
                options.showBadges, config.effectiveContent.showFavorite, palette, playerInfo,
            )
            DiscPresentation.PORTABLE -> CornerBubbles(
                stage, 0.87f to 0.87f, 0.88f to 0.12f, 0.6f,
                options.showBadges, config.effectiveContent.showFavorite, palette, playerInfo,
            )
        }
    }
}

/** A square stage in the middle of the preview cell, with the widget's background behind it. */
@Composable
private fun StageBox(config: WidgetConfig, playerInfo: PlayerInfo, content: @Composable (stage: Dp) -> Unit) {
    val colors = previewColors(config.appearance, playerInfo)
    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().previewSurface(config.appearance, colors),
        contentAlignment = Alignment.Center,
    ) {
        val stage = minOf(maxWidth, maxHeight)
        Box(modifier = Modifier.size(stage)) { content(stage) }
    }
}

/** Underlay, turning base and overlay, stacked exactly as the widget composites them. */
@Composable
private fun SpinLayers(
    stage: Dp,
    placement: WidgetLayoutMath.DiscPlacement,
    under: Bitmap?,
    base: Bitmap?,
    over: Bitmap?,
    angle: () -> Float,
) {
    under?.let {
        Image(it.asImageBitmap(), null, Modifier.size(stage), contentScale = ContentScale.FillBounds)
    }
    if (base != null) {
        val d = stage * placement.radius * 2f
        Image(
            bitmap = base.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier
                .offset(x = stage * placement.centreX - d / 2, y = stage * placement.centreY - d / 2)
                .size(d)
                .graphicsLayer { rotationZ = angle() },
        )
    }
    over?.let {
        Image(it.asImageBitmap(), null, Modifier.size(stage), contentScale = ContentScale.FillBounds)
    }
}

@Composable
private fun PreviewBubbles(
    stage: Dp,
    placement: WidgetLayoutMath.DiscPlacement,
    favouriteAngle: Float,
    showPlay: Boolean,
    showFavourite: Boolean,
    palette: TurntablePalette,
    isPlaying: Boolean,
    isFavorite: Boolean,
) {
    val disc = placement.radius * 2f
    val play = WidgetLayoutMath.badgeCentre(placement, 1f, 135f)
    val fav = WidgetLayoutMath.badgeCentre(placement, 1f, favouriteAngle)
    Bubbles(stage, play, fav, disc, showPlay, showFavourite, palette, isPlaying, isFavorite)
}

@Composable
private fun CornerBubbles(
    stage: Dp,
    play: Pair<Float, Float>,
    favourite: Pair<Float, Float>,
    discFraction: Float,
    showPlay: Boolean,
    showFavourite: Boolean,
    palette: TurntablePalette,
    playerInfo: PlayerInfo,
) = Bubbles(stage, play, favourite, discFraction, showPlay, showFavourite, palette, playerInfo.isPlaying, playerInfo.isFavorite)

@Composable
private fun Bubbles(
    stage: Dp,
    play: Pair<Float, Float>,
    favourite: Pair<Float, Float>,
    discFraction: Float,
    showPlay: Boolean,
    showFavourite: Boolean,
    palette: TurntablePalette,
    isPlaying: Boolean,
    isFavorite: Boolean,
) {
    if (showFavourite) {
        val d = max(12f, stage.value * discFraction * 0.26f).dp
        PreviewBadge(
            modifier = Modifier.offset(x = stage * favourite.first - d / 2, y = stage * favourite.second - d / 2),
            size = d,
            shape = CircleShape,
            background = Color(palette.favoriteBadgeBackground),
        ) {
            Icon(
                if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                contentDescription = null,
                tint = Color(palette.favoriteBadgeIcon),
                modifier = Modifier.size(d * 0.52f),
            )
        }
    }
    if (showPlay) {
        val d = max(14f, stage.value * discFraction * 0.32f).dp
        PreviewBadge(
            modifier = Modifier.offset(x = stage * play.first - d / 2, y = stage * play.second - d / 2),
            size = d,
            shape = RoundedCornerShape(d * 0.3f),
            background = Color(palette.playBadgeBackground),
        ) {
            Icon(
                if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = null,
                tint = Color(palette.playBadgeIcon),
                modifier = Modifier.size(d * 0.5f),
            )
        }
    }
}

@Composable
private fun PreviewBadge(
    modifier: Modifier,
    size: Dp,
    shape: androidx.compose.ui.graphics.Shape,
    background: Color,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = modifier.size(size).clip(shape).background(background),
        contentAlignment = Alignment.Center,
    ) { content() }
}

// -------------------------------------------------------------------------------------
// Cassette
// -------------------------------------------------------------------------------------

@Composable
private fun CassettePreview(config: WidgetConfig, playerInfo: PlayerInfo) {
    val context = LocalContext.current
    val options = config.cassette
    val content = config.effectiveContent
    val colors = previewColors(config.appearance, playerInfo)
    val palette = remember(config.appearance, playerInfo.themeColors, context) {
        TurntablePalette.resolve(context, config.appearance, playerInfo)
    }
    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().previewSurface(config.appearance, colors),
        contentAlignment = Alignment.Center,
    ) {
        val w = minOf(maxWidth, maxHeight * CassetteWidget.ASPECT)
        val h = w / CassetteWidget.ASPECT
        val shell = when (options.shell) {
            CassetteShell.BLACK -> Color(0xFF1B1B1E)
            CassetteShell.SMOKE -> Color(0xB8282A30)
            CassetteShell.WHITE -> Color(0xFFECE9E2)
            CassetteShell.ACCENT -> Color(com.theveloper.pixelplay.ui.glancewidget.ColorMath.atLuminance(palette.accent, 0.42f))
        }
        val progress = WidgetLayoutMath.progress(playerInfo.currentPositionMs, playerInfo.totalDurationMs)
            .takeIf { playerInfo.totalDurationMs > 0 } ?: 0.35f
        val (supply, takeUp) = WidgetLayoutMath.tapePackRadii(
            progress, (w * CassetteWidget.EMPTY_PACK).value, (h * CassetteWidget.FULL_PACK).value,
        )
        val hub = w * CassetteWidget.HUB_RADIUS * 2f
        val reelY = h * CassetteWidget.REEL_Y
        val leftX = w * (0.5f - CassetteWidget.REEL_SPACING / 2f)
        val rightX = w * (0.5f + CassetteWidget.REEL_SPACING / 2f)
        val turning = options.spinReels
        val leftAngle = rememberReelAngle(turning, 1.3f * supply / (w * CassetteWidget.EMPTY_PACK).value)
        val rightAngle = rememberReelAngle(turning, 1.3f * takeUp / (w * CassetteWidget.EMPTY_PACK).value)

        Box(modifier = Modifier.size(w, h)) {
            Layer(R.drawable.widget_cassette_shell, shell)
            Layer(R.drawable.widget_cassette_details)
            when (options.label) {
                CassetteLabel.PAPER -> {
                    Layer(R.drawable.widget_cassette_label_paper)
                    Layer(
                        R.drawable.widget_cassette_label_stripe,
                        Color(com.theveloper.pixelplay.ui.glancewidget.ColorMath.atLuminance(palette.accent, 0.5f)),
                    )
                }
                CassetteLabel.ART -> {
                    val art = rememberArtwork(playerInfo, 256)
                    Box(
                        modifier = Modifier
                            .offset(x = w * CassetteWidget.LABEL_X, y = h * CassetteWidget.LABEL_Y)
                            .size(w * CassetteWidget.LABEL_W, h * CassetteWidget.LABEL_H)
                            .clip(RoundedCornerShape(w * 0.018f))
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        art?.let {
                            Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        }
                    }
                    Layer(R.drawable.widget_cassette_label_strip)
                }
                CassetteLabel.NONE -> Unit
            }
            Layer(R.drawable.widget_cassette_window)
            Pack(leftX, reelY, supply.dp)
            Pack(rightX, reelY, takeUp.dp)
            Hub(leftX, reelY, hub, leftAngle)
            Hub(rightX, reelY, hub, rightAngle)
            Layer(R.drawable.widget_cassette_glass)
            if (content.showTitle || content.showArtist) {
                val ink = when {
                    options.label != CassetteLabel.NONE -> Color(CassetteWidget.INK)
                    options.shell == CassetteShell.WHITE -> Color(0xFF1A1A1E)
                    else -> Color.White
                }
                Column(modifier = Modifier.offset(x = w * 0.17f, y = h * 0.095f)) {
                    if (content.showTitle) {
                        Text(
                            playerInfo.songTitle.ifEmpty { stringResource(R.string.widget_preview_song_title) },
                            color = ink, fontFamily = FontFamily.Cursive, maxLines = 1,
                            fontSize = (h.value * 0.085f).coerceIn(6f, 22f).sp,
                        )
                    }
                    if (content.showArtist) {
                        Text(
                            playerInfo.artistName.ifEmpty { stringResource(R.string.widget_preview_artist) },
                            color = ink.copy(alpha = 0.78f), fontFamily = FontFamily.Cursive, maxLines = 1,
                            fontSize = (h.value * 0.056f).coerceIn(5f, 15f).sp,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Layer(res: Int, tint: Color? = null) {
    Image(
        painter = painterResource(res),
        contentDescription = null,
        contentScale = ContentScale.FillBounds,
        colorFilter = tint?.let { ColorFilter.tint(it) },
        modifier = Modifier.fillMaxSize(),
    )
}

@Composable
private fun Pack(cx: Dp, cy: Dp, r: Dp) {
    Image(
        painter = painterResource(R.drawable.widget_cassette_tape),
        contentDescription = null,
        modifier = Modifier.offset(x = cx - r, y = cy - r).size(r * 2f),
    )
}

@Composable
private fun Hub(cx: Dp, cy: Dp, d: Dp, angle: () -> Float) {
    Image(
        painter = painterResource(R.drawable.widget_cassette_hub),
        contentDescription = null,
        modifier = Modifier
            .offset(x = cx - d / 2, y = cy - d / 2)
            .size(d)
            .graphicsLayer { rotationZ = angle() },
    )
}

/** An anticlockwise reel turn taking [periodSeconds] a revolution, as the widget's reels do. */
@Composable
private fun rememberReelAngle(turning: Boolean, periodSeconds: Float): () -> Float {
    if (!turning) return { 0f }
    val transition = rememberInfiniteTransition(label = "reel")
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = -360f,
        animationSpec = infiniteRepeatable(tween((periodSeconds * 1000).toInt().coerceAtLeast(300), easing = LinearEasing)),
        label = "reelAngle",
    )
    return { angle }
}

// -------------------------------------------------------------------------------------
// The content widgets
// -------------------------------------------------------------------------------------

@Composable
private fun ContentWidgetPreview(kind: WidgetKind, config: WidgetConfig, playerInfo: PlayerInfo) {
    val appearance = config.appearance
    val content = config.effectiveContent
    val colors = previewColors(appearance, playerInfo)
    val radius = if (kind == WidgetKind.ADAPTIVE) 20.dp else appearance.cornerRadiusDp.dp * 0.6f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .previewSurface(appearance, colors, radius)
            .padding(8.dp),
    ) {
        if (kind == WidgetKind.GRID_2X2) {
            GridPreview(content, colors, playerInfo)
            return@Box
        }
        val compact = kind == WidgetKind.BAR_4X1
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
            Row(
                modifier = Modifier.fillMaxWidth().then(if (compact) Modifier.weight(1f) else Modifier),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                ArtworkTile(playerInfo, Modifier.size(if (compact) 24.dp else 36.dp))
                Column(modifier = Modifier.weight(1f)) {
                    PreviewText(content, colors, playerInfo)
                }
                // The bar keeps every control in its one row; the others put the heart here.
                if (!compact && content.showFavorite) {
                    Icon(
                        if (playerInfo.isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        null, tint = colors.onSurface, modifier = Modifier.size(14.dp),
                    )
                }
                if (compact) {
                    ControlsPreview(
                        WidgetLayoutMath.planTransport(content.showPrevNext, content.showShuffle, content.showRepeat, content.showFavorite, 6),
                        colors, playerInfo, 20.dp,
                    )
                }
            }
            if (!compact) {
                ProgressPreview(content.progressStyle, colors, playerInfo)
                Spacer(Modifier.height(6.dp))
                ControlsPreview(
                    WidgetLayoutMath.planTransport(content.showPrevNext, content.showShuffle, content.showRepeat, false, 6),
                    colors, playerInfo, 24.dp, fill = true,
                )
            } else {
                ProgressPreview(content.progressStyle, colors, playerInfo)
            }
        }
    }
}

@Composable
private fun GridPreview(content: com.theveloper.pixelplay.data.preferences.WidgetContentOptions, colors: PreviewColors, playerInfo: PlayerInfo) {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                ArtworkTile(playerInfo, Modifier.fillMaxSize())
                if (content.showTitle || content.showArtist) {
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(2.dp)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0x8C000000))
                            .padding(horizontal = 3.dp, vertical = 1.dp),
                    ) {
                        if (content.showTitle) Text(playerInfo.songTitle.ifEmpty { stringResource(R.string.widget_preview_song_title) }, color = Color.White, fontSize = 7.sp, maxLines = 1)
                        if (content.showArtist) Text(playerInfo.artistName.ifEmpty { stringResource(R.string.widget_preview_artist) }, color = Color.White.copy(alpha = 0.85f), fontSize = 6.sp, maxLines = 1)
                    }
                }
                if (content.showFavorite) {
                    Box(
                        modifier = Modifier.align(Alignment.TopEnd).padding(2.dp).size(12.dp).clip(CircleShape).background(colors.button),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(if (playerInfo.isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = colors.onButton, modifier = Modifier.size(8.dp))
                    }
                }
            }
            TransportTile(Modifier.weight(1f).fillMaxSize(), if (playerInfo.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, colors.play, colors.onPlay)
        }
        if (content.showPrevNext) {
            Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TransportTile(Modifier.weight(1f).fillMaxSize(), Icons.Rounded.SkipPrevious, colors.button, colors.onButton)
                TransportTile(Modifier.weight(1f).fillMaxSize(), Icons.Rounded.SkipNext, colors.button, colors.onButton)
            }
        }
        ProgressPreview(content.progressStyle, colors, playerInfo)
    }
}

@Composable
private fun PreviewText(content: com.theveloper.pixelplay.data.preferences.WidgetContentOptions, colors: PreviewColors, playerInfo: PlayerInfo) {
    if (content.showTitle) {
        Text(
            text = playerInfo.songTitle.ifEmpty { stringResource(R.string.widget_preview_song_title) },
            style = MaterialTheme.typography.labelMedium,
            color = colors.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
    if (content.showArtist) {
        Text(
            text = playerInfo.artistName.ifEmpty { stringResource(R.string.widget_preview_artist) },
            style = MaterialTheme.typography.labelSmall,
            color = colors.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun ControlsPreview(slots: List<TransportSlot>, colors: PreviewColors, playerInfo: PlayerInfo, size: Dp, fill: Boolean = false) {
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = if (fill) Modifier.fillMaxWidth() else Modifier) {
        slots.forEach { slot ->
            val (icon, bg, fg) = when (slot) {
                TransportSlot.PLAY -> Triple(if (playerInfo.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, colors.play, colors.onPlay)
                TransportSlot.PREVIOUS -> Triple(Icons.Rounded.SkipPrevious, colors.button, colors.onButton)
                TransportSlot.NEXT -> Triple(Icons.Rounded.SkipNext, colors.button, colors.onButton)
                TransportSlot.SHUFFLE -> if (playerInfo.isShuffleEnabled) Triple(Icons.Rounded.Shuffle, colors.onSurface, colors.surface) else Triple(Icons.Rounded.Shuffle, colors.button, colors.onButton)
                TransportSlot.REPEAT -> if (playerInfo.repeatMode != 0) {
                    Triple(if (playerInfo.repeatMode == 1) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, colors.onSurface, colors.surface)
                } else Triple(Icons.Rounded.Repeat, colors.button, colors.onButton)
                TransportSlot.FAVORITE -> Triple(if (playerInfo.isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, colors.button, colors.onButton)
            }
            TransportTile(
                if (fill) Modifier.weight(1f).height(size) else Modifier.size(size),
                icon, bg, fg,
            )
        }
    }
}

@Composable
private fun ProgressPreview(style: WidgetProgressStyle, colors: PreviewColors, playerInfo: PlayerInfo) {
    if (style == WidgetProgressStyle.NONE) return
    val fraction = if (playerInfo.totalDurationMs > 0) {
        WidgetLayoutMath.progress(playerInfo.currentPositionMs, playerInfo.totalDurationMs)
    } else 0.4f
    Spacer(Modifier.height(4.dp))
    Canvas(modifier = Modifier.fillMaxWidth().height(if (style == WidgetProgressStyle.WAVY) 6.dp else 3.dp)) {
        val mid = size.height / 2f
        val stroke = if (style == WidgetProgressStyle.WAVY) size.height * 0.3f else size.height
        drawLine(colors.onSurfaceVariant.copy(alpha = 0.25f), Offset(0f, mid), Offset(size.width, mid), stroke, StrokeCap.Round)
        val end = size.width * fraction
        if (style == WidgetProgressStyle.LINE) {
            drawLine(colors.play, Offset(0f, mid), Offset(end, mid), stroke, StrokeCap.Round)
        } else {
            val path = Path()
            val amp = (size.height - stroke) / 2f
            val wave = max(8f, size.height * 1.6f)
            var x = 0f
            path.moveTo(0f, mid)
            while (x < end) {
                val damp = min(1f, (end - x) / wave)
                path.lineTo(x, mid + sin(x / wave * 2f * PI.toFloat()) * amp * damp)
                x += 1f
            }
            drawPath(path, colors.play, style = Stroke(width = stroke, cap = StrokeCap.Round))
        }
    }
}

@Composable
private fun ArtworkTile(playerInfo: PlayerInfo, modifier: Modifier) {
    val art = rememberArtwork(playerInfo, 128)
    Box(
        modifier = modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        if (art != null) {
            Image(art.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Rounded.MusicNote, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
        }
    }
}

@Composable
private fun TransportTile(modifier: Modifier, icon: ImageVector, background: Color, tint: Color) {
    Box(
        modifier = modifier.clip(RoundedCornerShape(8.dp)).background(background),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
    }
}
