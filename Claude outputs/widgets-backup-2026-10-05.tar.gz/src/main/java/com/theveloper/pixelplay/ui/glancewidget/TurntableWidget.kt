package com.theveloper.pixelplay.ui.glancewidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.glance.ColorFilter
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalSize
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.state.getAppWidgetState
import androidx.glance.background
import androidx.glance.currentState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.size
import androidx.glance.unit.ColorProvider
import com.theveloper.pixelplay.R
import com.theveloper.pixelplay.data.model.PlayerInfo
import com.theveloper.pixelplay.data.preferences.WidgetConfig
import com.theveloper.pixelplay.data.preferences.WidgetKind
import timber.log.Timber
import kotlin.math.max

/**
 * A vinyl record on the home screen, turning while the music plays.
 *
 * The record is a bitmap from [TurntableRenderer] — `RemoteViews` cannot rotate a view — and
 * [SpinClock] decides the angle and how often a new frame is published. Each frame is a real
 * recomposition: the clock's [SpinClock.frame] is collected here and the angle passed down as
 * a parameter, which is what actually makes the record move (see [SpinClock] for why a bare
 * `update()` did not). The layout around it is [SpinStage].
 */
class TurntableWidget : GlanceAppWidget() {

    override val sizeMode = SizeMode.Exact
    override val stateDefinition = PlayerInfoStateDefinition

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val initial = loadWidgetConfig(context, WidgetKind.TURNTABLE)

        // Placing a widget while music is already playing has to start the spin too, not
        // just a play/pause event; sync is idempotent.
        runCatching {
            val state = getAppWidgetState(context, PlayerInfoStateDefinition, id)
            SpinClock.sync(context, state.isPlaying)
        }.onFailure { Timber.tag(TAG).d(it, "Could not reconcile spin state") }

        provideContent {
            val config = rememberWidgetConfig(context, WidgetKind.TURNTABLE, initial)
            val playerInfo = currentState<PlayerInfo>()
            // Read so every published frame recomposes; the value itself is not needed.
            val frame = SpinClock.frame(WidgetKind.TURNTABLE).collectAsState().value
            val angle = SpinClock.angle(WidgetKind.TURNTABLE, config.turntable.spin, playerInfo.currentPositionMs)
            GlanceTheme {
                TurntableContent(context, playerInfo, config, angle, frame)
            }
        }
    }

    @Composable
    private fun TurntableContent(
        context: Context,
        playerInfo: PlayerInfo,
        config: WidgetConfig,
        angle: Float,
        @Suppress("UNUSED_PARAMETER") frame: Long,
    ) {
        val options = config.turntable
        val palette = TurntablePalette.resolve(context, config.appearance, playerInfo)
        val placement = WidgetLayoutMath.vinylPlacement(options.discScale, options.showTonearm)
        val density = context.resources.displayMetrics.density
        val progress = WidgetLayoutMath.progress(playerInfo.currentPositionMs, playerInfo.totalDurationMs)

        SpinStage.Content(
            context = context,
            playerInfo = playerInfo,
            config = config,
            palette = palette,
            size = LocalSize.current,
            // The arm occupies the top right, so with it the favourite bubble moves top left.
            bubbles = {
                SpinStage.edgeBubbles(
                    placement,
                    favoriteAngleDeg = if (options.showTonearm) -135f else -45f,
                    play = options.showBadges,
                )
            },
            frame = { stage: Dp ->
                val stagePx = (stage.value * density).toInt().coerceIn(1, TurntableRenderer.MAX_RENDER_PX)
                val spec = TurntableRenderer.VinylSpec(
                    sizePx = stagePx,
                    placement = placement,
                    style = options.style,
                    labelFraction = options.labelScale,
                    showGrooves = options.showGrooves,
                    showSheen = options.showSheen,
                    showTonearm = options.showTonearm,
                    accent = palette.accent,
                    onAccent = palette.onAccent,
                    artworkKey = artworkKey(playerInfo),
                    title = playerInfo.songTitle,
                )
                TurntableRenderer.renderFrame(spec, angle, progress, playerInfo.isPlaying) {
                    val artPx = max(1, (spec.radiusPx * 2f).toInt())
                    TurntableRenderer.prepareArtwork(resolveTurntableArtwork(context, playerInfo, artPx), artPx)
                }
            },
            fallback = { stage -> PlainDisc(stage * placement.radius * 2f, palette) },
            objectDescription = context.getString(R.string.widget_turntable_disc_cd),
        )
    }

    /** Rendering can fail under memory pressure; a plain record beats an empty cell. */
    @Composable
    private fun PlainDisc(disc: Dp, palette: TurntablePalette) {
        Box(
            modifier = GlanceModifier
                .size(disc)
                .background(Color(0xFF0E0D10))
                .cornerRadius(disc / 2),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier = GlanceModifier
                    .size(disc * 0.34f)
                    .background(Color(palette.accent))
                    .cornerRadius(disc * 0.17f),
                contentAlignment = Alignment.Center,
            ) {
                Image(
                    provider = ImageProvider(R.drawable.ic_music_placeholder),
                    contentDescription = null,
                    modifier = GlanceModifier.size(disc * 0.16f),
                    colorFilter = ColorFilter.tint(ColorProvider(Color(palette.onAccent))),
                )
            }
        }
    }

    private companion object {
        private const val TAG = "TurntableWidget"
    }
}

/**
 * Album art as a [Bitmap], for widgets that draw it into their own artwork.
 *
 * Mirrors what `AlbumArtImage` does for the other widgets — bytes first, then the URI — but
 * returns the bitmap rather than an `ImageProvider`, because the artwork is painted into the
 * record, the CD or the cassette label rather than shown as its own view.
 */
internal fun resolveTurntableArtwork(
    context: Context,
    playerInfo: PlayerInfo,
    targetPx: Int,
): Bitmap? {
    playerInfo.albumArtBitmapData?.let { data ->
        val key = "turntable:${AlbumArtBitmapCache.getKey(data)}"
        AlbumArtBitmapCache.getBitmap(key)?.let { return it }
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(data, 0, data.size, bounds)

            var sample = 1
            if (bounds.outHeight > targetPx || bounds.outWidth > targetPx) {
                val halfHeight = bounds.outHeight / 2
                val halfWidth = bounds.outWidth / 2
                while (halfHeight / sample >= targetPx && halfWidth / sample >= targetPx) {
                    sample *= 2
                }
            }

            BitmapFactory.decodeByteArray(
                data,
                0,
                data.size,
                BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inJustDecodeBounds = false
                },
            )?.also { AlbumArtBitmapCache.putBitmap(key, it) }
        } catch (e: Exception) {
            Timber.tag("TurntableWidget").e(e, "Failed to decode artwork bytes")
            null
        }
    }

    val uri = playerInfo.albumArtUri ?: return null
    val key = "turntable:uri:$uri"
    AlbumArtBitmapCache.getBitmap(key)?.let { return it }
    return decodeWidgetAlbumArtBitmap(
        context = context,
        rawUri = uri,
        targetWidthPx = targetPx,
        targetHeightPx = targetPx,
    )?.also { AlbumArtBitmapCache.putBitmap(key, it) }
}

/** Identifies the current artwork so cached discs are dropped when the track changes. */
internal fun artworkKey(playerInfo: PlayerInfo): String =
    playerInfo.albumArtBitmapData?.let { AlbumArtBitmapCache.getKey(it) }
        ?: playerInfo.albumArtUri
        ?: "none"
