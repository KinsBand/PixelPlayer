package com.theveloper.pixelplay.ui.glancewidget

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Pure geometry and layout decisions shared by the widgets.
 *
 * Nothing in here touches Android, Glance or Compose, so every rule the widgets depend on —
 * which controls fit, where a bubble sits, how much tape is on each reel, where the stylus is
 * — is unit-testable on the JVM and cannot drift between the widget and its in-app preview.
 */
object WidgetLayoutMath {

    // -------------------------------------------------------------------------------------
    // Transport controls
    // -------------------------------------------------------------------------------------

    /** One button in a transport row, in display order. */
    enum class TransportSlot { FAVORITE, SHUFFLE, PREVIOUS, PLAY, NEXT, REPEAT }

    /**
     * Which transport buttons to draw, in order, given what the user switched on and how many
     * buttons physically fit.
     *
     * Play is always kept. When there is not room for everything the user asked for, buttons
     * are dropped in a fixed order — repeat, then shuffle, then favourite, then previous and
     * next together (a lone "next" without "previous" reads as a bug) — so the result is
     * predictable rather than whatever happened to be last.
     */
    fun planTransport(
        prevNext: Boolean,
        shuffle: Boolean,
        repeat: Boolean,
        favorite: Boolean,
        maxSlots: Int,
    ): List<TransportSlot> {
        var wantPrevNext = prevNext
        var wantShuffle = shuffle
        var wantRepeat = repeat
        var wantFavorite = favorite

        fun count(): Int = 1 +
            (if (wantPrevNext) 2 else 0) +
            (if (wantShuffle) 1 else 0) +
            (if (wantRepeat) 1 else 0) +
            (if (wantFavorite) 1 else 0)

        val limit = max(1, maxSlots)
        if (count() > limit) wantRepeat = false
        if (count() > limit) wantShuffle = false
        if (count() > limit) wantFavorite = false
        if (count() > limit) wantPrevNext = false

        return buildList {
            if (wantFavorite) add(TransportSlot.FAVORITE)
            if (wantShuffle) add(TransportSlot.SHUFFLE)
            if (wantPrevNext) add(TransportSlot.PREVIOUS)
            add(TransportSlot.PLAY)
            if (wantPrevNext) add(TransportSlot.NEXT)
            if (wantRepeat) add(TransportSlot.REPEAT)
        }
    }

    /** How many buttons of [buttonWidth], separated by [spacing], fit into [available]. */
    fun slotsThatFit(available: Float, buttonWidth: Float, spacing: Float): Int {
        if (buttonWidth <= 0f) return 1
        return max(0, floor((available + spacing) / (buttonWidth + spacing)).toInt())
    }

    // -------------------------------------------------------------------------------------
    // Bubbles on a disc
    // -------------------------------------------------------------------------------------

    /**
     * Distance from the stage's corner at which a bubble of [badge] diameter sits centred on
     * the 45° edge of a [disc]-wide circle centred in a square [stage]. Clamped at zero for
     * the degenerate case where the disc fills the whole stage.
     */
    fun edgeInset(stage: Float, disc: Float, badge: Float): Float {
        val projected = (disc / 2f) / sqrt(2f)
        return max(0f, stage / 2f - projected - badge / 2f)
    }

    /**
     * Where a round object (record or CD) sits in its square stage, as fractions of the
     * stage's edge: centre and radius.
     */
    data class DiscPlacement(val centreX: Float, val centreY: Float, val radius: Float)

    /**
     * Placement of the record. Without a tonearm it is centred at [discScale]. With one, it
     * is capped a little smaller and the record-and-arm assembly is centred, so the arm's pivot, counterweight and resting
     * position all fit inside the stage on the right, the way a deck is laid out.
     */
    fun vinylPlacement(discScale: Float, tonearm: Boolean): DiscPlacement {
        if (!tonearm) return DiscPlacement(0.5f, 0.5f, discScale.coerceIn(0.1f, 1f) / 2f)
        val r = min(discScale, TONEARM_MAX_DISC_SCALE) / 2f
        // Centre the record-plus-arm assembly as a whole, then keep both ends on stage.
        val centred = 0.5f + r - (1f + TONEARM_REACH) * r / 2f
        val cx = centred.coerceIn(r + 0.02f, max(r + 0.02f, 0.98f - TONEARM_REACH * r))
        return DiscPlacement(cx, 0.5f, r)
    }

    /** Largest record diameter (as a fraction of the stage) that leaves room for the arm. */
    const val TONEARM_MAX_DISC_SCALE = 0.8f

    /** Furthest right the arm assembly reaches, in record radii from the record's centre. */
    const val TONEARM_REACH = 1.26f

    /** Arm pivot, in record radii from the record's centre. */
    const val TONEARM_PIVOT_X = 1.06f
    const val TONEARM_PIVOT_Y = -0.62f

    /** Arm length (pivot to stylus), in record radii. */
    const val TONEARM_LENGTH = 1.12f

    /**
     * Centre of a bubble of diameter [badge] parked on the record's edge at [angleDeg]
     * (0° = 3 o'clock, clockwise), in the same units as [stage].
     */
    fun badgeCentre(placement: DiscPlacement, stage: Float, angleDeg: Float): Pair<Float, Float> {
        val a = Math.toRadians(angleDeg.toDouble())
        val r = placement.radius * stage
        return (placement.centreX * stage + r * kotlin.math.cos(a).toFloat()) to
            (placement.centreY * stage + r * kotlin.math.sin(a).toFloat())
    }

    // -------------------------------------------------------------------------------------
    // Cassette tape
    // -------------------------------------------------------------------------------------

    /**
     * Radii of the two tape packs, `(supply, take-up)`, for playback [progress] in 0..1.
     *
     * Tape length is proportional to the *area* of the pack, not its radius, so the radii
     * follow a square root: halfway through a song the two packs are the same size, but the
     * supply pack shrinks slowly at first and quickly at the end — exactly like a real tape.
     * The total tape area is conserved at every progress value.
     */
    fun tapePackRadii(progress: Float, hubRadius: Float, fullRadius: Float): Pair<Float, Float> {
        val p = progress.coerceIn(0f, 1f)
        val hub2 = hubRadius * hubRadius
        val span = max(0f, fullRadius * fullRadius - hub2)
        val supply = sqrt(hub2 + span * (1f - p))
        val takeUp = sqrt(hub2 + span * p)
        return supply to takeUp
    }

    /**
     * Seconds per revolution of a reel whose pack has radius [packRadius], when tape moves at
     * [tapeSpeed] (same length unit per second). Constant tape speed means the emptier reel
     * turns faster.
     */
    fun reelPeriodSeconds(packRadius: Float, tapeSpeed: Float): Float {
        if (packRadius <= 0f || tapeSpeed <= 0f) return Float.POSITIVE_INFINITY
        return (2f * PI.toFloat() * packRadius) / tapeSpeed
    }

    /** Index of the closest of [bucketsSeconds] to [periodSeconds]. */
    fun nearestBucket(periodSeconds: Float, bucketsSeconds: List<Float>): Int {
        require(bucketsSeconds.isNotEmpty())
        var best = 0
        var bestDistance = Float.MAX_VALUE
        bucketsSeconds.forEachIndexed { index, bucket ->
            val distance = abs(bucket - periodSeconds)
            if (distance < bestDistance) {
                best = index
                bestDistance = distance
            }
        }
        return best
    }

    // -------------------------------------------------------------------------------------
    // Tonearm
    // -------------------------------------------------------------------------------------

    /** Groove area of a 12" LP as fractions of the record's radius. */
    const val LEAD_IN_RADIUS = 0.955f
    const val RUN_OUT_RADIUS = 0.42f

    /**
     * Where the stylus should be, as a fraction of the record's radius, at playback
     * [progress]. It starts in the lead-in and walks inwards to the run-out groove at
     * [runOut] (which moves with the label size).
     */
    fun stylusRadius(progress: Float, runOut: Float = RUN_OUT_RADIUS): Float {
        val p = progress.coerceIn(0f, 1f)
        return LEAD_IN_RADIUS - p * (LEAD_IN_RADIUS - runOut)
    }

    /**
     * Where the tip of a tonearm of length [armLength], pivoting at ([pivotX], [pivotY]),
     * touches a circle of radius [targetRadius] around the record centre ([centreX],
     * [centreY]) — i.e. where the stylus sits.
     *
     * This is the intersection of two circles. Of the two solutions the one further right is
     * returned: with the pivot at the top right, as on a real deck, that is the intersection
     * the arm reaches by swinging in over the record rather than across the far side of it.
     * Returns `null` when the arm cannot reach that circle at all.
     */
    fun tonearmTip(
        pivotX: Float,
        pivotY: Float,
        centreX: Float,
        centreY: Float,
        armLength: Float,
        targetRadius: Float,
    ): Pair<Float, Float>? {
        val dx = centreX - pivotX
        val dy = centreY - pivotY
        val d = sqrt(dx * dx + dy * dy)
        if (d <= 0f || armLength <= 0f || targetRadius < 0f) return null
        if (d > armLength + targetRadius || d < abs(armLength - targetRadius)) return null
        // Distance from the pivot, along the pivot→centre line, to the chord between the two
        // intersections; then half the chord length.
        val a = (armLength * armLength - targetRadius * targetRadius + d * d) / (2f * d)
        val h = sqrt(max(0f, armLength * armLength - a * a))
        val mx = pivotX + a * dx / d
        val my = pivotY + a * dy / d
        val x1 = mx + h * dy / d
        val y1 = my - h * dx / d
        val x2 = mx - h * dy / d
        val y2 = my + h * dx / d
        return if (x1 >= x2) x1 to y1 else x2 to y2
    }

    /** Angle of the vector from (x0, y0) to (x1, y1), in degrees, 0° = +x, clockwise on screen. */
    fun angleDeg(x0: Float, y0: Float, x1: Float, y1: Float): Float =
        (atan2((y1 - y0).toDouble(), (x1 - x0).toDouble()) * 180.0 / PI).toFloat()

    // -------------------------------------------------------------------------------------
    // Misc
    // -------------------------------------------------------------------------------------

    /** Playback progress in 0..1, or 0 when the duration is unknown. */
    fun progress(positionMs: Long, durationMs: Long): Float =
        if (durationMs <= 0L) 0f else (positionMs.toFloat() / durationMs).coerceIn(0f, 1f)

    /** Wraps any angle into 0 ≤ a < 360. */
    fun normaliseDeg(angle: Float): Float {
        val wrapped = angle % 360f
        return if (wrapped < 0f) wrapped + 360f else wrapped
    }

    /** Linear interpolation. */
    fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    internal fun clamp01(v: Float): Float = min(1f, max(0f, v))

    /** `exp` on floats, kept here so callers do not each import kotlin.math. */
    internal fun expf(x: Float): Float = exp(x.toDouble()).toFloat()
}

/**
 * The motion of one spinning object — a record or a CD — with inertia.
 *
 * Velocity approaches a target exponentially, `v(t) = target + (v0 − target)·e^(−t/τ)`, so
 * pressing play spins the platter up over about a second and pausing lets it coast to a stop,
 * rather than snapping between still and full speed. Because the angle is the closed-form
 * integral of that velocity, it is exact at any instant regardless of how often frames are
 * drawn, and changing speed or direction mid-spin never applies the new rate to time that has
 * already passed.
 *
 * Not thread-safe on its own; `SpinClock` guards access.
 */
internal class SpinMotion(
    initialAngleDeg: Float = 0f,
) {
    private var anchorAngle = initialAngleDeg
    private var anchorTimeMs = 0L
    private var anchorVelocity = 0f // degrees per ms
    private var targetVelocity = 0f
    private var tauMs = 1f

    /** The rate the motion is heading towards, in degrees per millisecond. */
    val target: Float
        get() = targetVelocity

    fun angleAt(nowMs: Long): Float {
        val dt = (nowMs - anchorTimeMs).coerceAtLeast(0L).toFloat()
        val decay = 1f - WidgetLayoutMath.expf(-dt / tauMs)
        return WidgetLayoutMath.normaliseDeg(
            anchorAngle + targetVelocity * dt + (anchorVelocity - targetVelocity) * tauMs * decay,
        )
    }

    fun velocityAt(nowMs: Long): Float {
        val dt = (nowMs - anchorTimeMs).coerceAtLeast(0L).toFloat()
        return targetVelocity + (anchorVelocity - targetVelocity) * WidgetLayoutMath.expf(-dt / tauMs)
    }

    /**
     * Heads towards [newTargetDegPerMs] from wherever the motion is right now, easing with
     * time constant [easeMs]. A zero [easeMs] jumps straight to the new rate.
     */
    fun retarget(nowMs: Long, newTargetDegPerMs: Float, easeMs: Float) {
        val angle = angleAt(nowMs)
        val velocity = velocityAt(nowMs)
        anchorAngle = angle
        anchorTimeMs = nowMs
        targetVelocity = newTargetDegPerMs
        if (easeMs <= 0f) {
            anchorVelocity = newTargetDegPerMs
            tauMs = 1f
        } else {
            anchorVelocity = velocity
            tauMs = easeMs
        }
    }

    /** Stops dead where it is, with no coasting. */
    fun halt(nowMs: Long) = retarget(nowMs, 0f, 0f)

    /** True once the motion has effectively stopped and is not heading anywhere. */
    fun isAtRest(nowMs: Long): Boolean =
        targetVelocity == 0f && abs(velocityAt(nowMs)) < REST_VELOCITY

    /** True while turning towards a non-zero target, or still coasting down from one. */
    fun isMoving(nowMs: Long): Boolean = !isAtRest(nowMs)

    companion object {
        /** Below ~0.3°/s the eye cannot see the record move. */
        const val REST_VELOCITY = 0.0003f

        /** Spin-up time constant: ~95% of full speed after about a second. */
        const val SPIN_UP_MS = 330f

        /** Coast-down time constant: effectively still after about 0.8 s. */
        const val SPIN_DOWN_MS = 260f

        /** A change of speed or direction while already turning. */
        const val RETUNE_MS = 300f
    }
}
