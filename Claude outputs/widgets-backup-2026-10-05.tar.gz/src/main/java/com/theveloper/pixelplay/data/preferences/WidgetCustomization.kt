package com.theveloper.pixelplay.data.preferences

import com.theveloper.pixelplay.R

/**
 * Value types behind the Visual Widgets settings screen.
 *
 * Everything here is plain data — no Android framework types, no Compose — so the same
 * definitions can be read by the settings UI, by the Glance widgets and by unit tests.
 * Human-readable labels live in `strings_widget.xml` and are resolved by the UI via
 * `labelRes`; the `storageKey` is what actually goes into DataStore and must never change
 * once shipped.
 */

/**
 * Every user-facing option a widget can honour.
 *
 * Each [WidgetKind] declares the subset it actually draws in [WidgetKind.features]. The
 * settings screen shows a control **only** for features in that set, and every widget reads
 * every flag in its set, so a switch on the screen can never again be a switch that does
 * nothing on the home screen.
 */
enum class WidgetFeature {
    BACKGROUND,
    CORNER_RADIUS,
    ACCENT,
    TITLE,
    ARTIST,
    PREV_NEXT,
    SHUFFLE,
    REPEAT,
    FAVORITE,
    PROGRESS,
}

private val ALL_FEATURES: Set<WidgetFeature> = WidgetFeature.entries.toSet()

/** The widgets a user can place, and therefore customise, one by one. */
enum class WidgetKind(
    val storageKey: String,
    val labelRes: Int,
    /** What this widget honours. See [WidgetFeature]. */
    val features: Set<WidgetFeature>,
    /**
     * True when some controls only appear once the widget is big enough. The settings screen
     * says so under the toggles rather than letting a switched-on control silently not fit.
     */
    val sizeDependentControls: Boolean,
) {
    /**
     * Picks its own shape per size bucket — at 1x1 it is a circle — so a user corner radius
     * would flatten shapes that carry the design.
     */
    ADAPTIVE(
        "adaptive",
        R.string.widget_kind_adaptive,
        ALL_FEATURES - WidgetFeature.CORNER_RADIUS,
        sizeDependentControls = true,
    ),
    BAR_4X1("bar_4x1", R.string.widget_kind_bar, ALL_FEATURES, sizeDependentControls = true),
    CONTROL_4X2("control_4x2", R.string.widget_kind_control, ALL_FEATURES, sizeDependentControls = false),

    /** Four equal tiles: there is no fifth or sixth tile for shuffle and repeat to go in. */
    GRID_2X2(
        "grid_2x2",
        R.string.widget_kind_grid,
        ALL_FEATURES - WidgetFeature.SHUFFLE - WidgetFeature.REPEAT,
        sizeDependentControls = false,
    ),

    /** Progress is shown by the tonearm travelling across the record instead of a bar. */
    TURNTABLE(
        "turntable",
        R.string.widget_kind_turntable,
        ALL_FEATURES - WidgetFeature.PROGRESS,
        sizeDependentControls = true,
    ),

    /** Progress is shown by tape moving from one reel to the other instead of a bar. */
    CASSETTE(
        "cassette",
        R.string.widget_kind_cassette,
        ALL_FEATURES - WidgetFeature.PROGRESS,
        sizeDependentControls = true,
    ),
    DISC(
        "disc",
        R.string.widget_kind_disc,
        ALL_FEATURES - WidgetFeature.PROGRESS,
        sizeDependentControls = true,
    );

    fun supports(feature: WidgetFeature): Boolean = feature in features

    /** Widgets whose artwork is turned by the frame loop in `SpinClock`. */
    val isFrameSpun: Boolean
        get() = this == TURNTABLE || this == DISC

    companion object {
        fun fromStorageKey(value: String?): WidgetKind =
            entries.firstOrNull { it.storageKey == value } ?: ADAPTIVE
    }
}

/** How a widget fills the space behind its content. */
enum class WidgetBackgroundStyle(
    val storageKey: String,
    val labelRes: Int,
) {
    /** A flat surface colour — the historical behaviour of every shipped widget. */
    SOLID("solid", R.string.widget_background_solid),

    /** Nothing behind the content, so the wallpaper shows through. */
    TRANSPARENT("transparent", R.string.widget_background_transparent),

    /** A surface-coloured outline over a transparent body. */
    OUTLINED("outlined", R.string.widget_background_outlined);

    companion object {
        val default: WidgetBackgroundStyle = SOLID

        fun fromStorageKey(value: String?): WidgetBackgroundStyle =
            entries.firstOrNull { it.storageKey == value } ?: default
    }
}

/** Where a widget takes its accent colour from. */
enum class WidgetAccentSource(
    val storageKey: String,
    val labelRes: Int,
) {
    /** Follow the system's dynamic colour, via `GlanceTheme`. */
    MATERIAL_YOU("material_you", R.string.widget_accent_material_you),

    /** Follow the palette extracted from the current album art. */
    ALBUM_ART("album_art", R.string.widget_accent_album_art),

    /** Always use [WidgetAppearance.fixedAccentColor]. */
    FIXED("fixed", R.string.widget_accent_fixed);

    companion object {
        val default: WidgetAccentSource = ALBUM_ART

        fun fromStorageKey(value: String?): WidgetAccentSource =
            entries.firstOrNull { it.storageKey == value } ?: default
    }
}

/**
 * How a record or disc turns.
 *
 * App widgets cannot animate: every visible change is a fresh `RemoteViews` pushed to the
 * launcher. These modes are therefore a straight trade of smoothness against how often the
 * app has to wake up and re-render.
 */
enum class WidgetSpinMode(
    val storageKey: String,
    val labelRes: Int,
    val descriptionRes: Int,
) {
    /** Frames pushed continuously while audio plays, and not at all otherwise. */
    SMOOTH("smooth", R.string.widget_spin_smooth, R.string.widget_spin_smooth_desc),

    /** One step every couple of seconds; reads as turning rather than spinning. */
    TICK("tick", R.string.widget_spin_tick, R.string.widget_spin_tick_desc),

    /** No extra updates at all: the angle is derived from playback position. */
    POSITION("position", R.string.widget_spin_position, R.string.widget_spin_position_desc),

    /** Never turns. */
    OFF("off", R.string.widget_spin_off, R.string.widget_spin_off_desc);

    /** Modes that need the frame loop running while music plays. */
    val isDriven: Boolean
        get() = this == SMOOTH || this == TICK

    companion object {
        val default: WidgetSpinMode = SMOOTH

        fun fromStorageKey(value: String?): WidgetSpinMode =
            entries.firstOrNull { it.storageKey == value } ?: default
    }
}

/** Optional progress treatment along the bottom of the content widgets. */
enum class WidgetProgressStyle(
    val storageKey: String,
    val labelRes: Int,
) {
    NONE("none", R.string.widget_progress_none),
    LINE("line", R.string.widget_progress_line),
    WAVY("wavy", R.string.widget_progress_wavy);

    companion object {
        val default: WidgetProgressStyle = LINE

        fun fromStorageKey(value: String?): WidgetProgressStyle =
            entries.firstOrNull { it.storageKey == value } ?: default
    }
}

/** What the record itself is made of. */
enum class VinylStyle(
    val storageKey: String,
    val labelRes: Int,
) {
    /** Black vinyl with the album art as its centre label. */
    CLASSIC("classic", R.string.widget_vinyl_style_classic),

    /** Translucent vinyl tinted from the accent, so the wallpaper glows through faintly. */
    COLOURED("coloured", R.string.widget_vinyl_style_coloured),

    /** The album art printed across the whole record, grooves pressed over it. */
    PICTURE("picture", R.string.widget_vinyl_style_picture),

    /** A 7-inch single: wide centre hole with a three-spoke adapter. */
    SINGLE("single", R.string.widget_vinyl_style_single);

    companion object {
        val default: VinylStyle = CLASSIC

        fun fromStorageKey(value: String?): VinylStyle =
            entries.firstOrNull { it.storageKey == value } ?: default
    }
}

/** Shell colour of the cassette. */
enum class CassetteShell(
    val storageKey: String,
    val labelRes: Int,
) {
    BLACK("black", R.string.widget_cassette_shell_black),

    /** Smoked translucent plastic: the tape path and hubs show through the body. */
    SMOKE("smoke", R.string.widget_cassette_shell_smoke),
    WHITE("white", R.string.widget_cassette_shell_white),

    /** Follows the widget's accent colour. */
    ACCENT("accent", R.string.widget_cassette_shell_accent);

    companion object {
        val default: CassetteShell = BLACK

        fun fromStorageKey(value: String?): CassetteShell =
            entries.firstOrNull { it.storageKey == value } ?: default
    }
}

/** What is stuck on the front of the cassette. */
enum class CassetteLabel(
    val storageKey: String,
    val labelRes: Int,
) {
    /** A cream paper label with ruled lines and the track written on it by hand. */
    PAPER("paper", R.string.widget_cassette_label_paper),

    /** The album art as the label. */
    ART("art", R.string.widget_cassette_label_art),

    /** No label at all. */
    NONE("none", R.string.widget_cassette_label_none);

    companion object {
        val default: CassetteLabel = PAPER

        fun fromStorageKey(value: String?): CassetteLabel =
            entries.firstOrNull { it.storageKey == value } ?: default
    }
}

/** Which face of the CD is showing. */
enum class DiscFace(
    val storageKey: String,
    val labelRes: Int,
) {
    /** The playing side: mirror silver with a rainbow diffraction sheen. */
    SILVER("silver", R.string.widget_disc_face_silver),

    /** The label side: the album art printed across the disc. */
    PRINTED("printed", R.string.widget_disc_face_printed),

    /** A burnt CD-R: gold dye, with the burn edge following playback. */
    CDR("cdr", R.string.widget_disc_face_cdr);

    companion object {
        val default: DiscFace = PRINTED

        fun fromStorageKey(value: String?): DiscFace =
            entries.firstOrNull { it.storageKey == value } ?: default
    }
}

/** What the CD sits in. */
enum class DiscPresentation(
    val storageKey: String,
    val labelRes: Int,
) {
    /** Just the disc. */
    DISC("disc", R.string.widget_disc_presentation_disc),

    /** A jewel case with the album art as its insert, the disc slid half out. */
    JEWEL_CASE("jewel_case", R.string.widget_disc_presentation_case),

    /** A portable player with the disc visible through its lid. */
    PORTABLE("portable", R.string.widget_disc_presentation_portable);

    companion object {
        val default: DiscPresentation = DISC

        fun fromStorageKey(value: String?): DiscPresentation =
            entries.firstOrNull { it.storageKey == value } ?: default
    }
}

/** Appearance shared by every widget kind. */
data class WidgetAppearance(
    val backgroundStyle: WidgetBackgroundStyle = WidgetBackgroundStyle.default,
    val cornerRadiusDp: Int = DEFAULT_CORNER_RADIUS_DP,
    val accentSource: WidgetAccentSource = WidgetAccentSource.default,
    val fixedAccentColor: Int = DEFAULT_FIXED_ACCENT,
) {
    companion object {
        const val DEFAULT_CORNER_RADIUS_DP = 28
        const val MIN_CORNER_RADIUS_DP = 0
        const val MAX_CORNER_RADIUS_DP = 48

        /** The deep indigo the turntable mock is built around. */
        const val DEFAULT_FIXED_ACCENT = 0xFF1B0A33.toInt()

        /**
         * The swatches offered by the fixed-colour picker. Chosen to read well both as a
         * widget surface and behind white or near-black text.
         */
        val FIXED_ACCENT_SWATCHES: List<Int> = listOf(
            0xFF1B0A33.toInt(), // indigo night
            0xFF3B49DF.toInt(), // electric blue
            0xFF0F6E7A.toInt(), // teal
            0xFF2E6B3A.toInt(), // forest
            0xFF8A6A12.toInt(), // mustard
            0xFFC0531D.toInt(), // burnt orange
            0xFFB3262E.toInt(), // tomato
            0xFFB5297A.toInt(), // magenta
            0xFF6B3FA0.toInt(), // violet
            0xFF3A3A40.toInt(), // graphite
            0xFFE9E3D5.toInt(), // bone
            0xFFF6C9D6.toInt(), // blush
        )
    }
}

/** Which transport controls and text a widget shows. */
data class WidgetContentOptions(
    val showTitle: Boolean = true,
    val showArtist: Boolean = true,
    val showPrevNext: Boolean = true,
    val showShuffle: Boolean = false,
    val showRepeat: Boolean = false,
    val showFavorite: Boolean = true,
    val progressStyle: WidgetProgressStyle = WidgetProgressStyle.default,
)

/**
 * How a spinning widget turns. Shared by the turntable and the disc so the frame loop has
 * one shape to read.
 */
data class SpinSettings(
    val mode: WidgetSpinMode = WidgetSpinMode.default,
    /** Cosmetic, not literal: 33⅓ rpm is far too fast to read at widget frame rates. */
    val rpm: Float = TurntableOptions.DEFAULT_SPIN_RPM,
    val clockwise: Boolean = true,
) {
    /** Degrees per millisecond, signed by direction. Zero when the object is static. */
    val degreesPerMs: Float
        get() {
            if (mode == WidgetSpinMode.OFF) return 0f
            val magnitude = rpm * 360f / 60_000f
            return if (clockwise) magnitude else -magnitude
        }
}

/** Everything specific to the turntable widget. */
data class TurntableOptions(
    /** Disc diameter as a fraction of the widget's shorter edge. */
    val discScale: Float = DEFAULT_DISC_SCALE,
    /** Label (album art) diameter as a fraction of the disc diameter. */
    val labelScale: Float = DEFAULT_LABEL_SCALE,
    val spinMode: WidgetSpinMode = WidgetSpinMode.default,
    val spinRpm: Float = DEFAULT_SPIN_RPM,
    val clockwise: Boolean = true,
    /** The floating play bubble on the disc's edge. The favourite bubble is `showFavorite`. */
    val showBadges: Boolean = true,
    val showTonearm: Boolean = false,
    val showGrooves: Boolean = true,
    val showSheen: Boolean = true,
    val style: VinylStyle = VinylStyle.default,
) {
    val spin: SpinSettings
        get() = SpinSettings(mode = spinMode, rpm = spinRpm, clockwise = clockwise)

    /** Degrees per millisecond, signed by direction. Zero when the record is static. */
    val degreesPerMs: Float
        get() = spin.degreesPerMs

    companion object {
        const val DEFAULT_DISC_SCALE = 0.82f
        const val MIN_DISC_SCALE = 0.55f
        const val MAX_DISC_SCALE = 1.0f

        const val DEFAULT_LABEL_SCALE = 0.34f
        const val MIN_LABEL_SCALE = 0.18f
        const val MAX_LABEL_SCALE = 0.58f

        const val DEFAULT_SPIN_RPM = 8f
        const val MIN_SPIN_RPM = 2f
        const val MAX_SPIN_RPM = 24f
    }
}

/** Everything specific to the cassette widget. */
data class CassetteOptions(
    val shell: CassetteShell = CassetteShell.default,
    val label: CassetteLabel = CassetteLabel.default,
    /**
     * Whether the reels turn while music plays. They are animated by the launcher itself, not
     * by the app, so this costs no battery; it exists for people who prefer a still widget.
     */
    val spinReels: Boolean = true,
    /** The circled "A" on the label. */
    val showSide: Boolean = true,
)

/** Everything specific to the CD widget. */
data class DiscOptions(
    val face: DiscFace = DiscFace.default,
    val presentation: DiscPresentation = DiscPresentation.default,
    /** Disc diameter as a fraction of the widget's shorter edge. */
    val discScale: Float = DEFAULT_DISC_SCALE,
    val spinMode: WidgetSpinMode = WidgetSpinMode.default,
    val spinRpm: Float = DEFAULT_SPIN_RPM,
    val clockwise: Boolean = true,
    /** The floating play bubble on the disc's edge. The favourite bubble is `showFavorite`. */
    val showBadges: Boolean = true,
) {
    val spin: SpinSettings
        get() = SpinSettings(mode = spinMode, rpm = spinRpm, clockwise = clockwise)

    companion object {
        const val DEFAULT_DISC_SCALE = 0.86f
        const val MIN_DISC_SCALE = 0.55f
        const val MAX_DISC_SCALE = 1.0f

        /** A CD turns much faster than a record; the motion blur sells the rest. */
        const val DEFAULT_SPIN_RPM = 16f
        const val MIN_SPIN_RPM = 4f
        const val MAX_SPIN_RPM = 40f
    }
}

/** The full customisation state for one widget kind. */
data class WidgetConfig(
    val kind: WidgetKind,
    val appearance: WidgetAppearance = WidgetAppearance(),
    val content: WidgetContentOptions = WidgetContentOptions(),
    val turntable: TurntableOptions = TurntableOptions(),
    val cassette: CassetteOptions = CassetteOptions(),
    val disc: DiscOptions = DiscOptions(),
) {
    /** The spin settings that apply to this kind, or `null` if it is not frame-spun. */
    val spin: SpinSettings?
        get() = when (kind) {
            WidgetKind.TURNTABLE -> turntable.spin
            WidgetKind.DISC -> disc.spin
            else -> null
        }

    /**
     * The content options with every flag the kind does not support forced off. Widgets
     * render from this, so a stale stored value for an unsupported feature can never leak
     * onto the home screen.
     */
    val effectiveContent: WidgetContentOptions
        get() = WidgetContentOptions(
            showTitle = content.showTitle && kind.supports(WidgetFeature.TITLE),
            showArtist = content.showArtist && kind.supports(WidgetFeature.ARTIST),
            showPrevNext = content.showPrevNext && kind.supports(WidgetFeature.PREV_NEXT),
            showShuffle = content.showShuffle && kind.supports(WidgetFeature.SHUFFLE),
            showRepeat = content.showRepeat && kind.supports(WidgetFeature.REPEAT),
            showFavorite = content.showFavorite && kind.supports(WidgetFeature.FAVORITE),
            progressStyle = if (kind.supports(WidgetFeature.PROGRESS)) {
                content.progressStyle
            } else {
                WidgetProgressStyle.NONE
            },
        )
}
