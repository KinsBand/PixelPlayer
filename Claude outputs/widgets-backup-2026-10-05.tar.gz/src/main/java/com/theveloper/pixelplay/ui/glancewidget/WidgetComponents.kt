package com.theveloper.pixelplay.ui.glancewidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.glance.ColorFilter
import androidx.glance.LocalContext
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.Action
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.cornerRadius
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.ContentScale
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.unit.ColorProvider
import com.theveloper.pixelplay.R
import timber.log.Timber

@Composable
fun AlbumArtImage(
    modifier: GlanceModifier = GlanceModifier,
    bitmapData: ByteArray?,
    albumArtUri: String? = null,
    size: Dp,
    context: Context,
    cornerRadius: Dp
) {
    val imageProvider = bitmapData?.let { data ->
        val cacheKey = AlbumArtBitmapCache.getKey(data)
        var bitmap = AlbumArtBitmapCache.getBitmap(cacheKey)

        if (bitmap == null) {
            try {
                val options = BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                BitmapFactory.decodeByteArray(data, 0, data.size, options)

                var inSampleSize = 1
                // Calculate target size in pixels
                val targetSizePx = (size.value * context.resources.displayMetrics.density).toInt()

                if (options.outHeight > targetSizePx || options.outWidth > targetSizePx) {
                    val halfHeight = options.outHeight / 2
                    val halfWidth = options.outWidth / 2
                    while (halfHeight / inSampleSize >= targetSizePx &&
                        halfWidth / inSampleSize >= targetSizePx
                    ) {
                        inSampleSize *= 2
                    }
                }

                options.inSampleSize = inSampleSize
                options.inJustDecodeBounds = false
                bitmap = BitmapFactory.decodeByteArray(data, 0, data.size, options)

                bitmap?.let { AlbumArtBitmapCache.putBitmap(cacheKey, it) }
            } catch (e: Exception) {
                Timber.tag("WidgetImage").e(e, "Error decoding bitmap")
                bitmap = null
            }
        }
        bitmap?.let { ImageProvider(it) }
    } ?: albumArtUri?.let { rawUri ->
        val cacheKey = "uri:$rawUri"
        var bitmap = AlbumArtBitmapCache.getBitmap(cacheKey)
        if (bitmap == null) {
            bitmap = decodeAlbumArtFromUri(
                context = context,
                rawUri = rawUri,
                requestedSize = size
            )
            bitmap?.let { AlbumArtBitmapCache.putBitmap(cacheKey, it) }
        }
        bitmap?.let { ImageProvider(it) }
    }

    val cdAlbumArt = context.getString(R.string.widget_album_art)
    val cdPlaceholder = context.getString(R.string.widget_album_art_placeholder)
    Box(
        modifier = modifier
    ) {
        if (imageProvider != null) {
            Image(
                provider = imageProvider,
                contentDescription = cdAlbumArt,
                modifier = GlanceModifier
                    .fillMaxSize()
                    .cornerRadius(cornerRadius),
                contentScale = ContentScale.Crop
            )
        } else {
            // Placeholder
            Box(
                modifier = GlanceModifier
                    .fillMaxSize()
                    .cornerRadius(cornerRadius)
                    .background(GlanceTheme.colors.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    provider = ImageProvider(R.drawable.ic_music_placeholder),
                    contentDescription = cdPlaceholder,
                    modifier = GlanceModifier.size(size * 0.6f),
                    contentScale = ContentScale.Fit,
                    colorFilter = ColorFilter.tint(GlanceTheme.colors.onSurfaceVariant)
                )
            }
        }
    }
}

private fun decodeAlbumArtFromUri(
    context: Context,
    rawUri: String,
    requestedSize: Dp,
): Bitmap? {
    val targetPx = (requestedSize.value * context.resources.displayMetrics.density)
        .toInt()
        .coerceAtLeast(64)
    return decodeWidgetAlbumArtBitmap(
        context = context,
        rawUri = rawUri,
        targetWidthPx = targetPx,
        targetHeightPx = targetPx,
    )
}

@Composable
fun WidgetIconButton(
    modifier: GlanceModifier,
    action: Action,
    backgroundColor: ColorProvider,
    iconColor: ColorProvider,
    imageProvider: ImageProvider,
    contentDescription: String,
    iconSize: Dp = 20.dp,
    cornerRadius: Dp
) {
    Box(
        modifier = modifier
            .background(backgroundColor)
            .cornerRadius(cornerRadius)
            .clickable(action),
        contentAlignment = Alignment.Center
    ) {
        Image(
            provider = imageProvider,
            contentDescription = contentDescription,
            modifier = GlanceModifier.size(iconSize),
            colorFilter = ColorFilter.tint(iconColor)
        )
    }
}

// Convenience wrappers for specific actions
@Composable
fun PreviousButton(
    modifier: GlanceModifier,
    backgroundColor: ColorProvider,
    iconColor: ColorProvider,
    cornerRadius: Dp,
    iconSize: Dp = 20.dp
) {
    val context = LocalContext.current
    val params = actionParametersOf(PlayerActions.key to PlayerActions.PREVIOUS)
    WidgetIconButton(
        modifier = modifier,
        action = actionRunCallback<PlayerControlActionCallback>(params),
        backgroundColor = backgroundColor,
        iconColor = iconColor,
        imageProvider = ImageProvider(R.drawable.rounded_skip_previous_filled_24),
        contentDescription = context.getString(R.string.common_previous_track),
        iconSize = iconSize,
        cornerRadius = cornerRadius
    )
}

@Composable
fun NextButton(
    modifier: GlanceModifier,
    backgroundColor: ColorProvider,
    iconColor: ColorProvider,
    cornerRadius: Dp,
    iconSize: Dp = 20.dp
) {
    val context = LocalContext.current
    val params = actionParametersOf(PlayerActions.key to PlayerActions.NEXT)
    WidgetIconButton(
        modifier = modifier,
        action = actionRunCallback<PlayerControlActionCallback>(params),
        backgroundColor = backgroundColor,
        iconColor = iconColor,
        imageProvider = ImageProvider(R.drawable.rounded_skip_next_filled_24),
        contentDescription = context.getString(R.string.common_next_track),
        iconSize = iconSize,
        cornerRadius = cornerRadius
    )
}

@Composable
fun PlayPauseButton(
    modifier: GlanceModifier,
    isPlaying: Boolean,
    backgroundColor: ColorProvider,
    iconColor: ColorProvider,
    cornerRadius: Dp,
    iconSize: Dp = 22.dp
) {
    val context = LocalContext.current
    val params = actionParametersOf(PlayerActions.key to PlayerActions.PLAY_PAUSE)
    WidgetIconButton(
        modifier = modifier,
        action = actionRunCallback<PlayerControlActionCallback>(params),
        backgroundColor = backgroundColor,
        iconColor = iconColor,
        imageProvider = ImageProvider(
            if (isPlaying) R.drawable.rounded_pause_filled_24
            else R.drawable.rounded_play_arrow_filled_24
        ),
        contentDescription = context.getString(
            if (isPlaying) R.string.common_pause else R.string.common_play
        ),
        iconSize = iconSize,
        cornerRadius = cornerRadius
    )
}

@Composable
fun ShuffleButton(
    modifier: GlanceModifier,
    backgroundColor: ColorProvider,
    iconColor: ColorProvider,
    cornerRadius: Dp,
    iconSize: Dp = 20.dp,
    isActive: Boolean = false,
) {
    val context = LocalContext.current
    val params = actionParametersOf(PlayerActions.key to PlayerActions.SHUFFLE)
    WidgetIconButton(
        modifier = modifier,
        action = actionRunCallback<PlayerControlActionCallback>(params),
        backgroundColor = backgroundColor,
        iconColor = iconColor,
        imageProvider = ImageProvider(
            if (isActive) R.drawable.rounded_shuffle_on_24 else R.drawable.rounded_shuffle_24
        ),
        contentDescription = context.getString(R.string.common_shuffle),
        iconSize = iconSize,
        cornerRadius = cornerRadius
    )
}

@Composable
fun RepeatButton(
    modifier: GlanceModifier,
    backgroundColor: ColorProvider,
    iconRes: Int,
    iconColor: ColorProvider,
    cornerRadius: Dp,
    iconSize: Dp = 20.dp,
) {
    val context = LocalContext.current
    val params = actionParametersOf(PlayerActions.key to PlayerActions.REPEAT)
    WidgetIconButton(
        modifier = modifier,
        action = actionRunCallback<PlayerControlActionCallback>(params),
        backgroundColor = backgroundColor,
        iconColor = iconColor,
        imageProvider = ImageProvider(iconRes),
        contentDescription = context.getString(R.string.common_repeat),
        iconSize = iconSize,
        cornerRadius = cornerRadius
    )
}

/**
 * Toggles the current track's favourite state. Filled heart when it is a favourite, outline
 * when it is not — `round_favorite_24` is the filled glyph and `round_favorite_border_24` the
 * outline (`rounded_favorite_24`, despite the name, is also an outline).
 */
@Composable
fun FavoriteButton(
    modifier: GlanceModifier,
    isFavorite: Boolean,
    backgroundColor: ColorProvider,
    iconColor: ColorProvider,
    cornerRadius: Dp,
    iconSize: Dp = 20.dp,
) {
    val context = LocalContext.current
    val params = actionParametersOf(PlayerActions.key to PlayerActions.FAVORITE)
    WidgetIconButton(
        modifier = modifier,
        action = actionRunCallback<PlayerControlActionCallback>(params),
        backgroundColor = backgroundColor,
        iconColor = iconColor,
        imageProvider = ImageProvider(favoriteIconRes(isFavorite)),
        contentDescription = context.getString(
            if (isFavorite) R.string.widget_turntable_unfavorite_cd
            else R.string.widget_turntable_favorite_cd
        ),
        iconSize = iconSize,
        cornerRadius = cornerRadius
    )
}

/** The heart glyph for a favourite state; see [FavoriteButton]. */
internal fun favoriteIconRes(isFavorite: Boolean): Int =
    if (isFavorite) R.drawable.round_favorite_24 else R.drawable.round_favorite_border_24

/** The repeat glyph for a Media3 repeat mode (0 off, 1 one, 2 all). */
internal fun repeatIconRes(repeatMode: Int): Int =
    if (repeatMode == REPEAT_MODE_ONE) R.drawable.rounded_repeat_one_24 else R.drawable.rounded_repeat_24

/** Media3's `Player.REPEAT_MODE_*` values, mirrored so widgets need not import Media3. */
internal const val REPEAT_MODE_OFF = 0
internal const val REPEAT_MODE_ONE = 1

/** Colours for a row of transport buttons. */
internal data class TransportColors(
    val button: ColorProvider,
    val onButton: ColorProvider,
    val play: ColorProvider,
    val onPlay: ColorProvider,
    /** Shuffle or repeat while switched on, so their state reads at a glance. */
    val active: ColorProvider,
    val onActive: ColorProvider,
)

internal fun WidgetColors.transportColors(): TransportColors = TransportColors(
    button = prevNextBackground,
    onButton = prevNextIcon,
    play = playPauseBackground,
    onPlay = playPauseIcon,
    active = onSurface,
    onActive = surface,
)

/**
 * A row of transport buttons that honours every content flag the user set, and drops the
 * ones that do not fit in a fixed, predictable order (see [WidgetLayoutMath.planTransport]).
 *
 * Every button is wrapped in its own weighted box carrying half the gap as padding, rather
 * than being separated by spacers: Glance rows hold at most ten children, and six buttons with
 * five spacers between them would be eleven.
 */
@Composable
internal fun TransportRow(
    playerInfo: com.theveloper.pixelplay.data.model.PlayerInfo,
    content: com.theveloper.pixelplay.data.preferences.WidgetContentOptions,
    colors: TransportColors,
    availableWidth: Dp,
    buttonHeight: Dp,
    minButtonWidth: Dp,
    cornerRadius: Dp,
    modifier: GlanceModifier = GlanceModifier,
    spacing: Dp = 6.dp,
    playCornerRadius: Dp = cornerRadius,
    iconSize: Dp = 20.dp,
    playIconSize: Dp = 22.dp,
    includeFavorite: Boolean = content.showFavorite,
    /** When false the buttons keep [minButtonWidth] instead of sharing the row. */
    fillWidth: Boolean = true,
) {
    val slots = WidgetLayoutMath.planTransport(
        prevNext = content.showPrevNext,
        shuffle = content.showShuffle,
        repeat = content.showRepeat,
        favorite = includeFavorite,
        maxSlots = WidgetLayoutMath.slotsThatFit(
            available = availableWidth.value,
            buttonWidth = minButtonWidth.value,
            spacing = spacing.value,
        ),
    )
    androidx.glance.layout.Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        slots.forEach { slot ->
            val cell = if (fillWidth) {
                GlanceModifier.defaultWeight()
            } else {
                GlanceModifier.width(minButtonWidth + spacing)
            }
            Box(
                modifier = cell
                    .height(buttonHeight)
                    .padding(horizontal = spacing / 2),
                contentAlignment = Alignment.Center,
            ) {
                TransportButton(
                    slot = slot,
                    playerInfo = playerInfo,
                    colors = colors,
                    cornerRadius = cornerRadius,
                    playCornerRadius = playCornerRadius,
                    iconSize = iconSize,
                    playIconSize = playIconSize,
                )
            }
        }
    }
}

/** One transport button filling its cell. */
@Composable
internal fun TransportButton(
    slot: WidgetLayoutMath.TransportSlot,
    playerInfo: com.theveloper.pixelplay.data.model.PlayerInfo,
    colors: TransportColors,
    cornerRadius: Dp,
    playCornerRadius: Dp = cornerRadius,
    iconSize: Dp = 20.dp,
    playIconSize: Dp = 22.dp,
    modifier: GlanceModifier = GlanceModifier.fillMaxSize(),
) {
    when (slot) {
        WidgetLayoutMath.TransportSlot.FAVORITE -> FavoriteButton(
            modifier = modifier,
            isFavorite = playerInfo.isFavorite,
            backgroundColor = colors.button,
            iconColor = colors.onButton,
            cornerRadius = cornerRadius,
            iconSize = iconSize,
        )
        WidgetLayoutMath.TransportSlot.SHUFFLE -> ShuffleButton(
            modifier = modifier,
            backgroundColor = if (playerInfo.isShuffleEnabled) colors.active else colors.button,
            iconColor = if (playerInfo.isShuffleEnabled) colors.onActive else colors.onButton,
            cornerRadius = cornerRadius,
            iconSize = iconSize,
            isActive = playerInfo.isShuffleEnabled,
        )
        WidgetLayoutMath.TransportSlot.PREVIOUS -> PreviousButton(
            modifier = modifier,
            backgroundColor = colors.button,
            iconColor = colors.onButton,
            cornerRadius = cornerRadius,
            iconSize = iconSize,
        )
        WidgetLayoutMath.TransportSlot.PLAY -> PlayPauseButton(
            modifier = modifier,
            isPlaying = playerInfo.isPlaying,
            backgroundColor = colors.play,
            iconColor = colors.onPlay,
            cornerRadius = playCornerRadius,
            iconSize = playIconSize,
        )
        WidgetLayoutMath.TransportSlot.NEXT -> NextButton(
            modifier = modifier,
            backgroundColor = colors.button,
            iconColor = colors.onButton,
            cornerRadius = cornerRadius,
            iconSize = iconSize,
        )
        WidgetLayoutMath.TransportSlot.REPEAT -> {
            val on = playerInfo.repeatMode != REPEAT_MODE_OFF
            RepeatButton(
                modifier = modifier,
                backgroundColor = if (on) colors.active else colors.button,
                iconRes = repeatIconRes(playerInfo.repeatMode),
                iconColor = if (on) colors.onActive else colors.onButton,
                cornerRadius = cornerRadius,
                iconSize = iconSize,
            )
        }
    }
}
