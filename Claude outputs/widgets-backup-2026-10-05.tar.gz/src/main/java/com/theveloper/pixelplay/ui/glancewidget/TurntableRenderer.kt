package com.theveloper.pixelplay.ui.glancewidget

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.util.LruCache
import com.theveloper.pixelplay.data.preferences.VinylStyle
import timber.log.Timber
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Draws the turntable as bitmaps Glance can show.
 *
 * `RemoteViews` has no rotation primitive, so a spinning record means publishing a fresh,
 * already-rotated frame. A frame is three layers, and only the middle one turns:
 *
 *  1. **Underlay** (fixed): the soft shadow the record casts on the wallpaper.
 *  2. **Base** (rotates): vinyl, grooves with gaps between tracks, the dead-wax band with its
 *     etched matrix number, the album-art label with printing on it, the centre hole. This is
 *     composed once per track and cached, then blitted at a new angle each frame.
 *  3. **Overlay** (fixed): the two-lobed "bow-tie" reflection real records show, the rim
 *     highlight, the metal spindle and the tonearm. A light source or a spindle that turned
 *     with the record would read as a wobble, so these are composited after the rotation.
 *
 * Grooves are rotationally symmetric and so cannot show motion; what makes the turn readable
 * is everything asymmetric that rides on the record — the label art, the printed ring text,
 * the matrix scratches.
 *
 * Frames are never reused: each one is serialised into a `RemoteViews` and read by the
 * launcher asynchronously, so mutating it afterwards could tear a frame still in flight.
 */
object TurntableRenderer {

    /**
     * Upper bound on a frame's edge, in pixels. Every frame travels to the launcher over
     * binder inside a `RemoteViews`; 384² ARGB is 576 KiB, safely below the ~1 MB
     * transaction limit that a 512px frame (1 MiB on its own) could exceed at large sizes.
     */
    const val MAX_RENDER_PX = 384

    private const val MIN_RENDER_PX = 48

    private val baseCache = object : LruCache<String, Bitmap>(4 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val layerCache = object : LruCache<String, Bitmap>(3 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    /** Record anatomy, in fractions of the record's radius. */
    private const val LEAD_IN = WidgetLayoutMath.LEAD_IN_RADIUS
    private const val RIM = 0.985f
    private const val SPINDLE_HOLE = 0.024f
    private const val SINGLE_HOLE = 0.218f
    private const val SINGLE_LABEL = 0.48f
    private const val DEAD_WAX = 0.075f

    private val CLASSIC_BLACK = Color.rgb(14, 13, 16)

    /** Everything that decides what the turntable looks like. */
    data class VinylSpec(
        /** Edge of the square stage, in pixels. */
        val sizePx: Int,
        val placement: WidgetLayoutMath.DiscPlacement,
        val style: VinylStyle,
        /** Label diameter as a fraction of the record diameter (ignored for 7" singles). */
        val labelFraction: Float,
        val showGrooves: Boolean,
        val showSheen: Boolean,
        val showTonearm: Boolean,
        /** Tints: art-less label, coloured vinyl. */
        val accent: Int,
        val onAccent: Int,
        /** Identity of the artwork, so a new track invalidates the cached base. */
        val artworkKey: String,
        /** Printed round the label. */
        val title: String,
    ) {
        val radiusPx: Float get() = placement.radius * sizePx
        val labelRadius: Float
            get() = if (style == VinylStyle.SINGLE) SINGLE_LABEL else labelFraction.coerceIn(0.14f, 0.62f)
        val runOut: Float get() = labelRadius + DEAD_WAX

        fun baseKey(): String = buildString {
            append(radiusPx.roundToInt()).append('|').append(style.storageKey).append('|')
            append((labelFraction * 1000).toInt()).append('|').append(if (showGrooves) 1 else 0).append('|')
            append(accent).append('|').append(onAccent).append('|').append(artworkKey).append('|').append(title)
        }
    }

    // -------------------------------------------------------------------------------------
    // Frames
    // -------------------------------------------------------------------------------------

    /**
     * A square stage-sized frame of the record at [angleDeg], with [progress] placing the
     * stylus, or `null` if the size is unusable or memory is short. Callers treat `null` as
     * "skip this frame": a dropped frame is invisible, a crash in a widget update is not.
     */
    fun renderFrame(
        spec: VinylSpec,
        angleDeg: Float,
        progress: Float,
        isPlaying: Boolean,
        artwork: () -> Bitmap?,
    ): Bitmap? {
        val size = spec.sizePx
        if (size < MIN_RENDER_PX) return null
        val base = renderBase(spec, artwork) ?: return null
        return try {
            val frame = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(frame)
            renderUnderlay(spec)?.let { canvas.drawBitmap(it, 0f, 0f, null) }
            val cx = spec.placement.centreX * size
            val cy = spec.placement.centreY * size
            canvas.save()
            canvas.rotate(angleDeg, cx, cy)
            canvas.drawBitmap(base, cx - base.width / 2f, cy - base.height / 2f, BITMAP_PAINT)
            canvas.restore()
            renderOverlay(spec, progress, isPlaying)?.let { canvas.drawBitmap(it, 0f, 0f, null) }
            frame
        } catch (e: OutOfMemoryError) {
            Timber.tag(TAG).w(e, "Out of memory rendering turntable frame at %dpx", size)
            clearCache()
            null
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to render turntable frame")
            null
        }
    }

    /** Drops every cached layer. Called on low memory and when styling changes. */
    fun clearCache() {
        baseCache.evictAll()
        layerCache.evictAll()
    }

    // -------------------------------------------------------------------------------------
    // Base (rotates)
    // -------------------------------------------------------------------------------------

    /**
     * The record itself, unrotated, on a bitmap exactly its diameter. Public because the
     * in-app preview spins this with a `graphicsLayer` rather than re-rasterising.
     */
    fun renderBase(spec: VinylSpec, artwork: () -> Bitmap?): Bitmap? {
        val key = spec.baseKey()
        baseCache.get(key)?.let { if (!it.isRecycled) return it }
        val edge = max(2, (spec.radiusPx * 2f).roundToInt())
        return try {
            val bitmap = Bitmap.createBitmap(edge, edge, Bitmap.Config.ARGB_8888)
            drawRecord(Canvas(bitmap), edge / 2f, spec, artwork())
            baseCache.put(key, bitmap)
            bitmap
        } catch (e: OutOfMemoryError) {
            Timber.tag(TAG).w(e, "Out of memory composing record")
            clearCache()
            null
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to compose record")
            null
        }
    }

    private fun drawRecord(canvas: Canvas, r: Float, spec: VinylSpec, art: Bitmap?) {
        val c = r
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val style = spec.style
        val usableArt = art?.takeIf { !it.isRecycled && it.width > 0 && it.height > 0 }
        val labelR = spec.labelRadius * r
        val grooveInner = spec.runOut * r
        val grooveOuter = LEAD_IN * r

        // Body.
        paint.color = when (style) {
            VinylStyle.COLOURED -> colouredVinyl(spec.accent)
            else -> CLASSIC_BLACK
        }
        canvas.drawCircle(c, c, r, paint)

        if (style == VinylStyle.PICTURE && usableArt != null) {
            drawArtCircle(canvas, c, c, r * RIM, usableArt)
        }

        // Grooves, in bands separated by the gaps between tracks.
        if (spec.showGrooves) {
            drawGrooves(canvas, c, r, grooveInner, grooveOuter, spec)
            if (style != VinylStyle.PICTURE) drawMatrix(canvas, c, (labelR + grooveInner) / 2f, grooveInner - labelR, r, spec)
        }

        // Label.
        if (style != VinylStyle.PICTURE) {
            canvas.save()
            val clip = Path().apply { addCircle(c, c, labelR, Path.Direction.CW) }
            canvas.clipPath(clip)
            if (usableArt != null) {
                drawArtCircle(canvas, c, c, labelR, usableArt)
            } else {
                paint.shader = null
                paint.color = spec.accent
                canvas.drawCircle(c, c, labelR, paint)
                drawNoteGlyph(canvas, c, c, labelR, spec.onAccent)
            }
            drawLabelPrinting(canvas, c, labelR, spec.title)
            canvas.restore()
            stroke(paint, max(1f, r * 0.005f), Color.argb(128, 0, 0, 0))
            canvas.drawCircle(c, c, labelR, paint)
        } else {
            stroke(paint, max(1f, r * 0.004f), Color.argb(90, 255, 255, 255))
            canvas.drawCircle(c, c, labelR, paint)
        }

        // Smooth lead-in band, then the rim bevel.
        val leadWidth = r * (RIM - LEAD_IN)
        stroke(paint, leadWidth, if (style == VinylStyle.PICTURE) Color.argb(230, 20, 20, 24) else Color.argb(8, 255, 255, 255))
        canvas.drawCircle(c, c, r * (RIM + LEAD_IN) / 2f, paint)
        stroke(paint, r * (1f - RIM), if (style == VinylStyle.PICTURE) Color.rgb(15, 15, 18) else Color.argb(90, 0, 0, 0))
        canvas.drawCircle(c, c, r * (1f + RIM) / 2f, paint)

        // Centre hole, and the adapter a 7" single needs.
        val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
        if (style == VinylStyle.SINGLE) {
            val holeR = SINGLE_HOLE * r
            canvas.drawCircle(c, c, holeR, hole)
            drawAdapter(canvas, c, holeR, hole)
        } else {
            canvas.drawCircle(c, c, SPINDLE_HOLE * r, hole)
        }
    }

    private fun drawGrooves(canvas: Canvas, c: Float, r: Float, inner: Float, outer: Float, spec: VinylSpec) {
        if (outer <= inner) return
        val random = java.util.Random(spec.artworkKey.hashCode().toLong())
        val picture = spec.style == VinylStyle.PICTURE

        // 4–7 tracks of varied length, like a real side.
        val tracks = 4 + random.nextInt(4)
        val weights = FloatArray(tracks) { 0.6f + random.nextFloat() }
        val total = weights.sum()
        val gaps = FloatArray(tracks - 1)
        var acc = 0f
        for (i in 0 until tracks - 1) {
            acc += weights[i]
            gaps[i] = outer - (outer - inner) * acc / total
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = max(0.6f, r * 0.0035f)
        }
        val light = if (picture) 0.10f else 0.075f
        val lines = max(40, ((outer - inner) / max(1.1f, r * 0.006f)).roundToInt())
        for (i in 0..lines) {
            val radius = inner + (outer - inner) * i / lines
            if (gaps.any { abs(radius - it) < r * 0.008f }) continue
            val depth = 0.7f + 0.3f * (radius - inner) / (outer - inner)
            val a = (if (i % 2 == 0) light else light * 0.35f) * depth
            paint.color = if (picture) ColorMath.withAlpha(Color.BLACK, a * 1.4f) else ColorMath.withAlpha(Color.WHITE, a)
            canvas.drawCircle(c, c, radius, paint)
        }
        // Gaps between tracks: a glossier, slightly brighter band.
        for (gap in gaps) {
            paint.strokeWidth = max(1f, r * 0.009f)
            paint.color = if (picture) Color.argb(64, 0, 0, 0) else Color.argb(9, 255, 255, 255)
            canvas.drawCircle(c, c, gap, paint)
            paint.strokeWidth = max(0.6f, r * 0.002f)
            paint.color = if (picture) Color.argb(46, 255, 255, 255) else Color.argb(26, 255, 255, 255)
            canvas.drawCircle(c, c, gap, paint)
        }
        paint.strokeWidth = max(0.8f, r * 0.004f)
        paint.color = Color.argb(23, 255, 255, 255)
        canvas.drawCircle(c, c, outer, paint)
        paint.color = Color.argb(18, 255, 255, 255)
        canvas.drawCircle(c, c, inner, paint)
    }

    /** The etched matrix number in the dead wax: a short run of hand-scratched strokes. */
    private fun drawMatrix(canvas: Canvas, c: Float, radius: Float, band: Float, r: Float, spec: VinylSpec) {
        val random = java.util.Random(spec.artworkKey.hashCode().toLong() xor 0x5DEECE66DL)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = max(0.6f, r * 0.0035f)
            strokeCap = Paint.Cap.ROUND
            color = Color.argb(56, 255, 255, 255)
        }
        var t = -2.2
        repeat(16) {
            val h = band * (0.25f + 0.3f * random.nextFloat())
            val ct = cos(t).toFloat()
            val st = sin(t).toFloat()
            val x = c + ct * radius
            val y = c + st * radius
            canvas.drawLine(
                x - ct * h / 2f, y - st * h / 2f,
                x + ct * h / 2f + st * h * 0.2f, y + st * h / 2f - ct * h * 0.2f,
                paint,
            )
            t += 0.045
        }
    }

    /** The paper label's printing: a thin ring, the title across the top, speed underneath. */
    private fun drawLabelPrinting(canvas: Canvas, c: Float, labelR: Float, title: String) {
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = max(0.6f, labelR * 0.012f)
            color = Color.argb(140, 255, 255, 255)
        }
        canvas.drawCircle(c, c, labelR * 0.86f, ring)
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            letterSpacing = 0.08f
            setShadowLayer(labelR * 0.02f, 0f, 0f, Color.argb(120, 0, 0, 0))
        }
        if (title.isNotBlank()) {
            text.textSize = labelR * 0.085f
            text.color = Color.argb(217, 255, 255, 255)
            drawTextOnArc(canvas, title.uppercase(), c, labelR * 0.925f, top = true, paint = text)
        }
        text.textSize = labelR * 0.075f
        text.color = Color.argb(178, 255, 255, 255)
        drawTextOnArc(canvas, "SIDE A · 33⅓ RPM", c, labelR * 0.925f, top = false, paint = text)
    }

    /**
     * Upright text centred on the top or bottom of a circle of [radius] around ([c], [c]),
     * shrunk if it would run past 85% of the half circle.
     */
    internal fun drawTextOnArc(canvas: Canvas, text: String, c: Float, radius: Float, top: Boolean, paint: Paint) {
        val maxLength = (PI * radius * 0.85).toFloat()
        val width = paint.measureText(text)
        if (width > maxLength) paint.textSize *= maxLength / width
        val measured = paint.measureText(text)
        val oval = RectF(c - radius, c - radius, c + radius, c + radius)
        val path = Path().apply {
            // Top: 9 → 12 → 3 o'clock, glyphs pointing outwards. Bottom: 9 → 6 → 3, pointing in.
            if (top) addArc(oval, 180f, 180f) else addArc(oval, 180f, -180f)
        }
        val arcLength = (PI * radius).toFloat()
        val vOffset = paint.textSize * 0.35f
        canvas.drawTextOnPath(text, path, (arcLength - measured) / 2f, vOffset, paint)
    }

    private fun drawNoteGlyph(canvas: Canvas, cx: Float, cy: Float, labelR: Float, color: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; alpha = 230 }
        val u = labelR * 0.42f
        canvas.save()
        canvas.rotate(-20f, cx - u * 0.35f, cy + u * 0.55f)
        canvas.drawOval(RectF(cx - u * 0.77f, cy + u * 0.23f, cx + u * 0.07f, cy + u * 0.87f), paint)
        canvas.restore()
        canvas.drawRect(cx - u * 0.05f, cy - u * 0.9f, cx + u * 0.09f, cy + u * 0.55f, paint)
        val flag = Path().apply {
            moveTo(cx - u * 0.05f, cy - u * 0.9f)
            quadTo(cx + u * 0.75f, cy - u * 0.75f, cx + u * 0.55f, cy - u * 0.1f)
            quadTo(cx + u * 0.55f, cy - u * 0.5f, cx + u * 0.09f, cy - u * 0.55f)
            close()
        }
        canvas.drawPath(flag, paint)
    }

    /** The yellow three-spoke adapter that sits in a 7" single's centre hole. */
    private fun drawAdapter(canvas: Canvas, c: Float, holeR: Float, clear: Paint) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(236, 196, 70) }
        canvas.drawCircle(c, c, holeR * 0.34f, paint)
        val spoke = Path()
        val oval = RectF(-holeR, -holeR, holeR, holeR)
        for (i in 0 until 3) {
            spoke.reset()
            spoke.moveTo(holeR * 0.2f, -holeR * 0.16f)
            spoke.lineTo(holeR * 0.97f, -holeR * 0.24f)
            spoke.arcTo(oval, -13.8f, 27.6f)
            spoke.lineTo(holeR * 0.2f, holeR * 0.16f)
            spoke.close()
            canvas.save()
            canvas.translate(c, c)
            canvas.rotate(-90f + i * 120f)
            canvas.drawPath(spoke, paint)
            canvas.restore()
        }
        canvas.drawCircle(c, c, holeR * 0.11f, clear)
    }

    private fun colouredVinyl(accent: Int): Int {
        val base = ColorMath.atLuminance(accent, 0.30f)
        return ColorMath.withAlpha(base, 0.9f)
    }

    // -------------------------------------------------------------------------------------
    // Underlay and overlay (fixed)
    // -------------------------------------------------------------------------------------

    /** The shadow under the record: a blurred, offset, translucent disc. */
    fun renderUnderlay(spec: VinylSpec): Bitmap? {
        val key = "under|${spec.sizePx}|${spec.placement}"
        layerCache.get(key)?.let { if (!it.isRecycled) return it }
        return layer(key, spec.sizePx) { canvas ->
            val r = spec.radiusPx
            val cx = spec.placement.centreX * spec.sizePx
            val cy = spec.placement.centreY * spec.sizePx
            drawDropShadow(canvas, cx, cy, r)
        }
    }

    /**
     * The layer composited over the turning record: reflections, rim light, spindle and
     * tonearm. Keyed on progress quantised to 1% so the cache stays small while the stylus
     * creeps inwards.
     */
    fun renderOverlay(spec: VinylSpec, progress: Float, isPlaying: Boolean): Bitmap? {
        val step = (progress.coerceIn(0f, 1f) * 100f).toInt()
        val key = "over|${spec.sizePx}|${spec.placement}|${spec.style.storageKey}|${spec.labelRadius}|" +
            "${spec.showSheen}|${spec.showTonearm}|${if (spec.showTonearm) step else 0}|" +
            "${spec.showTonearm && isPlaying}"
        layerCache.get(key)?.let { if (!it.isRecycled) return it }
        return layer(key, spec.sizePx) { canvas ->
            val r = spec.radiusPx
            val cx = spec.placement.centreX * spec.sizePx
            val cy = spec.placement.centreY * spec.sizePx
            val labelR = spec.labelRadius * r
            if (spec.showSheen) drawSheen(canvas, cx, cy, r, labelR, spec.style == VinylStyle.PICTURE)
            if (spec.style != VinylStyle.SINGLE) drawSpindle(canvas, cx, cy, r)
            if (spec.showTonearm) drawTonearm(canvas, cx, cy, r, step / 100f, isPlaying, spec.runOut)
        }
    }

    internal fun drawDropShadow(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(107, 0, 0, 0)
            maskFilter = BlurMaskFilter(max(1f, r * 0.045f), BlurMaskFilter.Blur.NORMAL)
        }
        canvas.drawCircle(cx + r * 0.02f, cy + r * 0.04f, r * 0.985f, paint)
    }

    /**
     * The reflection real records show under a single light: two bright wedges on opposite
     * sides, here at 45° and 225°, plus a softer crossing pair. It stays still while the
     * record turns — which is exactly how it behaves on a deck.
     */
    private fun drawSheen(canvas: Canvas, cx: Float, cy: Float, r: Float, labelR: Float, picture: Boolean) {
        canvas.save()
        val grooved = Path().apply {
            fillType = Path.FillType.EVEN_ODD
            addCircle(cx, cy, r * RIM, Path.Direction.CW)
            addCircle(cx, cy, labelR, Path.Direction.CW)
        }
        canvas.clipPath(grooved)
        val peak = if (picture) 0.14f else 0.20f
        fillSweep(
            canvas, cx, cy, r,
            floatArrayOf(0f, 0.075f, 0.125f, 0.175f, 0.575f, 0.625f, 0.675f, 1f),
            floatArrayOf(0f, 0f, peak, 0f, 0f, peak, 0f, 0f),
        )
        fillSweep(
            canvas, cx, cy, r,
            floatArrayOf(0f, 0.32f, 0.375f, 0.43f, 0.82f, 0.875f, 0.93f, 1f),
            floatArrayOf(0f, 0f, 0.06f, 0f, 0f, 0.06f, 0f, 0f),
        )
        canvas.restore()

        // The label is matte paper: only a soft, broad glow.
        canvas.save()
        canvas.clipPath(Path().apply { addCircle(cx, cy, labelR, Path.Direction.CW) })
        val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                cx - labelR * 0.4f, cy - labelR * 0.45f, labelR * 1.4f,
                Color.argb(31, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP,
            )
        }
        canvas.drawCircle(cx, cy, labelR, glow)
        canvas.restore()

        // Rim catching the light at the top left.
        val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = max(1f, r * 0.008f)
            shader = LinearGradient(
                cx - r, cy - r, cx + r, cy + r,
                intArrayOf(Color.argb(90, 255, 255, 255), Color.argb(5, 255, 255, 255), Color.argb(0, 255, 255, 255)),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP,
            )
        }
        canvas.drawCircle(cx, cy, r * 0.996f, rim)
    }

    /** Fills the circle with white at the given alphas around a sweep. */
    internal fun fillSweep(canvas: Canvas, cx: Float, cy: Float, r: Float, positions: FloatArray, alphas: FloatArray, rgb: Int = Color.WHITE) {
        val colors = IntArray(alphas.size) { ColorMath.withAlpha(rgb, alphas[it]) }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = SweepGradient(cx, cy, colors, positions) }
        canvas.drawCircle(cx, cy, r, paint)
    }

    private fun drawSpindle(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        val sr = r * 0.022f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                cx - sr * 0.35f, cy - sr * 0.4f, sr * 1.1f,
                intArrayOf(Color.rgb(242, 243, 245), Color.rgb(169, 173, 180), Color.rgb(91, 95, 102)),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP,
            )
        }
        canvas.drawCircle(cx, cy, sr, paint)
    }

    /**
     * Tonearm: pivot base and counterweight at the top right, a metal tube, and an offset
     * headshell carrying the cartridge. While playing, the stylus sits on the groove matching
     * [progress]; paused, the arm swings back to its rest beside the record and its shadow
     * spreads, as if lifted.
     */
    private fun drawTonearm(canvas: Canvas, cx: Float, cy: Float, r: Float, progress: Float, playing: Boolean, runOut: Float) {
        val px = cx + WidgetLayoutMath.TONEARM_PIVOT_X * r
        val py = cy + WidgetLayoutMath.TONEARM_PIVOT_Y * r
        val length = WidgetLayoutMath.TONEARM_LENGTH * r
        val target = WidgetLayoutMath.stylusRadius(progress, runOut) * r
        val tip: Pair<Float, Float> = if (playing) {
            WidgetLayoutMath.tonearmTip(px, py, cx, cy, length, target) ?: (px to py + length)
        } else {
            val rest = (PI / 2 - 0.08).toFloat()
            (px + cos(rest) * length) to (py + sin(rest) * length)
        }
        val angle = kotlin.math.atan2(tip.second - py, tip.first - px)
        val lift = if (playing) 1f else 1.9f
        val headAngle = angle + 0.38f
        val headLength = r * 0.24f
        val headWidth = r * 0.085f
        val joint = (tip.first - cos(headAngle) * headLength * 0.72f) to (tip.second - sin(headAngle) * headLength * 0.72f)
        val tail = (px - cos(angle) * r * 0.18f) to (py - sin(angle) * r * 0.18f)

        // Shadow.
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(115, 0, 0, 0)
            maskFilter = BlurMaskFilter(max(1f, r * 0.02f * lift), BlurMaskFilter.Blur.NORMAL)
            strokeCap = Paint.Cap.ROUND
        }
        val sx = r * 0.03f * lift
        val sy = r * 0.045f * lift
        shadow.style = Paint.Style.STROKE
        shadow.strokeWidth = r * 0.045f
        canvas.drawLine(tail.first + sx, tail.second + sy, joint.first + sx, joint.second + sy, shadow)
        shadow.style = Paint.Style.FILL
        drawHeadshell(canvas, joint.first + sx, joint.second + sy, headAngle, headLength, headWidth, shadow)
        canvas.drawCircle(px + r * 0.03f, py + r * 0.045f, r * 0.13f, shadow)

        // Counterweight.
        canvas.save()
        canvas.translate(px, py)
        canvas.rotate(Math.toDegrees(angle.toDouble()).toFloat())
        val weight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, -r * 0.06f, 0f, r * 0.06f,
                intArrayOf(Color.rgb(217, 220, 225), Color.rgb(141, 144, 151), Color.rgb(75, 78, 84)),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP,
            )
        }
        canvas.drawRoundRect(RectF(-r * 0.24f, -r * 0.055f, -r * 0.13f, r * 0.055f), r * 0.02f, r * 0.02f, weight)
        canvas.restore()

        // Tube: dark edge, metal body, a thin specular line.
        val tube = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        tube.color = Color.rgb(92, 95, 102); tube.strokeWidth = r * 0.038f
        canvas.drawLine(tail.first, tail.second, joint.first, joint.second, tube)
        tube.color = Color.rgb(212, 215, 220); tube.strokeWidth = r * 0.026f
        canvas.drawLine(tail.first, tail.second, joint.first, joint.second, tube)
        tube.color = Color.argb(204, 255, 255, 255); tube.strokeWidth = r * 0.007f
        val ox = sin(angle) * r * 0.006f
        val oy = -cos(angle) * r * 0.006f
        canvas.drawLine(tail.first + ox, tail.second + oy, joint.first + ox, joint.second + oy, tube)

        drawHeadshell(canvas, joint.first, joint.second, headAngle, headLength, headWidth, null)

        // Pivot base with a machined ring and a polished cap.
        val base = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(px - r * 0.04f, py - r * 0.05f, r * 0.14f, Color.rgb(74, 76, 82), Color.rgb(27, 28, 31), Shader.TileMode.CLAMP)
        }
        canvas.drawCircle(px, py, r * 0.12f, base)
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = r * 0.006f; color = Color.argb(46, 255, 255, 255)
        }
        canvas.drawCircle(px, py, r * 0.095f, ring)
        val cap = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(px - r * 0.02f, py - r * 0.02f, r * 0.06f, Color.rgb(241, 242, 244), Color.rgb(138, 142, 149), Shader.TileMode.CLAMP)
        }
        canvas.drawCircle(px, py, r * 0.05f, cap)
    }

    /** Headshell, cartridge and finger lift, drawn along [angle] from ([x], [y]). */
    private fun drawHeadshell(canvas: Canvas, x: Float, y: Float, angle: Float, length: Float, width: Float, shadow: Paint?) {
        canvas.save()
        canvas.translate(x, y)
        canvas.rotate(Math.toDegrees(angle.toDouble()).toFloat())
        val body = RectF(-length * 0.08f, -width / 2f, length * 0.92f, width / 2f)
        if (shadow != null) {
            canvas.drawRoundRect(body, width * 0.3f, width * 0.3f, shadow)
            canvas.restore()
            return
        }
        val shell = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, -width / 2f, 0f, width / 2f, Color.rgb(58, 59, 64), Color.rgb(22, 23, 26), Shader.TileMode.CLAMP)
        }
        canvas.drawRoundRect(body, width * 0.3f, width * 0.3f, shell)
        val cartridge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(200, 50, 47) }
        canvas.drawRoundRect(RectF(length * 0.45f, -width * 0.32f, length * 0.87f, width * 0.32f), width * 0.12f, width * 0.12f, cartridge)
        val lift = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = width * 0.18f; strokeCap = Paint.Cap.ROUND; color = Color.rgb(201, 204, 210)
        }
        canvas.drawLine(length * 0.3f, -width * 0.5f, length * 0.42f, -width * 1.05f, lift)
        canvas.restore()
    }

    // -------------------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------------------

    /** Crops [art] to a circle of radius [r] at ([cx], [cy]), scaled to cover. */
    internal fun drawArtCircle(canvas: Canvas, cx: Float, cy: Float, r: Float, art: Bitmap) {
        val diameter = r * 2f
        val scale = max(diameter / art.width, diameter / art.height)
        val matrix = Matrix().apply {
            setScale(scale, scale)
            postTranslate(cx - art.width * scale / 2f, cy - art.height * scale / 2f)
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            shader = BitmapShader(art, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).apply { setLocalMatrix(matrix) }
        }
        canvas.drawCircle(cx, cy, r, paint)
    }

    private fun stroke(paint: Paint, width: Float, color: Int) {
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = width
        paint.color = color
    }

    private inline fun layer(key: String, size: Int, block: (Canvas) -> Unit): Bitmap? = try {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        block(Canvas(bitmap))
        layerCache.put(key, bitmap)
        bitmap
    } catch (e: OutOfMemoryError) {
        Timber.tag(TAG).w(e, "Out of memory composing turntable layer")
        layerCache.evictAll()
        null
    } catch (e: Exception) {
        Timber.tag(TAG).e(e, "Failed to compose turntable layer")
        null
    }

    /**
     * Downscales artwork to roughly the size it is drawn at before it is used as a shader
     * source. Feeding a 1000px cover into a 120px label wastes memory and fill rate.
     */
    fun prepareArtwork(source: Bitmap?, targetPx: Int): Bitmap? {
        if (source == null || source.isRecycled) return null
        val target = targetPx.coerceAtLeast(MIN_RENDER_PX)
        val shortest = min(source.width, source.height)
        if (shortest <= target * 1.5f) return source
        val scale = target.toFloat() / shortest
        return try {
            Bitmap.createScaledBitmap(
                source,
                max(1, (source.width * scale).toInt()),
                max(1, (source.height * scale).toInt()),
                true,
            )
        } catch (e: OutOfMemoryError) {
            Timber.tag(TAG).w(e, "Out of memory scaling turntable artwork")
            source
        }
    }

    private val BITMAP_PAINT = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    private const val TAG = "TurntableRenderer"
}
