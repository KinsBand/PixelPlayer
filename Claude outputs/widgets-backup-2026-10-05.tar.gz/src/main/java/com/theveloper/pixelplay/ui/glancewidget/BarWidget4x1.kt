package com.theveloper.pixelplay.ui.glancewidget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.LocalSize
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.provideContent
import androidx.glance.currentState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import com.theveloper.pixelplay.MainActivity
import com.theveloper.pixelplay.R
import com.theveloper.pixelplay.data.model.PlayerInfo
import com.theveloper.pixelplay.data.preferences.WidgetConfig
import com.theveloper.pixelplay.data.preferences.WidgetKind
import kotlin.math.max

/**
 * One row: artwork, title and artist, then the transport controls.
 *
 * Every content switch is honoured. Favourite, shuffle and repeat all join the row when they
 * are on; if the cell is too narrow for everything that was asked for, they are dropped in
 * [WidgetLayoutMath.planTransport]'s fixed order, and the text is given at least a minimum
 * width before any button is added.
 */
class BarWidget4x1 : GlanceAppWidget() {

    override val sizeMode = SizeMode.Exact
    override val stateDefinition = PlayerInfoStateDefinition

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val initial = loadWidgetConfig(context, WidgetKind.BAR_4X1)
        provideContent {
            val config = rememberWidgetConfig(context, WidgetKind.BAR_4X1, initial)
            val playerInfo = currentState<PlayerInfo>()
            GlanceTheme {
                BarWidget4x1Content(
                    playerInfo = playerInfo,
                    context = context,
                    config = config,
                    size = LocalSize.current
                )
            }
        }
    }

    @Composable
    private fun BarWidget4x1Content(
        playerInfo: PlayerInfo,
        context: Context,
        config: WidgetConfig,
        size: DpSize
    ) {
        val content = config.effectiveContent
        val title = playerInfo.songTitle.ifEmpty { context.getString(R.string.app_name) }
        val artist = playerInfo.artistName.ifEmpty { context.getString(R.string.widget_tap_to_open) }
        val colors = playerInfo.getWidgetColors(config.appearance)
        val showText = content.showTitle || content.showArtist

        val padding = 16.dp
        val artSize = 44.dp
        val button = 40.dp
        val gap = 6.dp
        // What is left for text plus controls after padding and artwork.
        val inner = size.width - padding * 2 - artSize - 8.dp
        // Keep a readable text column before offering the rest to buttons.
        val textReserve = if (showText) 96.dp else 0.dp
        val controlsWidth = (inner - textReserve).coerceAtLeast(button)
        val controlSlots = WidgetLayoutMath.planTransport(
            prevNext = content.showPrevNext,
            shuffle = content.showShuffle,
            repeat = content.showRepeat,
            favorite = content.showFavorite,
            maxSlots = WidgetLayoutMath.slotsThatFit(controlsWidth.value, button.value, gap.value),
        )
        val rowWidth = button * controlSlots.size + gap * max(0, controlSlots.size - 1)

        Box(
            modifier = GlanceModifier
                .fillMaxSize()
                .widgetSurface(
                    context = context,
                    appearance = config.appearance,
                    colors = colors,
                    outlineColor = outlineColorFor(context, config.appearance, playerInfo),
                    size = size
                )
                .padding(padding)
                .clickable(actionStartActivity<MainActivity>())
        ) {
            Column(modifier = GlanceModifier.fillMaxSize()) {
                Row(
                    modifier = GlanceModifier.defaultWeight().fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalAlignment = Alignment.Horizontal.Start
                ) {
                    AlbumArtImage(
                        modifier = GlanceModifier.size(artSize),
                        bitmapData = playerInfo.albumArtBitmapData,
                        albumArtUri = playerInfo.albumArtUri,
                        size = artSize,
                        context = context,
                        cornerRadius = 16.dp
                    )

                    Spacer(GlanceModifier.width(8.dp))

                    // Text keeps the weight even when switched off, so the controls stay
                    // end-aligned instead of sliding across to meet the artwork.
                    Column(
                        modifier = GlanceModifier
                            .defaultWeight()
                            .fillMaxHeight(),
                        verticalAlignment = Alignment.Vertical.CenterVertically
                    ) {
                        if (content.showTitle) {
                            Text(
                                text = title,
                                style = TextStyle(
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.onSurface
                                ),
                                maxLines = 1
                            )
                        }
                        if (content.showTitle && content.showArtist) {
                            Spacer(GlanceModifier.height(2.dp))
                        }
                        if (content.showArtist) {
                            Text(
                                text = artist,
                                style = TextStyle(
                                    fontSize = 12.sp,
                                    color = colors.artist
                                ),
                                maxLines = 1
                            )
                        }
                    }

                    Spacer(GlanceModifier.width(8.dp))

                    TransportRow(
                        playerInfo = playerInfo,
                        content = content,
                        colors = colors.transportColors(),
                        availableWidth = rowWidth,
                        buttonHeight = button,
                        minButtonWidth = button,
                        spacing = gap,
                        cornerRadius = 16.dp,
                        playCornerRadius = if (playerInfo.isPlaying) 16.dp else 20.dp,
                        fillWidth = false,
                        modifier = GlanceModifier.width(rowWidth + gap),
                    )
                }

                WidgetProgressBar(
                    context = context,
                    appearance = config.appearance,
                    playerInfo = playerInfo,
                    style = content.progressStyle,
                    widthDp = size.width - padding * 2
                )
            }
        }
    }
}
