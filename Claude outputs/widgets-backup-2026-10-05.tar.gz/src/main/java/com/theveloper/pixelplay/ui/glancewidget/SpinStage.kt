package com.theveloper.pixelplay.ui.glancewidget

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.ColorFilter
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.actionParametersOf
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.cornerRadius
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.theveloper.pixelplay.MainActivity
import com.theveloper.pixelplay.R
import com.theveloper.pixelplay.data.model.PlayerInfo
import com.theveloper.pixelplay.data.preferences.WidgetConfig
import com.theveloper.pixelplay.data.preferences.WidgetContentOptions
import kotlin.math.max
import kotlin.math.min
import androidx.compose.ui.unit.min

/**
 * The layout shared by the widgets that show one round object — the turntable and the CD.
 *
 * The object is drawn as one stage-sized bitmap (see the renderers), with the floating play
 * and favourite bubbles as real Glance elements on top, so they stay tappable and upright.
 * Around the stage, the cell's shape decides where text and controls go:
 *
 *  - nothing switched on: the stage alone, centred;
 *  - wide cells (≥ 1.6:1): text and controls in a column beside the stage;
 *  - everything else: text and a controls row stacked under the stage, which shrinks to make
 *    room — so a square 2x2 with previous/next on still shows them, instead of dropping them.
 */
internal object SpinStage {

    /** A bubble's centre, as fractions of the stage edge. */
    data class Spot(val x: Float, val y: Float)

    /** Where a widget wants its bubbles for a given stage. */
    data class Bubbles(val play: Spot?, val favorite: Spot?, val discDiameterFraction: Float)

    private const val WIDE_ASPECT = 1.6f
    private const val PLAY_FRACTION = 0.32f
    private const val FAVORITE_FRACTION = 0.26f
    private val MIN_BUBBLE = 20.dp

    @Composable
    fun Content(
        context: Context,
        playerInfo: PlayerInfo,
        config: WidgetConfig,
        palette: TurntablePalette,
        size: DpSize,
        bubbles: (stagePx: Float) -> Bubbles,
        frame: (stage: Dp) -> Bitmap?,
        fallback: @Composable (stage: Dp) -> Unit,
        objectDescription: String,
    ) {
        val content = config.effectiveContent
        val showText = content.showTitle || content.showArtist
        val showControls = content.showPrevNext || content.showShuffle || content.showRepeat
        val wantsSide = showText || showControls
        val colors = playerInfo.getWidgetColors(config.appearance)
        val framed = config.appearance.backgroundStyle != com.theveloper.pixelplay.data.preferences.WidgetBackgroundStyle.TRANSPARENT
        val pad = if (framed) 10.dp else 0.dp
        val inner = DpSize(size.width - pad * 2, size.height - pad * 2)
        val aspect = if (inner.height.value > 0f) inner.width.value / inner.height.value else 1f

        Box(
            modifier = GlanceModifier
                .fillMaxSize()
                .widgetSurface(
                    context = context,
                    appearance = config.appearance,
                    colors = colors,
                    outlineColor = outlineColorFor(context, config.appearance, playerInfo),
                    size = size,
                )
                .padding(pad)
                .clickable(actionStartActivity<MainActivity>()),
            contentAlignment = Alignment.Center,
        ) {
            when {
                !wantsSide -> Stage(context, playerInfo, content, palette, min(inner.width, inner.height), bubbles, frame, fallback, objectDescription)

                aspect >= WIDE_ASPECT -> {
                    val stage = min(inner.height, inner.width * 0.62f)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Stage(context, playerInfo, content, palette, stage, bubbles, frame, fallback, objectDescription)
                        Spacer(GlanceModifier.width(10.dp))
                        Column(
                            modifier = GlanceModifier.defaultWeight(),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            TrackText(context, playerInfo, content, palette, stage)
                            if (showControls) {
                                if (showText) Spacer(GlanceModifier.height(6.dp))
                                val button = (stage.value * 0.24f).coerceIn(28f, 44f).dp
                                Controls(playerInfo, content, palette, inner.width - stage - 10.dp, button)
                            }
                        }
                    }
                }

                else -> {
                    val titleSp = textSizes(min(inner.width, inner.height)).first
                    val textHeight = if (showText) {
                        ((if (content.showTitle) titleSp * 1.35f else 0f) + (if (content.showArtist) titleSp * 1.15f else 0f)).dp + 6.dp
                    } else 0.dp
                    val button = (min(inner.width, inner.height).value * 0.2f).coerceIn(28f, 40f).dp
                    val controlsHeight = if (showControls) button + 6.dp else 0.dp
                    val stage = max(24f, min(inner.width.value, (inner.height - textHeight - controlsHeight).value)).dp
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalAlignment = Alignment.CenterVertically) {
                        Stage(context, playerInfo, content, palette, stage, bubbles, frame, fallback, objectDescription)
                        if (showText) {
                            Spacer(GlanceModifier.height(6.dp))
                            TrackText(context, playerInfo, content, palette, min(inner.width, inner.height), centred = true)
                        }
                        if (showControls) {
                            Spacer(GlanceModifier.height(6.dp))
                            Controls(playerInfo, content, palette, inner.width, button)
                        }
                    }
                }
            }
        }
    }

    /** The object and its bubbles. */
    @Composable
    private fun Stage(
        context: Context,
        playerInfo: PlayerInfo,
        content: WidgetContentOptions,
        palette: TurntablePalette,
        stage: Dp,
        bubbles: (stagePx: Float) -> Bubbles,
        frame: (stage: Dp) -> Bitmap?,
        fallback: @Composable (stage: Dp) -> Unit,
        objectDescription: String,
    ) {
        val spots = bubbles(stage.value)
        val disc = stage * spots.discDiameterFraction
        val bitmap = frame(stage)

        Box(modifier = GlanceModifier.size(stage), contentAlignment = Alignment.Center) {
            if (bitmap != null) {
                Image(
                    provider = ImageProvider(bitmap),
                    contentDescription = objectDescription,
                    modifier = GlanceModifier.size(stage),
                )
            } else {
                fallback(stage)
            }

            spots.play?.let { spot ->
                val d = max(MIN_BUBBLE.value, disc.value * PLAY_FRACTION).dp
                Positioned(
                    alignment = Alignment.TopStart,
                    start = (stage * spot.x - d / 2).coerceAtLeast(0.dp),
                    top = (stage * spot.y - d / 2).coerceAtLeast(0.dp),
                ) {
                    PlayBubble(context, playerInfo.isPlaying, palette, d)
                }
            }
            if (content.showFavorite) {
                spots.favorite?.let { spot ->
                    val d = max(MIN_BUBBLE.value, disc.value * FAVORITE_FRACTION).dp
                    Positioned(
                        alignment = Alignment.TopStart,
                        start = (stage * spot.x - d / 2).coerceAtLeast(0.dp),
                        top = (stage * spot.y - d / 2).coerceAtLeast(0.dp),
                    ) {
                        FavoriteBubble(context, playerInfo.isFavorite, palette, d)
                    }
                }
            }
        }
    }

    @Composable
    private fun FavoriteBubble(context: Context, isFavorite: Boolean, palette: TurntablePalette, diameter: Dp) {
        Box(
            modifier = GlanceModifier
                .size(diameter)
                .background(Color(palette.favoriteBadgeBackground))
                .cornerRadius(diameter / 2)
                .clickable(
                    actionRunCallback<PlayerControlActionCallback>(
                        actionParametersOf(PlayerActions.key to PlayerActions.FAVORITE),
                    ),
                ),
            contentAlignment = Alignment.Center,
        ) {
            Image(
                provider = ImageProvider(favoriteIconRes(isFavorite)),
                contentDescription = context.getString(
                    if (isFavorite) R.string.widget_turntable_unfavorite_cd
                    else R.string.widget_turntable_favorite_cd,
                ),
                modifier = GlanceModifier.size(diameter * 0.52f),
                colorFilter = ColorFilter.tint(ColorProvider(Color(palette.favoriteBadgeIcon))),
            )
        }
    }

    @Composable
    private fun PlayBubble(context: Context, isPlaying: Boolean, palette: TurntablePalette, side: Dp) {
        Box(
            modifier = GlanceModifier
                .size(side)
                .background(Color(palette.playBadgeBackground))
                .cornerRadius(side * 0.3f)
                .clickable(
                    actionRunCallback<PlayerControlActionCallback>(
                        actionParametersOf(PlayerActions.key to PlayerActions.PLAY_PAUSE),
                    ),
                ),
            contentAlignment = Alignment.Center,
        ) {
            Image(
                provider = ImageProvider(
                    if (isPlaying) R.drawable.rounded_pause_filled_24 else R.drawable.rounded_play_arrow_filled_24,
                ),
                contentDescription = context.getString(if (isPlaying) R.string.common_pause else R.string.common_play),
                modifier = GlanceModifier.size(side * 0.5f),
                colorFilter = ColorFilter.tint(ColorProvider(Color(palette.playBadgeIcon))),
            )
        }
    }

    private fun textSizes(reference: Dp): Pair<Float, Float> =
        (reference.value * 0.14f).coerceIn(11f, 18f) to (reference.value * 0.11f).coerceIn(10f, 15f)

    @Composable
    private fun TrackText(
        context: Context,
        playerInfo: PlayerInfo,
        content: WidgetContentOptions,
        palette: TurntablePalette,
        reference: Dp,
        centred: Boolean = false,
    ) {
        if (!content.showTitle && !content.showArtist) return
        val (titleSp, artistSp) = textSizes(reference)
        val align = if (centred) androidx.glance.text.TextAlign.Center else androidx.glance.text.TextAlign.Start
        Column(horizontalAlignment = if (centred) Alignment.CenterHorizontally else Alignment.Start) {
            if (content.showTitle) {
                Text(
                    text = playerInfo.songTitle.ifEmpty { context.getString(R.string.app_name) },
                    maxLines = 1,
                    style = TextStyle(
                        color = ColorProvider(Color(palette.title)),
                        fontSize = titleSp.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = align,
                    ),
                )
            }
            if (content.showArtist) {
                Text(
                    text = playerInfo.artistName.ifEmpty { context.getString(R.string.widget_tap_to_open) },
                    maxLines = 1,
                    style = TextStyle(
                        color = ColorProvider(Color(palette.artist)),
                        fontSize = artistSp.sp,
                        textAlign = align,
                    ),
                )
            }
        }
    }

    /**
     * Previous, next, shuffle and repeat as round buttons. Play and favourite are already on
     * the stage as bubbles, so they are not repeated here.
     */
    @Composable
    private fun Controls(
        playerInfo: PlayerInfo,
        content: WidgetContentOptions,
        palette: TurntablePalette,
        available: Dp,
        button: Dp,
    ) {
        val colors = TransportColors(
            button = ColorProvider(Color(palette.playBadgeBackground)),
            onButton = ColorProvider(Color(palette.playBadgeIcon)),
            play = ColorProvider(Color(palette.playBadgeBackground)),
            onPlay = ColorProvider(Color(palette.playBadgeIcon)),
            active = ColorProvider(Color(palette.playBadgeIcon)),
            onActive = ColorProvider(Color(palette.playBadgeBackground)),
        )
        val plan = WidgetLayoutMath.planTransport(
            prevNext = content.showPrevNext,
            shuffle = content.showShuffle,
            repeat = content.showRepeat,
            favorite = false,
            // +1: play is planned but not drawn here, so it must not cost a real slot.
            maxSlots = WidgetLayoutMath.slotsThatFit(available.value, button.value, 6f) + 1,
        ).filter { it != WidgetLayoutMath.TransportSlot.PLAY }
        if (plan.isEmpty()) return
        Row(verticalAlignment = Alignment.CenterVertically) {
            plan.forEach { slot ->
                Box(modifier = GlanceModifier.size(button + 6.dp).padding(3.dp)) {
                    TransportButton(
                        slot = slot,
                        playerInfo = playerInfo,
                        colors = colors,
                        cornerRadius = button / 2,
                        iconSize = button * 0.5f,
                    )
                }
            }
        }
    }

    /** Bubbles on a centred disc: play on the lower-left edge, favourite on the upper-right. */
    fun edgeBubbles(placement: WidgetLayoutMath.DiscPlacement, favoriteAngleDeg: Float = -45f, play: Boolean): Bubbles {
        fun spot(angle: Float): Spot {
            val (x, y) = WidgetLayoutMath.badgeCentre(placement, 1f, angle)
            return Spot(x, y)
        }
        return Bubbles(
            play = if (play) spot(135f) else null,
            favorite = spot(favoriteAngleDeg),
            discDiameterFraction = placement.radius * 2f,
        )
    }
}
