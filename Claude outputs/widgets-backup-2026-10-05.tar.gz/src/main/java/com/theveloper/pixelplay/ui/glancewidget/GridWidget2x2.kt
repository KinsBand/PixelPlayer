package com.theveloper.pixelplay.ui.glancewidget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.LocalSize
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.currentState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.theveloper.pixelplay.MainActivity
import com.theveloper.pixelplay.R
import com.theveloper.pixelplay.data.model.PlayerInfo
import com.theveloper.pixelplay.data.preferences.WidgetConfig
import com.theveloper.pixelplay.data.preferences.WidgetKind

/**
 * Four equal tiles: artwork, play, previous, next.
 *
 * Title and artist, when switched on, sit on a small scrim across the bottom of the artwork;
 * the favourite heart floats in its top corner. There is no room for shuffle or repeat without
 * breaking the grid, so this widget does not offer them (see `WidgetKind.GRID_2X2`). With
 * previous/next off, the artwork and play tiles take the full height.
 */
class GridWidget2x2 : GlanceAppWidget() {

    override val sizeMode = SizeMode.Exact
    override val stateDefinition = PlayerInfoStateDefinition

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val initial = loadWidgetConfig(context, WidgetKind.GRID_2X2)
        provideContent {
            val config = rememberWidgetConfig(context, WidgetKind.GRID_2X2, initial)
            val playerInfo = currentState<PlayerInfo>()
            GlanceTheme {
                GridWidget2x2Content(
                    playerInfo = playerInfo,
                    context = context,
                    config = config
                )
            }
        }
    }

    @Composable
    private fun GridWidget2x2Content(
        playerInfo: PlayerInfo,
        context: Context,
        config: WidgetConfig
    ) {
        val content = config.effectiveContent
        val colors = playerInfo.getWidgetColors(config.appearance)
        val transport = colors.transportColors()
        val itemCornerRadius = 16.dp

        val size = LocalSize.current
        val minSide = min(size.width, size.height)
        val dynamicIconSize = (minSide.value * 0.14f).dp
        val dynamicPlayIconSize = (minSide.value * 0.16f).dp
        val albumArtSize = (minSide.value * 0.40f).dp
        val padding = 16.dp

        Box(
            modifier = GlanceModifier
                .fillMaxSize()
                .clickable(actionStartActivity<MainActivity>()),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier = GlanceModifier
                    .size(minSide)
                    .widgetSurface(
                        context = context,
                        appearance = config.appearance,
                        colors = colors,
                        outlineColor = outlineColorFor(context, config.appearance, playerInfo),
                        size = DpSize(minSide, minSide)
                    )
                    .padding(padding)
            ) {
                Column(modifier = GlanceModifier.fillMaxSize()) {
                    Row(
                        modifier = GlanceModifier
                            .defaultWeight()
                            .fillMaxWidth()
                    ) {
                        Box(modifier = GlanceModifier.defaultWeight().fillMaxHeight()) {
                            AlbumArtImage(
                                modifier = GlanceModifier.fillMaxSize(),
                                bitmapData = playerInfo.albumArtBitmapData,
                                albumArtUri = playerInfo.albumArtUri,
                                size = albumArtSize,
                                context = context,
                                cornerRadius = itemCornerRadius
                            )
                            if (content.showTitle || content.showArtist) {
                                Positioned(alignment = Alignment.BottomStart, start = 4.dp, end = 4.dp, bottom = 4.dp) {
                                    ArtworkCaption(context, playerInfo, content.showTitle, content.showArtist)
                                }
                            }
                            if (content.showFavorite) {
                                Positioned(alignment = Alignment.TopEnd, top = 5.dp, end = 5.dp) {
                                    FavoriteButton(
                                        modifier = GlanceModifier.size(26.dp),
                                        isFavorite = playerInfo.isFavorite,
                                        backgroundColor = transport.button,
                                        iconColor = transport.onButton,
                                        cornerRadius = 13.dp,
                                        iconSize = 15.dp,
                                    )
                                }
                            }
                        }

                        Spacer(GlanceModifier.width(6.dp))

                        PlayPauseButton(
                            modifier = GlanceModifier
                                .defaultWeight()
                                .fillMaxHeight(),
                            isPlaying = playerInfo.isPlaying,
                            backgroundColor = transport.play,
                            iconColor = transport.onPlay,
                            cornerRadius = itemCornerRadius,
                            iconSize = dynamicPlayIconSize
                        )
                    }

                    if (content.showPrevNext) {
                        Spacer(GlanceModifier.height(6.dp))
                        Row(
                            modifier = GlanceModifier
                                .defaultWeight()
                                .fillMaxWidth()
                        ) {
                            PreviousButton(
                                modifier = GlanceModifier
                                    .defaultWeight()
                                    .fillMaxHeight(),
                                backgroundColor = transport.button,
                                iconColor = transport.onButton,
                                cornerRadius = itemCornerRadius,
                                iconSize = dynamicIconSize
                            )

                            Spacer(GlanceModifier.width(6.dp))

                            NextButton(
                                modifier = GlanceModifier
                                    .defaultWeight()
                                    .fillMaxHeight(),
                                backgroundColor = transport.button,
                                iconColor = transport.onButton,
                                cornerRadius = itemCornerRadius,
                                iconSize = dynamicIconSize
                            )
                        }
                    }

                    WidgetProgressBar(
                        context = context,
                        appearance = config.appearance,
                        playerInfo = playerInfo,
                        style = content.progressStyle,
                        widthDp = minSide - padding * 2
                    )
                }
            }
        }
    }

    /** Title and artist on a dark rounded scrim, so they read on any artwork. */
    @Composable
    private fun ArtworkCaption(
        context: Context,
        playerInfo: PlayerInfo,
        showTitle: Boolean,
        showArtist: Boolean,
    ) {
        Column(
            modifier = GlanceModifier
                .fillMaxWidth()
                .background(ColorProvider(Color(0x8C000000)))
                .cornerRadius(12.dp)
                .padding(horizontal = 8.dp, vertical = 5.dp)
        ) {
            if (showTitle) {
                Text(
                    text = playerInfo.songTitle.ifEmpty { context.getString(R.string.app_name) },
                    style = TextStyle(
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorProvider(Color.White)
                    ),
                    maxLines = 1
                )
            }
            if (showArtist) {
                Text(
                    text = playerInfo.artistName.ifEmpty { context.getString(R.string.widget_tap_to_open) },
                    style = TextStyle(
                        fontSize = 10.sp,
                        color = ColorProvider(Color(0xDDFFFFFF))
                    ),
                    maxLines = 1
                )
            }
        }
    }
}
