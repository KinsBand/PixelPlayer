package com.theveloper.pixelplay.ui.glancewidget

import android.content.Context
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver

class DiscWidgetReceiver : GlanceAppWidgetReceiver() {

    override val glanceAppWidget: GlanceAppWidget = DiscWidget()

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        super.onDeleted(context, appWidgetIds)
        SpinClock.sync(context)
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        SpinClock.sync(context)
        DiscRenderer.clearCache()
    }
}
