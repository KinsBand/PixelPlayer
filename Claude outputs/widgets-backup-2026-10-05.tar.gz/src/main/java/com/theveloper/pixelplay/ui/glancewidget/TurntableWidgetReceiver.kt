package com.theveloper.pixelplay.ui.glancewidget

import android.content.Context
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver

class TurntableWidgetReceiver : GlanceAppWidgetReceiver() {

    override val glanceAppWidget: GlanceAppWidget = TurntableWidget()

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        super.onDeleted(context, appWidgetIds)
        // The clock re-counts placed widgets itself, so removing the last turntable stops its
        // frames straight away rather than at the next keep-alive.
        SpinClock.sync(context)
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        SpinClock.sync(context)
        TurntableRenderer.clearCache()
    }
}
