package com.theveloper.pixelplay.data.service

import android.content.Context
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.state.updateAppWidgetState
import com.theveloper.pixelplay.data.diagnostics.PerformanceMetrics
import com.theveloper.pixelplay.data.model.PlayerInfo
import com.theveloper.pixelplay.ui.glancewidget.BarWidget4x1
import com.theveloper.pixelplay.ui.glancewidget.CassetteWidget
import com.theveloper.pixelplay.ui.glancewidget.ControlWidget4x2
import com.theveloper.pixelplay.ui.glancewidget.DiscWidget
import com.theveloper.pixelplay.ui.glancewidget.GridWidget2x2
import com.theveloper.pixelplay.ui.glancewidget.PixelPlayGlanceWidget
import com.theveloper.pixelplay.ui.glancewidget.PlayerInfoStateDefinition
import com.theveloper.pixelplay.ui.glancewidget.SpinClock
import com.theveloper.pixelplay.ui.glancewidget.TurntableWidget
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import kotlin.math.abs

/**
 * Owns the Glance widget update pipeline, extracted from [MusicService]
 * during the Pass 5 service decomposition.
 *
 * Responsibilities:
 *  - Debouncing the many `requestFullUpdate` triggers fired by player/cast events.
 *  - Diffing the freshly built [PlayerInfo] against the last published one so we
 *    only re-render widgets when something user-visible actually changed.
 *  - Rendering every Glance widget variant.
 *
 * State *assembly* stays in the service (it is intimately tied to the player,
 * repositories, favorites and theme), supplied here through [buildPlayerInfo].
 * This manager only orchestrates the *update*.
 */
internal class WidgetUpdateManager(
    private val context: Context,
    private val scope: CoroutineScope,
    private val buildPlayerInfo: suspend () -> PlayerInfo,
) {
    private companion object {
        private const val TAG = "MusicService_PixelPlay"
        private const val FORCED_DEBOUNCE_MS = 250L
        private const val NORMAL_DEBOUNCE_MS = 300L
        private const val FOLLOW_UP_DELAY_MS = 250L
        private const val QUEUE_PREVIEW_LIMIT = 4
    }

    private var debouncedUpdateJob: Job? = null
    private var followUpUpdateJob: Job? = null
    private var lastWidgetPlayerInfo: PlayerInfo? = null

    fun requestFullUpdate(force: Boolean = false) {
        debouncedUpdateJob?.cancel()
        debouncedUpdateJob = scope.launch {
            val debounceMs = if (force) FORCED_DEBOUNCE_MS else NORMAL_DEBOUNCE_MS
            if (debounceMs > 0L) {
                delay(debounceMs)
            }
            processUpdateInternal()
        }
    }

    /** Forces an immediate update plus a delayed follow-up so late-arriving
     *  metadata/artwork (delivered after the first callback) is still published. */
    fun requestWithFollowUp() {
        requestFullUpdate(force = true)
        followUpUpdateJob?.cancel()
        followUpUpdateJob = scope.launch {
            delay(FOLLOW_UP_DELAY_MS)
            requestFullUpdate(force = true)
        }
    }

    fun cancel() {
        followUpUpdateJob?.cancel()
        debouncedUpdateJob?.cancel()
    }

    /**
     * Drops the cached [PlayerInfo] so its embedded artwork ByteArray becomes
     * GC-eligible under memory pressure. The next update rebuilds it from scratch.
     */
    fun clearCachedState() {
        lastWidgetPlayerInfo = null
    }

    private suspend fun processUpdateInternal() {
        val playerInfo = buildPlayerInfo()
        val oldInfo = lastWidgetPlayerInfo

        val shouldUpdateWidgets = oldInfo == null || shouldUpdateWidget(oldInfo, playerInfo)

        if (shouldUpdateWidgets) {
            lastWidgetPlayerInfo = playerInfo
            updateGlanceWidgets(playerInfo)
        }
    }

    private fun shouldUpdateWidget(old: PlayerInfo, new: PlayerInfo): Boolean {
        if (old.songTitle != new.songTitle) return true
        if (old.artistName != new.artistName) return true
        if (old.isPlaying != new.isPlaying) return true
        if (old.albumArtUri != new.albumArtUri) return true
        // Detect when artwork bytes arrive (null → non-null) or are cleared
        if ((old.albumArtBitmapData == null) != (new.albumArtBitmapData == null)) return true
        if (old.isFavorite != new.isFavorite) return true
        if (old.queue != new.queue) return true
        if (old.themeColors != new.themeColors) return true
        if (old.isShuffleEnabled != new.isShuffleEnabled) return true
        if (old.repeatMode != new.repeatMode) return true
        if (old.totalDurationMs != new.totalDurationMs) return true

        val drift = abs(old.currentPositionMs - new.currentPositionMs)
        return drift > 3000L
    }

    private suspend fun updateGlanceWidgets(playerInfo: PlayerInfo) = withContext(Dispatchers.IO) {
        val startNanos = System.nanoTime()
        try {
            val glanceManager = GlanceAppWidgetManager(context)
            val widgetPlayerInfo = playerInfo.toWidgetTransportState()

            val glanceIds = glanceManager.getGlanceIds(PixelPlayGlanceWidget::class.java)
            glanceIds.forEach { id ->
                updateAppWidgetState(context, PlayerInfoStateDefinition, id) { widgetPlayerInfo }
                PixelPlayGlanceWidget().update(context, id)
            }

            val barGlanceIds = glanceManager.getGlanceIds(BarWidget4x1::class.java)
            barGlanceIds.forEach { id ->
                updateAppWidgetState(context, PlayerInfoStateDefinition, id) { widgetPlayerInfo }
                BarWidget4x1().update(context, id)
            }

            val controlGlanceIds = glanceManager.getGlanceIds(ControlWidget4x2::class.java)
            controlGlanceIds.forEach { id ->
                updateAppWidgetState(context, PlayerInfoStateDefinition, id) { widgetPlayerInfo }
                ControlWidget4x2().update(context, id)
            }

            val gridGlanceIds = glanceManager.getGlanceIds(GridWidget2x2::class.java)
            gridGlanceIds.forEach { id ->
                updateAppWidgetState(context, PlayerInfoStateDefinition, id) { widgetPlayerInfo }
                GridWidget2x2().update(context, id)
            }

            val turntableGlanceIds = glanceManager.getGlanceIds(TurntableWidget::class.java)
            turntableGlanceIds.forEach { id ->
                updateAppWidgetState(context, PlayerInfoStateDefinition, id) { widgetPlayerInfo }
                TurntableWidget().update(context, id)
            }

            val cassetteGlanceIds = glanceManager.getGlanceIds(CassetteWidget::class.java)
            cassetteGlanceIds.forEach { id ->
                updateAppWidgetState(context, PlayerInfoStateDefinition, id) { widgetPlayerInfo }
                CassetteWidget().update(context, id)
            }

            val discGlanceIds = glanceManager.getGlanceIds(DiscWidget::class.java)
            discGlanceIds.forEach { id ->
                updateAppWidgetState(context, PlayerInfoStateDefinition, id) { widgetPlayerInfo }
                DiscWidget().update(context, id)
            }

            // The record and the CD keep turning between these updates, so the spin loop is
            // told whenever playback starts or stops. It reads each widget's own spin
            // settings itself, so nothing here can hand it the wrong ones.
            SpinClock.sync(context, playerInfo.isPlaying)

            val anyWidgets = glanceIds.isNotEmpty() || barGlanceIds.isNotEmpty() ||
                controlGlanceIds.isNotEmpty() || gridGlanceIds.isNotEmpty() ||
                turntableGlanceIds.isNotEmpty() || cassetteGlanceIds.isNotEmpty() ||
                discGlanceIds.isNotEmpty()
            PerformanceMetrics.setWidgetActive(anyWidgets)
            if (anyWidgets) {
                PerformanceMetrics.recordTiming(
                    PerformanceMetrics.Timings.WIDGET_UPDATE,
                    (System.nanoTime() - startNanos) / 1_000_000
                )
                Timber.tag(TAG)
                    .d("Widgets actualizados: ${playerInfo.songTitle} (Original: ${glanceIds.size}, Bar: ${barGlanceIds.size}, Control: ${controlGlanceIds.size}, Turntable: ${turntableGlanceIds.size}, Cassette: ${cassetteGlanceIds.size}, Disc: ${discGlanceIds.size})")
            } else {
                Timber.tag(TAG).w("No se encontraron widgets para actualizar")
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Error al actualizar el widget")
        }
    }

    private fun PlayerInfo.toWidgetTransportState(): PlayerInfo {
        return copy(
            lyrics = null,
            isLoadingLyrics = false,
            queue = queue.take(QUEUE_PREVIEW_LIMIT),
        )
    }
}
