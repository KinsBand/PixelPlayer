package com.theveloper.pixelplay.ui.glancewidget

import android.graphics.Bitmap
import android.graphics.BlendMode
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.util.LruCache
import com.theveloper.pixelplay.data.preferences.DiscFace
import com.theveloper.pixelplay.data.preferences.DiscPresentation
import timber.log.Timber
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Draws the CD widget as bitmaps, on the same three-layer plan as [TurntableRenderer]:
 * a fixed underlay (shadow; the jewel case's back), the disc that turns, and a fixed overlay.
 *
 * Proportions are a real 120 mm disc's, as fractions of its radius: a 15 mm centre hole, a
 * clear polycarbonate hub with its stacking ring, the mirror band where the matrix code is
 * etched, then the data or printed area out to a thin clear rim.
 *
 * The rainbow on the playing side is diffraction — it belongs to the light, not the disc — so
 * it is drawn in the fixed overlay and stays put while the disc turns underneath. What shows
 * the turn is the asymmetric detail riding on the disc: printed art, the title, the matrix
 * code. A CD also turns far faster than a record; above a few degrees per frame the base is
 * drawn with a light angular motion blur so it reads as spinning rather than strobing.
 */
object DiscRenderer {

    const val MAX_RENDER_PX = TurntableRenderer.MAX_RENDER_PX
    private const val MIN_RENDER_PX = 48

    // Anatomy, as fractions of the disc radius.
    private const val HOLE = 0.125f
    private const val HUB = 0.275f
    private const val STACK_RING = 0.285f
    private const val MIRROR = 0.383f
    private const val DATA_OUTER = 0.967f

    /** Motion blur starts once the disc moves more than this per frame. */
    private const val BLUR_THRESHOLD_DEG = 6f

    private val baseCache = object : LruCache<String, Bitmap>(4 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val layerCache = object : LruCache<String, Bitmap>(4 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    data class DiscSpec(
        /** Edge of the square stage, in pixels. */
        val sizePx: Int,
        val face: DiscFace,
        val presentation: DiscPresentation,
        /** Disc diameter as a fraction of the stage, before the presentation adjusts it. */
        val discScale: Float,
        val accent: Int,
        val artworkKey: String,
        val title: String,
    ) {
        /** Where the disc sits in the stage for this presentation. */
        val placement: WidgetLayoutMath.DiscPlacement
            get() = when (presentation) {
                DiscPresentation.DISC -> WidgetLayoutMath.DiscPlacement(0.5f, 0.5f, discScale / 2f)
                // Slid half out of the top-right of the case.
                DiscPresentation.JEWEL_CASE -> WidgetLayoutMath.DiscPlacement(0.61f, 0.39f, 0.35f)
                // Seen through the lid of a round portable player.
                DiscPresentation.PORTABLE -> WidgetLayoutMath.DiscPlacement(0.5f, 0.47f, 0.33f)
            }

        val radiusPx: Float get() = placement.radius * sizePx
    }

    /**
     * A stage-sized frame with the disc at [angleDeg]. [degreesPerFrame] sizes the motion
     * blur; [progress] drives the CD-R burn edge.
     */
    fun renderFrame(
        spec: DiscSpec,
        angleDeg: Float,
        degreesPerFrame: Float,
        progress: Float,
        artwork: () -> Bitmap?,
    ): Bitmap? {
        val size = spec.sizePx
        if (size < MIN_RENDER_PX) return null
        val base = renderBase(spec, progress, artwork) ?: return null
        return try {
            val frame = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(frame)
            renderUnderlay(spec)?.let { canvas.drawBitmap(it, 0f, 0f, null) }

            val cx = spec.placement.centreX * size
            val cy = spec.placement.centreY * size
            val blur = if (degreesPerFrame > BLUR_THRESHOLD_DEG) min(10f, degreesPerFrame * 0.5f) else 0f
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            if (blur > 0f) {
                // Two faint ghosts either side of the true angle, then the disc itself.
                paint.alpha = 90
                drawRotated(canvas, base, cx, cy, angleDeg - blur, paint)
                drawRotated(canvas, base, cx, cy, angleDeg + blur, paint)
                paint.alpha = 255
            }
            drawRotated(canvas, base, cx, cy, angleDeg, paint)

            renderOverlay(spec, artwork)?.let { canvas.drawBitmap(it, 0f, 0f, null) }
            frame
        } catch (e: OutOfMemoryError) {
            Timber.tag(TAG).w(e, "Out of memory rendering disc frame at %dpx", size)
            clearCache()
            null
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to render disc frame")
            null
        }
    }

    fun clearCache() {
        baseCache.evictAll()
        layerCache.evictAll()
    }

    private fun drawRotated(canvas: Canvas, base: Bitmap, cx: Float, cy: Float, angle: Float, paint: Paint) {
        canvas.save()
        canvas.rotate(angle, cx, cy)
        canvas.drawBitmap(base, cx - base.width / 2f, cy - base.height / 2f, paint)
        canvas.restore()
    }

    // -------------------------------------------------------------------------------------
    // Base (turns)
    // -------------------------------------------------------------------------------------

    /** The disc, unrotated, on a bitmap exactly its diameter. Public for the in-app preview. */
    fun renderBase(spec: DiscSpec, progress: Float, artwork: () -> Bitmap?): Bitmap? {
        val burnStep = if (spec.face == DiscFace.CDR) (progress.coerceIn(0f, 1f) * 100f).toInt() else 0
        val r = spec.radiusPx
        val key = "${r.roundToInt()}|${spec.face.storageKey}|${spec.artworkKey}|${spec.title}|$burnStep"
        baseCache.get(key)?.let { if (!it.isRecycled) return it }
        val edge = max(2, (r * 2f).roundToInt())
        return try {
            val bitmap = Bitmap.createBitmap(edge, edge, Bitmap.Config.ARGB_8888)
            drawDisc(Canvas(bitmap), edge / 2f, spec, burnStep / 100f, if (spec.face == DiscFace.PRINTED) artwork() else null)
            baseCache.put(key, bitmap)
            bitmap
        } catch (e: OutOfMemoryError) {
            Timber.tag(TAG).w(e, "Out of memory composing disc")
            clearCache()
            null
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to compose disc")
            null
        }
    }

    private fun drawDisc(canvas: Canvas, r: Float, spec: DiscSpec, burn: Float, art: Bitmap?) {
        val c = r
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // The polycarbonate itself: faintly visible everywhere, clear at the rim.
        paint.color = Color.argb(71, 235, 240, 245)
        canvas.drawPath(annulus(c, c, r, HOLE * r), paint)

        // Data or printed area.
        canvas.save()
        val inner = if (spec.face == DiscFace.PRINTED) (HUB + 0.02f) * r else MIRROR * r
        canvas.clipPath(annulus(c, c, DATA_OUTER * r, inner))
        when (spec.face) {
            DiscFace.PRINTED -> {
                val usable = art?.takeIf { !it.isRecycled && it.width > 0 && it.height > 0 }
                if (usable != null) {
                    TurntableRenderer.drawArtCircle(canvas, c, c, r, usable)
                } else {
                    // No artwork: print the accent as a clean solid with a subtle vignette.
                    paint.shader = RadialGradient(
                        c, c, r,
                        intArrayOf(ColorMath.atLuminance(spec.accent, 0.8f), ColorMath.atLuminance(spec.accent, 0.62f)),
                        null, Shader.TileMode.CLAMP,
                    )
                    canvas.drawCircle(c, c, r, paint)
                    paint.shader = null
                }
            }
            DiscFace.CDR -> {
                paint.shader = RadialGradient(c, c, r, Color.rgb(230, 197, 107), Color.rgb(181, 138, 44), Shader.TileMode.CLAMP)
                canvas.drawCircle(c, c, r, paint)
                paint.shader = null
                // The burnt region, whose edge follows playback like a disc being written.
                val burnR = (MIRROR + (DATA_OUTER - MIRROR) * burn) * r
                paint.color = Color.argb(46, 90, 50, 10)
                canvas.drawCircle(c, c, burnR, paint)
                strokeCircle(canvas, c, c, burnR, max(1f, r * 0.006f), Color.argb(90, 70, 40, 10))
            }
            DiscFace.SILVER -> {
                paint.shader = RadialGradient(
                    c, c, r,
                    intArrayOf(Color.rgb(215, 219, 225), Color.rgb(191, 196, 204), Color.rgb(169, 174, 183)),
                    floatArrayOf(0.35f, 0.7f, 1f), Shader.TileMode.CLAMP,
                )
                canvas.drawCircle(c, c, r, paint)
                paint.shader = null
                for (f in floatArrayOf(0.52f, 0.71f, 0.88f)) {
                    strokeCircle(canvas, c, c, r * f, max(0.6f, r * 0.003f), Color.argb(46, 255, 255, 255))
                }
            }
        }
        canvas.restore()

        if (spec.face == DiscFace.PRINTED) {
            if (spec.title.isNotBlank()) {
                val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                    letterSpacing = 0.1f
                    textSize = r * 0.058f
                    color = Color.argb(235, 255, 255, 255)
                    setShadowLayer(r * 0.012f, 0f, 0f, Color.argb(140, 0, 0, 0))
                }
                TurntableRenderer.drawTextOnArc(canvas, spec.title.uppercase(), c, r * 0.9f, top = true, paint = text)
            }
            strokeCircle(canvas, c, c, DATA_OUTER * r, max(0.8f, r * 0.005f), Color.argb(128, 255, 255, 255))
        } else {
            // Mirror band with the etched matrix code.
            paint.shader = RadialGradient(
                c, c, MIRROR * r,
                intArrayOf(Color.rgb(238, 240, 243), Color.rgb(201, 205, 212)),
                floatArrayOf(HUB / MIRROR, 1f), Shader.TileMode.CLAMP,
            )
            canvas.drawPath(annulus(c, c, MIRROR * r, HUB * r), paint)
            paint.shader = null
            val code = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                typeface = Typeface.MONOSPACE
                textSize = r * 0.028f
                color = Color.argb(140, 60, 64, 72)
            }
            TurntableRenderer.drawTextOnArc(canvas, "PXL-0421 01 ◆ L901", c, r * 0.33f, top = false, paint = code)
        }

        // Clear hub: a hint of plastic, the stacking ring, and edge highlights.
        paint.color = Color.argb(56, 240, 244, 248)
        canvas.drawPath(annulus(c, c, HUB * r, HOLE * r), paint)
        strokeCircle(canvas, c, c, STACK_RING * r, max(0.8f, r * 0.006f), Color.argb(140, 255, 255, 255))
        strokeCircle(canvas, c, c, HOLE * r * 1.02f, max(0.6f, r * 0.004f), Color.argb(90, 255, 255, 255))
        strokeCircle(canvas, c, c, HUB * r, max(0.6f, r * 0.004f), Color.argb(90, 255, 255, 255))

        // Centre hole, then the outer edge.
        val clear = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
        canvas.drawCircle(c, c, HOLE * r, clear)
        strokeCircle(canvas, c, c, r * 0.997f, max(0.8f, r * 0.006f), Color.argb(153, 255, 255, 255))
    }

    // -------------------------------------------------------------------------------------
    // Underlay and overlay (fixed)
    // -------------------------------------------------------------------------------------

    /** Shadow, and for the case and portable player, everything behind the disc. */
    fun renderUnderlay(spec: DiscSpec): Bitmap? {
        val key = "under|${spec.sizePx}|${spec.presentation}|${spec.discScale}|${spec.accent}"
        layerCache.get(key)?.let { if (!it.isRecycled) return it }
        return layer(key, spec.sizePx) { canvas ->
            val s = spec.sizePx.toFloat()
            val p = spec.placement
            when (spec.presentation) {
                DiscPresentation.DISC, DiscPresentation.JEWEL_CASE ->
                    TurntableRenderer.drawDropShadow(canvas, p.centreX * s, p.centreY * s, p.radius * s)
                DiscPresentation.PORTABLE -> drawPortableBody(canvas, s, spec.accent)
            }
        }
    }

    /** Reflections over the disc; the case front or player lid when there is one. */
    fun renderOverlay(spec: DiscSpec, artwork: () -> Bitmap?): Bitmap? {
        val key = "over|${spec.sizePx}|${spec.face}|${spec.presentation}|${spec.discScale}|" +
            (if (spec.presentation == DiscPresentation.JEWEL_CASE) spec.artworkKey else "")
        layerCache.get(key)?.let { if (!it.isRecycled) return it }
        return layer(key, spec.sizePx) { canvas ->
            val s = spec.sizePx.toFloat()
            val p = spec.placement
            val cx = p.centreX * s
            val cy = p.centreY * s
            val r = p.radius * s
            drawLight(canvas, cx, cy, r, spec.face)
            when (spec.presentation) {
                DiscPresentation.JEWEL_CASE -> drawJewelCase(canvas, s, artwork())
                DiscPresentation.PORTABLE -> drawPortableLid(canvas, cx, cy, r)
                DiscPresentation.DISC -> Unit
            }
        }
    }

    /**
     * Light on the disc. The playing side splits it into a spectrum: two opposite fans of
     * colour (screen-blended, so they brighten rather than paint over), fainter crossing fans,
     * and a thin white specular streak. The printed side is just glossy.
     */
    private fun drawLight(canvas: Canvas, cx: Float, cy: Float, r: Float, face: DiscFace) {
        if (face == DiscFace.PRINTED) {
            canvas.save()
            canvas.clipPath(annulus(cx, cy, DATA_OUTER * r, HUB * r))
            TurntableRenderer.fillSweep(
                canvas, cx, cy, r,
                floatArrayOf(0f, 0.09f, 0.125f, 0.16f, 0.59f, 0.625f, 0.66f, 1f),
                floatArrayOf(0f, 0f, 0.16f, 0f, 0f, 0.16f, 0f, 0f),
            )
            canvas.restore()
            return
        }
        canvas.save()
        canvas.clipPath(annulus(cx, cy, DATA_OUTER * r, MIRROR * r))
        val screen = Paint(Paint.ANTI_ALIAS_FLAG).apply { blendMode = BlendMode.SCREEN }
        for ((centre, width, strength) in listOf(
            Triple(0.125f, 0.16f, 0.85f), Triple(0.625f, 0.16f, 0.85f),
            Triple(0.375f, 0.10f, 0.35f), Triple(0.875f, 0.10f, 0.35f),
        )) {
            screen.shader = spectrumFan(cx, cy, centre, width, strength)
            canvas.drawCircle(cx, cy, r, screen)
        }
        TurntableRenderer.fillSweep(
            canvas, cx, cy, r,
            floatArrayOf(0f, 0.115f, 0.125f, 0.135f, 0.615f, 0.625f, 0.635f, 1f),
            floatArrayOf(0f, 0f, 0.35f, 0f, 0f, 0.35f, 0f, 0f),
        )
        canvas.restore()
    }

    /** A sweep that is transparent except for a rainbow fan centred at [centre] (0..1 of a turn). */
    private fun spectrumFan(cx: Float, cy: Float, centre: Float, width: Float, strength: Float): SweepGradient {
        val hues = floatArrayOf(0f, 45f, 90f, 150f, 200f, 260f, 310f)
        val start = centre - width / 2f
        val positions = ArrayList<Float>()
        val colors = ArrayList<Int>()
        positions += 0f; colors += Color.TRANSPARENT
        positions += (start - 0.01f).coerceIn(0.0001f, 0.9998f); colors += Color.TRANSPARENT
        hues.forEachIndexed { i, hue ->
            val t = (start + width * i / (hues.size - 1)).coerceIn(0.0002f, 0.9998f)
            val a = strength * sin(Math.PI * i / (hues.size - 1)).toFloat()
            positions += t
            colors += ColorMath.withAlpha(Color.HSVToColor(floatArrayOf(hue, 0.85f, 1f)), a)
        }
        positions += (start + width + 0.01f).coerceIn(0.0003f, 0.9999f); colors += Color.TRANSPARENT
        positions += 1f; colors += Color.TRANSPARENT
        // SweepGradient needs strictly non-decreasing positions.
        for (i in 1 until positions.size) if (positions[i] < positions[i - 1]) positions[i] = positions[i - 1]
        return SweepGradient(cx, cy, colors.toIntArray(), positions.toFloatArray())
    }

    /**
     * A jewel case lying bottom-left, with the album art as its front insert, a ridged hinge
     * spine and a diagonal glare. It is drawn over the disc, which peeks out of its top right.
     */
    private fun drawJewelCase(canvas: Canvas, s: Float, art: Bitmap?) {
        val left = s * 0.05f
        val top = s * 0.27f
        val size = s * 0.66f
        val rect = RectF(left, top, left + size, top + size)
        val corner = s * 0.018f

        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(100, 0, 0, 0)
            maskFilter = android.graphics.BlurMaskFilter(max(1f, s * 0.02f), android.graphics.BlurMaskFilter.Blur.NORMAL)
        }
        canvas.drawRoundRect(RectF(rect.left + s * 0.01f, rect.top + s * 0.018f, rect.right + s * 0.01f, rect.bottom + s * 0.018f), corner, corner, shadow)

        // Case body (clear plastic over a black tray).
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(24, 24, 28) }
        canvas.drawRoundRect(rect, corner, corner, body)

        // Insert: album art, inset from the case edge and right of the spine.
        val spine = size * 0.085f
        val insert = RectF(rect.left + spine, rect.top + size * 0.03f, rect.right - size * 0.03f, rect.bottom - size * 0.03f)
        val usable = art?.takeIf { !it.isRecycled && it.width > 0 && it.height > 0 }
        if (usable != null) {
            val scale = max(insert.width() / usable.width, insert.height() / usable.height)
            val matrix = Matrix().apply {
                setScale(scale, scale)
                postTranslate(insert.centerX() - usable.width * scale / 2f, insert.centerY() - usable.height * scale / 2f)
            }
            val artPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                shader = android.graphics.BitmapShader(usable, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).apply { setLocalMatrix(matrix) }
            }
            canvas.drawRect(insert, artPaint)
        } else {
            canvas.drawRect(insert, Paint().apply { color = Color.rgb(60, 60, 70) })
        }

        // Hinge spine with ridges.
        val ridge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 255, 255, 255); strokeWidth = max(1f, s * 0.003f) }
        var y = rect.top + size * 0.05f
        while (y < rect.bottom - size * 0.05f) {
            canvas.drawLine(rect.left + spine * 0.25f, y, rect.left + spine * 0.75f, y, ridge)
            y += size * 0.035f
        }

        // Clear lid: edge highlight and a diagonal glare band.
        strokeRoundRect(canvas, rect, corner, max(1f, s * 0.004f), Color.argb(110, 255, 255, 255))
        canvas.save()
        canvas.clipRect(rect)
        val glare = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                rect.left, rect.top, rect.right, rect.bottom,
                intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(46, 255, 255, 255), Color.argb(0, 255, 255, 255), Color.argb(20, 255, 255, 255), Color.argb(0, 255, 255, 255)),
                floatArrayOf(0.2f, 0.32f, 0.44f, 0.62f, 0.7f),
                Shader.TileMode.CLAMP,
            )
        }
        canvas.drawRect(rect, glare)
        canvas.restore()
    }

    /** A round portable player: body, an accent ring and a row of moulded buttons. */
    private fun drawPortableBody(canvas: Canvas, s: Float, accent: Int) {
        val cx = s / 2f
        val cy = s * 0.47f
        val r = s * 0.46f
        TurntableRenderer.drawDropShadow(canvas, cx, cy, r)
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(cx - r * 0.3f, cy - r * 0.35f, r * 1.5f, Color.rgb(214, 217, 223), Color.rgb(142, 147, 156), Shader.TileMode.CLAMP)
        }
        canvas.drawCircle(cx, cy, r, body)
        strokeCircle(canvas, cx, cy, r * 0.985f, max(1f, s * 0.004f), Color.argb(120, 255, 255, 255))
        // Recessed well the disc spins in.
        val well = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(34, 35, 40) }
        canvas.drawCircle(cx, cy, r * 0.76f, well)
        strokeCircle(canvas, cx, cy, r * 0.79f, max(1f, s * 0.006f), ColorMath.withAlpha(accent, 0.9f))
        // Moulded button row along the bottom edge (decorative; the real controls are bubbles).
        val button = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(96, 100, 108) }
        for (i in -2..2) {
            val bx = cx + i * r * 0.16f
            canvas.drawRoundRect(RectF(bx - r * 0.06f, cy + r * 0.84f, bx + r * 0.06f, cy + r * 0.9f), r * 0.02f, r * 0.02f, button)
        }
    }

    /** The smoked lid over the disc: a tint, a curved reflection and the lid's rim. */
    private fun drawPortableLid(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        val lidR = r * 1.1f
        val tint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(40, 20, 22, 30) }
        canvas.drawCircle(cx, cy, lidR, tint)
        canvas.save()
        canvas.clipPath(Path().apply { addCircle(cx, cy, lidR, Path.Direction.CW) })
        val sheen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(cx - lidR, cy - lidR, cx + lidR * 0.2f, cy + lidR * 0.2f, Color.argb(56, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        }
        canvas.drawOval(RectF(cx - lidR * 1.3f, cy - lidR * 1.6f, cx + lidR * 0.5f, cy + lidR * 0.1f), sheen)
        canvas.restore()
        strokeCircle(canvas, cx, cy, lidR, max(1f, r * 0.012f), Color.argb(120, 255, 255, 255))
    }

    // -------------------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------------------

    private fun annulus(cx: Float, cy: Float, outer: Float, inner: Float): Path = Path().apply {
        fillType = Path.FillType.EVEN_ODD
        addCircle(cx, cy, outer, Path.Direction.CW)
        addCircle(cx, cy, inner, Path.Direction.CW)
    }

    private fun strokeCircle(canvas: Canvas, cx: Float, cy: Float, r: Float, width: Float, color: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = width
            this.color = color
        }
        canvas.drawCircle(cx, cy, r, paint)
    }

    private fun strokeRoundRect(canvas: Canvas, rect: RectF, corner: Float, width: Float, color: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = width
            this.color = color
        }
        canvas.drawRoundRect(rect, corner, corner, paint)
    }

    private inline fun layer(key: String, size: Int, block: (Canvas) -> Unit): Bitmap? = try {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        block(Canvas(bitmap))
        layerCache.put(key, bitmap)
        bitmap
    } catch (e: OutOfMemoryError) {
        Timber.tag(TAG).w(e, "Out of memory composing disc layer")
        layerCache.evictAll()
        null
    } catch (e: Exception) {
        Timber.tag(TAG).e(e, "Failed to compose disc layer")
        null
    }

    private const val TAG = "DiscRenderer"
}
