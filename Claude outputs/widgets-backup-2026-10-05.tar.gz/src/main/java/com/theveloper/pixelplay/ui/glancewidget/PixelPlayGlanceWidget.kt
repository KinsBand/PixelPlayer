package com.theveloper.pixelplay.ui.glancewidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.ColorFilter
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalContext
import androidx.glance.LocalSize
import androidx.glance.action.actionParametersOf
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.currentState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.ColumnScope
import androidx.glance.layout.ContentScale
import androidx.glance.layout.Row
import androidx.glance.layout.RowScope
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.theveloper.pixelplay.MainActivity
import com.theveloper.pixelplay.R
import com.theveloper.pixelplay.data.model.PlayerInfo
import com.theveloper.pixelplay.data.model.QueueItem
import com.theveloper.pixelplay.data.preferences.WidgetAppearance
import com.theveloper.pixelplay.data.preferences.WidgetConfig
import com.theveloper.pixelplay.data.preferences.WidgetContentOptions
import com.theveloper.pixelplay.data.preferences.WidgetKind
import com.theveloper.pixelplay.ui.glancewidget.WidgetLayoutMath.TransportSlot
import kotlin.math.max

/**
 * The adaptive player: one widget that picks among eleven layouts by cell size.
 *
 * Every layout honours the same settings the other widgets do. Background (solid, transparent
 * or outlined) is applied with each layout's own corner radius, so the 1x1 circle stays a
 * circle. Buttons take the accent source's colours instead of always following the system
 * theme. Title, artist, previous/next, favourite, shuffle, repeat and progress all appear
 * wherever the layout has room for them; when a layout is too small for something that is
 * switched on, it is left out in the same fixed order everywhere
 * ([WidgetLayoutMath.planTransport]), and the settings screen says so.
 */
class PixelPlayGlanceWidget : GlanceAppWidget() {

    companion object {
        private val VERY_THIN_LAYOUT_SIZE = DpSize(width = 200.dp, height = 60.dp)
        private val THIN_LAYOUT_SIZE = DpSize(width = 250.dp, height = 80.dp)
        private val ONE_BY_ONE_LAYOUT_SIZE = DpSize(width = 110.dp, height = 110.dp)
        private val GABE_TWO_HEIGHT_LAYOUT_SIZE = DpSize(width = 110.dp, height = 200.dp)
        private val SMALL_LAYOUT_SIZE = DpSize(width = 120.dp, height = 100.dp)
        private val MEDIUM_LAYOUT_SIZE = DpSize(width = 250.dp, height = 150.dp)
        private val LARGE_LAYOUT_SIZE = DpSize(width = 300.dp, height = 180.dp)
        private val EXTRA_LARGE_LAYOUT_SIZE = DpSize(width = 300.dp, height = 220.dp)

        /** Smallest a transport button may get before it is dropped instead of squeezed. */
        private val MIN_BUTTON = 40.dp

        /** Width kept for title and artist before any extra button is offered room. */
        private val THIN_TEXT_RESERVE = 88.dp
    }

    override val sizeMode = SizeMode.Exact
    override val stateDefinition = PlayerInfoStateDefinition

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val initial = loadWidgetConfig(context, WidgetKind.ADAPTIVE)
        provideContent {
            val config = rememberWidgetConfig(context, WidgetKind.ADAPTIVE, initial)
            val playerInfo = currentState<PlayerInfo>()
            GlanceTheme {
                WidgetUi(
                    playerInfo = playerInfo,
                    size = LocalSize.current,
                    context = context,
                    config = config
                )
            }
        }
    }

    /** Everything a layout needs, gathered once. */
    private class Style(
        val context: Context,
        val playerInfo: PlayerInfo,
        val content: WidgetContentOptions,
        val colors: WidgetColors,
        val transport: TransportColors,
        val appearance: WidgetAppearance,
        val outlineColor: Int,
        val size: DpSize,
    ) {
        val title: String = playerInfo.songTitle.ifEmpty { context.getString(R.string.app_name) }
        val artist: String = playerInfo.artistName.ifEmpty { context.getString(R.string.widget_tap_to_open) }
        val textColor: ColorProvider get() = colors.onSurface
        val artistColor: ColorProvider get() = colors.artist
    }

    @Composable
    private fun WidgetUi(
        playerInfo: PlayerInfo,
        size: DpSize,
        context: Context,
        config: WidgetConfig
    ) {
        val colors = playerInfo.getWidgetColors(config.appearance)
        val style = Style(
            context = context,
            playerInfo = playerInfo,
            content = config.effectiveContent,
            colors = colors,
            transport = colors.transportColors(),
            appearance = config.appearance,
            outlineColor = outlineColorFor(context, config.appearance, playerInfo),
            size = size,
        )

        val baseModifier = GlanceModifier
            .fillMaxSize()
            .clickable(actionStartActivity<MainActivity>())

        Box(GlanceModifier.fillMaxSize()) {
            val isOneColumn = size.width < SMALL_LAYOUT_SIZE.width
            val isSmallHeight = size.height < SMALL_LAYOUT_SIZE.height

            if (isOneColumn) {
                when {
                    size.height <= ONE_BY_ONE_LAYOUT_SIZE.height ->
                        OneByOneWidgetLayout(baseModifier, style, bgCornerRadius = 60.dp)
                    size.height <= GABE_TWO_HEIGHT_LAYOUT_SIZE.height ->
                        GabeTwoHeightWidgetLayout(baseModifier, style, bgCornerRadius = 60.dp)
                    else -> GabeWidgetLayout(baseModifier, style, bgCornerRadius = 360.dp)
                }
            } else if (isSmallHeight) {
                when {
                    size.width < VERY_THIN_LAYOUT_SIZE.width ->
                        SmallHorizontalWidgetLayout(baseModifier, style, bgCornerRadius = 60.dp)
                    size.width < THIN_LAYOUT_SIZE.width ->
                        ThinWidgetLayout(baseModifier, style, bgCornerRadius = 60.dp, artGap = 10.dp)
                    else -> ThinWidgetLayout(baseModifier, style, bgCornerRadius = 60.dp, artGap = 14.dp)
                }
            } else {
                when {
                    size.width < MEDIUM_LAYOUT_SIZE.width || size.height < MEDIUM_LAYOUT_SIZE.height ->
                        SmallWidgetLayout(baseModifier, style, bgCornerRadius = 28.dp)
                    size.width < LARGE_LAYOUT_SIZE.width || size.height < LARGE_LAYOUT_SIZE.height ->
                        DetailWidgetLayout(baseModifier, style, bgCornerRadius = 28.dp, variant = Detail.MEDIUM)
                    size.width < EXTRA_LARGE_LAYOUT_SIZE.width || size.height < EXTRA_LARGE_LAYOUT_SIZE.height ->
                        DetailWidgetLayout(baseModifier, style, bgCornerRadius = 28.dp, variant = Detail.LARGE)
                    else -> ExtraLargeWidgetLayout(baseModifier, style, bgCornerRadius = 28.dp)
                }
            }
        }
    }

    // -------------------------------------------------------------------------------------
    // Shared pieces
    // -------------------------------------------------------------------------------------

    /** The chosen background style, with this layout's own corner radius. */
    @Composable
    private fun GlanceModifier.surface(style: Style, radius: Dp): GlanceModifier =
        widgetSurface(
            context = style.context,
            appearance = style.appearance,
            colors = style.colors,
            outlineColor = style.outlineColor,
            size = style.size,
            radiusOverride = radius,
        )

    /** Title and artist, each only if switched on. Renders nothing when both are off. */
    @Composable
    private fun TrackText(
        style: Style,
        titleSize: Int,
        artistSize: Int,
        titleLines: Int = 1,
        artistLines: Int = 1,
        gap: Dp = 0.dp,
        hideArtistPlaceholder: Boolean = false,
    ) {
        if (style.content.showTitle) {
            Text(
                text = style.title,
                style = TextStyle(fontSize = titleSize.sp, fontWeight = FontWeight.Bold, color = style.textColor),
                maxLines = titleLines
            )
        }
        val artistIsPlaceholder = style.playerInfo.artistName.isEmpty()
        if (style.content.showArtist && !(hideArtistPlaceholder && artistIsPlaceholder)) {
            if (style.content.showTitle && gap > 0.dp) Spacer(GlanceModifier.height(gap))
            Text(
                text = style.artist,
                style = TextStyle(fontSize = artistSize.sp, color = style.artistColor),
                maxLines = artistLines
            )
        }
    }

    /** One transport button in the adaptive player's own style (outlined glyphs). */
    @Composable
    private fun SlotButton(
        style: Style,
        slot: TransportSlot,
        modifier: GlanceModifier,
        cornerRadius: Dp,
        playCornerRadius: Dp,
        iconSize: Dp,
        playIconSize: Dp = iconSize,
    ) {
        val t = style.transport
        val info = style.playerInfo
        when (slot) {
            TransportSlot.PLAY -> PlayPauseButtonGlance(
                modifier = modifier,
                isPlaying = info.isPlaying,
                backgroundColor = t.play,
                iconColor = t.onPlay,
                iconSize = playIconSize,
                cornerRadius = playCornerRadius
            )
            TransportSlot.PREVIOUS -> PreviousButtonGlance(
                modifier = modifier,
                backgroundColor = t.button,
                iconColor = t.onButton,
                iconSize = iconSize,
                cornerRadius = cornerRadius
            )
            TransportSlot.NEXT -> NextButtonGlance(
                modifier = modifier,
                backgroundColor = t.button,
                iconColor = t.onButton,
                iconSize = iconSize,
                cornerRadius = cornerRadius
            )
            else -> TransportButton(
                slot = slot,
                playerInfo = info,
                colors = t,
                cornerRadius = cornerRadius,
                iconSize = iconSize,
                modifier = modifier,
            )
        }
    }

    /**
     * A horizontal row of [slots], each in an equally weighted cell. Half the gap is padding
     * on each cell rather than a spacer, so six buttons stay within Glance's ten-child limit.
     */
    @Composable
    private fun RowScope.SlotCells(
        style: Style,
        slots: List<TransportSlot>,
        gap: Dp,
        cornerRadius: Dp,
        playCornerRadius: Dp,
        iconSize: Dp,
        playIconSize: Dp = iconSize,
    ) {
        slots.forEach { slot ->
            Box(
                modifier = GlanceModifier.defaultWeight().fillMaxHeight().padding(horizontal = gap / 2),
                contentAlignment = Alignment.Center
            ) {
                SlotButton(style, slot, GlanceModifier.fillMaxSize(), cornerRadius, playCornerRadius, iconSize, playIconSize)
            }
        }
    }

    /** The vertical counterpart of [SlotCells], for the one-column layouts. */
    @Composable
    private fun ColumnScope.SlotCellsVertical(
        style: Style,
        slots: List<TransportSlot>,
        gap: Dp,
        cornerRadius: Dp,
        playCornerRadius: Dp,
        iconSize: Dp,
    ) {
        slots.forEach { slot ->
            Box(
                modifier = GlanceModifier.defaultWeight().fillMaxWidth().padding(vertical = gap / 2),
                contentAlignment = Alignment.Center
            ) {
                SlotButton(style, slot, GlanceModifier.fillMaxSize(), cornerRadius, playCornerRadius, iconSize)
            }
        }
    }

    /** Slots for a row of [width], all of the user's switches considered. */
    private fun planFor(style: Style, width: Dp, includeFavorite: Boolean): List<TransportSlot> =
        WidgetLayoutMath.planTransport(
            prevNext = style.content.showPrevNext,
            shuffle = style.content.showShuffle,
            repeat = style.content.showRepeat,
            favorite = includeFavorite && style.content.showFavorite,
            maxSlots = WidgetLayoutMath.slotsThatFit(width.value, MIN_BUTTON.value, 8f),
        )

    /** A small heart beside the title, in the layouts that have a title row. */
    @Composable
    private fun InlineFavorite(style: Style, size: Dp = 28.dp) {
        val info = style.playerInfo
        Image(
            provider = ImageProvider(favoriteIconRes(info.isFavorite)),
            contentDescription = style.context.getString(
                if (info.isFavorite) R.string.widget_turntable_unfavorite_cd
                else R.string.widget_turntable_favorite_cd
            ),
            modifier = GlanceModifier
                .size(size)
                .padding(2.dp)
                .clickable(
                    actionRunCallback<PlayerControlActionCallback>(
                        actionParametersOf(PlayerActions.key to PlayerActions.FAVORITE)
                    )
                ),
            colorFilter = ColorFilter.tint(style.textColor)
        )
    }

    // -------------------------------------------------------------------------------------
    // One column
    // -------------------------------------------------------------------------------------

    /** 1x1: a single play button. There is room for nothing else. */
    @Composable
    private fun OneByOneWidgetLayout(modifier: GlanceModifier, style: Style, bgCornerRadius: Dp) {
        Box(
            modifier = modifier.surface(style, bgCornerRadius).padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            PlayPauseButtonGlance(
                modifier = GlanceModifier.fillMaxSize(),
                backgroundColor = style.transport.play,
                iconColor = style.transport.onPlay,
                isPlaying = style.playerInfo.isPlaying,
                iconSize = 36.dp,
                cornerRadius = 30.dp
            )
        }
    }

    /** 1x2: artwork over play and next. */
    @Composable
    private fun GabeTwoHeightWidgetLayout(modifier: GlanceModifier, style: Style, bgCornerRadius: Dp) {
        val slots = if (style.content.showPrevNext) {
            listOf(TransportSlot.PLAY, TransportSlot.NEXT)
        } else {
            listOf(TransportSlot.PLAY)
        }
        Box(modifier = modifier.surface(style, bgCornerRadius).padding(16.dp)) {
            Column(
                modifier = GlanceModifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalAlignment = Alignment.Vertical.CenterVertically
            ) {
                AlbumArtImageGlance(
                    modifier = GlanceModifier.defaultWeight().height(48.dp),
                    bitmapData = style.playerInfo.albumArtBitmapData,
                    albumArtUri = style.playerInfo.albumArtUri,
                    context = style.context,
                    cornerRadius = 64.dp
                )
                Spacer(GlanceModifier.height(14.dp))
                Column(modifier = GlanceModifier.defaultWeight()) {
                    SlotCellsVertical(style, slots, gap = 10.dp, cornerRadius = 10.dp, playCornerRadius = 10.dp, iconSize = 26.dp)
                }
            }
        }
    }

    /** 1x3 and taller: artwork over a column of controls, as many as fit. */
    @Composable
    private fun GabeWidgetLayout(modifier: GlanceModifier, style: Style, bgCornerRadius: Dp) {
        val controlsHeight = (style.size.height - 32.dp - 14.dp) / 2
        val slots = planFor(style, controlsHeight, includeFavorite = true)
        Box(modifier = modifier.surface(style, bgCornerRadius).padding(16.dp)) {
            Column(
                modifier = GlanceModifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalAlignment = Alignment.Vertical.CenterVertically
            ) {
                AlbumArtImageGlance(
                    modifier = GlanceModifier.defaultWeight().fillMaxWidth().height(48.dp),
                    bitmapData = style.playerInfo.albumArtBitmapData,
                    albumArtUri = style.playerInfo.albumArtUri,
                    context = style.context,
                    cornerRadius = 64.dp
                )
                Spacer(GlanceModifier.height(14.dp))
                Column(modifier = GlanceModifier.defaultWeight()) {
                    SlotCellsVertical(style, slots, gap = 10.dp, cornerRadius = 10.dp, playCornerRadius = 10.dp, iconSize = 26.dp)
                }
            }
        }
    }

    // -------------------------------------------------------------------------------------
    // Short and wide
    // -------------------------------------------------------------------------------------

    /** 2x1: artwork and play. */
    @Composable
    private fun SmallHorizontalWidgetLayout(modifier: GlanceModifier, style: Style, bgCornerRadius: Dp) {
        Box(modifier = modifier.surface(style, bgCornerRadius).padding(16.dp)) {
            Row(
                modifier = GlanceModifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalAlignment = Alignment.Horizontal.CenterHorizontally
            ) {
                AlbumArtImageGlance(
                    modifier = GlanceModifier.padding(vertical = 6.dp),
                    bitmapData = style.playerInfo.albumArtBitmapData,
                    albumArtUri = style.playerInfo.albumArtUri,
                    size = 58.dp,
                    context = style.context,
                    cornerRadius = 64.dp
                )
                Spacer(GlanceModifier.width(14.dp))
                PlayPauseButtonGlance(
                    modifier = GlanceModifier.defaultWeight().fillMaxHeight(),
                    backgroundColor = style.transport.play,
                    iconColor = style.transport.onPlay,
                    isPlaying = style.playerInfo.isPlaying,
                    iconSize = 26.dp,
                    cornerRadius = 10.dp
                )
            }
        }
    }

    /**
     * 3x1 and 4x1: artwork, text, then as many controls as fit. Used to be two near-identical
     * layouts differing only in the gap after the artwork.
     */
    @Composable
    private fun ThinWidgetLayout(modifier: GlanceModifier, style: Style, bgCornerRadius: Dp, artGap: Dp) {
        val albumArtSize = style.size.height - 32.dp
        val showText = style.content.showTitle || style.content.showArtist
        val controlsWidth = style.size.width - 32.dp - albumArtSize - artGap - 8.dp -
            (if (showText) THIN_TEXT_RESERVE else 0.dp)
        // This layout has always shown play and next even at its narrowest; previous joins
        // only once there is room for all three, so the row never loses "next" to it.
        val fit = max(2, WidgetLayoutMath.slotsThatFit(controlsWidth.value, 48f, 10f))
        val plan = WidgetLayoutMath.planTransport(
            prevNext = style.content.showPrevNext,
            shuffle = style.content.showShuffle,
            repeat = style.content.showRepeat,
            favorite = style.content.showFavorite,
            maxSlots = fit + if (style.content.showPrevNext) 1 else 0,
        )
        val shown = if (plan.size > fit) plan - TransportSlot.PREVIOUS else plan
        val rowWidth = 48.dp * shown.size + 10.dp * shown.size

        Box(modifier = modifier.surface(style, bgCornerRadius).padding(16.dp)) {
            Row(
                modifier = GlanceModifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalAlignment = Alignment.Horizontal.CenterHorizontally
            ) {
                AlbumArtImageGlance(
                    modifier = GlanceModifier.size(albumArtSize),
                    bitmapData = style.playerInfo.albumArtBitmapData,
                    albumArtUri = style.playerInfo.albumArtUri,
                    context = style.context,
                    cornerRadius = bgCornerRadius
                )
                Spacer(GlanceModifier.width(artGap))
                Column(modifier = GlanceModifier.defaultWeight()) {
                    TrackText(style, titleSize = 16, artistSize = 14, hideArtistPlaceholder = true)
                }
                Spacer(GlanceModifier.width(8.dp))
                Row(
                    modifier = GlanceModifier.width(rowWidth).height(48.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SlotCells(style, shown, gap = 10.dp, cornerRadius = 10.dp, playCornerRadius = 10.dp, iconSize = 26.dp)
                }
            }
        }
    }

    // -------------------------------------------------------------------------------------
    // Two rows and up
    // -------------------------------------------------------------------------------------

    /** 2x2: artwork, a wide play button, then previous and next. */
    @Composable
    private fun SmallWidgetLayout(modifier: GlanceModifier, style: Style, bgCornerRadius: Dp) {
        val playerInfo = style.playerInfo
        val playButtonCornerRadius = if (playerInfo.isPlaying) 12.dp else 60.dp
        Box(modifier = modifier.surface(style, bgCornerRadius).padding(12.dp)) {
            Column(
                modifier = GlanceModifier.fillMaxSize(),
                verticalAlignment = Alignment.Top,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(modifier = GlanceModifier.defaultWeight().fillMaxWidth()) {
                    AlbumArtImageGlance(
                        modifier = GlanceModifier.fillMaxSize(),
                        bitmapData = playerInfo.albumArtBitmapData,
                        albumArtUri = playerInfo.albumArtUri,
                        context = style.context,
                        cornerRadius = 64.dp
                    )
                    if (style.content.showFavorite) {
                        Positioned(alignment = Alignment.TopEnd) {
                            FavoriteButton(
                                modifier = GlanceModifier.size(26.dp),
                                isFavorite = playerInfo.isFavorite,
                                backgroundColor = style.transport.button,
                                iconColor = style.transport.onButton,
                                cornerRadius = 13.dp,
                                iconSize = 15.dp,
                            )
                        }
                    }
                }
                Spacer(GlanceModifier.height(8.dp))
                PlayPauseButtonGlance(
                    modifier = GlanceModifier.defaultWeight().fillMaxWidth().height(50.dp),
                    isPlaying = playerInfo.isPlaying,
                    cornerRadius = playButtonCornerRadius,
                    iconSize = 26.dp,
                    backgroundColor = style.transport.play,
                    iconColor = style.transport.onPlay
                )
                if (style.content.showPrevNext) {
                    Spacer(GlanceModifier.height(8.dp))
                    Row(
                        modifier = GlanceModifier.defaultWeight().fillMaxWidth().height(50.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        SlotCells(
                            style,
                            listOf(TransportSlot.PREVIOUS, TransportSlot.NEXT),
                            gap = 8.dp,
                            cornerRadius = 16.dp,
                            playCornerRadius = 16.dp,
                            iconSize = 26.dp,
                        )
                    }
                }
            }
        }
    }

    private enum class Detail { MEDIUM, LARGE }

    /**
     * 3x2 and 4x2: artwork and details on top, optional progress, then a full row of controls.
     * Medium and large were two copies of this with different type sizes.
     */
    @Composable
    private fun DetailWidgetLayout(modifier: GlanceModifier, style: Style, bgCornerRadius: Dp, variant: Detail) {
        val playerInfo = style.playerInfo
        val large = variant == Detail.LARGE
        val artSize = if (large) 64.dp else 80.dp
        val innerWidth = style.size.width - 32.dp
        val slots = planFor(style, innerWidth, includeFavorite = false)
        val playButtonCornerRadius = if (playerInfo.isPlaying) 14.dp else 60.dp

        Box(modifier = modifier.surface(style, bgCornerRadius).padding(16.dp)) {
            Column(modifier = GlanceModifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(
                    modifier = GlanceModifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AlbumArtImageGlance(
                        bitmapData = playerInfo.albumArtBitmapData,
                        albumArtUri = playerInfo.albumArtUri,
                        size = artSize,
                        context = style.context,
                        cornerRadius = if (large) 18.dp else 16.dp
                    )
                    Spacer(GlanceModifier.width(12.dp))
                    Column(modifier = GlanceModifier.defaultWeight()) {
                        TrackText(
                            style,
                            titleSize = 16,
                            artistSize = 13,
                            titleLines = if (large) 1 else 2,
                            artistLines = if (large) 1 else 2,
                            gap = if (large) 0.dp else 4.dp,
                        )
                    }
                    if (style.content.showFavorite) {
                        Spacer(GlanceModifier.width(4.dp))
                        InlineFavorite(style)
                    }
                }

                WidgetProgressBar(
                    context = style.context,
                    appearance = style.appearance,
                    playerInfo = playerInfo,
                    style = style.content.progressStyle,
                    widthDp = innerWidth
                )
                Spacer(GlanceModifier.height(12.dp))

                Row(
                    modifier = GlanceModifier.defaultWeight().fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SlotCells(
                        style,
                        slots,
                        gap = 8.dp,
                        cornerRadius = 60.dp,
                        playCornerRadius = playButtonCornerRadius,
                        iconSize = 24.dp,
                    )
                }
            }
        }
    }

    /** 4x3 and up: details, controls, then the next few tracks in the queue. */
    @Composable
    private fun ExtraLargeWidgetLayout(modifier: GlanceModifier, style: Style, bgCornerRadius: Dp) {
        val playerInfo = style.playerInfo
        val context = style.context
        val playButtonCornerRadius = if (playerInfo.isPlaying) 16.dp else 60.dp
        val innerWidth = style.size.width - 32.dp
        val slots = planFor(style, innerWidth, includeFavorite = false)

        Box(modifier = modifier.surface(style, bgCornerRadius).padding(16.dp)) {
            Column(modifier = GlanceModifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = GlanceModifier.fillMaxWidth()
                ) {
                    AlbumArtImageGlance(
                        bitmapData = playerInfo.albumArtBitmapData,
                        albumArtUri = playerInfo.albumArtUri,
                        size = 68.dp,
                        context = context,
                        cornerRadius = 16.dp
                    )
                    Spacer(GlanceModifier.width(16.dp))
                    Column(modifier = GlanceModifier.defaultWeight()) {
                        TrackText(style, titleSize = 20, artistSize = 16, titleLines = 2)
                    }
                    if (style.content.showFavorite) {
                        Spacer(GlanceModifier.width(4.dp))
                        InlineFavorite(style, size = 32.dp)
                    }
                }

                WidgetProgressBar(
                    context = context,
                    appearance = style.appearance,
                    playerInfo = playerInfo,
                    style = style.content.progressStyle,
                    widthDp = innerWidth
                )
                Spacer(GlanceModifier.height(14.dp))

                Row(
                    modifier = GlanceModifier.defaultWeight().fillMaxWidth().height(56.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SlotCells(
                        style,
                        slots,
                        gap = 10.dp,
                        cornerRadius = 60.dp,
                        playCornerRadius = playButtonCornerRadius,
                        iconSize = 28.dp,
                        playIconSize = 30.dp,
                    )
                }

                Spacer(GlanceModifier.defaultWeight())

                Box(
                    modifier = GlanceModifier
                        .fillMaxWidth()
                        .padding(horizontal = 30.dp)
                        .background(style.textColor.getColor(context).copy(alpha = 0.15f))
                        .height(2.dp)
                        .cornerRadius(60.dp)
                ) {}

                Spacer(GlanceModifier.height(12.dp))

                QueueRow(style, playerInfo.queue)
            }
        }
    }

    @Composable
    private fun QueueRow(style: Style, queue: List<QueueItem>) {
        Row(
            modifier = GlanceModifier.fillMaxWidth().height(58.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val items = queue.take(4)
            val itemSize = 58.dp
            val cornerRadius = 14.dp
            for (i in 0 until 4) {
                Box(
                    modifier = GlanceModifier.defaultWeight().padding(horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (i < items.size) {
                        val queueItem = items[i]
                        AlbumArtImageGlance(
                            modifier = GlanceModifier.clickable(
                                actionRunCallback<PlayerControlActionCallback>(
                                    actionParametersOf(
                                        PlayerActions.key to PlayerActions.PLAY_FROM_QUEUE,
                                        PlayerActions.songIdKey to queueItem.id
                                    )
                                )
                            ),
                            bitmapData = null,
                            albumArtUri = queueItem.albumArtUri,
                            size = itemSize,
                            context = style.context,
                            cornerRadius = cornerRadius
                        )
                    } else {
                        EndOfQueuePlaceholder(size = itemSize, cornerRadius = cornerRadius)
                    }
                }
            }
        }
    }

    // -------------------------------------------------------------------------------------
    // Primitives
    // -------------------------------------------------------------------------------------

    @Composable
    fun AlbumArtImageGlance(
        bitmapData: ByteArray?,
        albumArtUri: String? = null,
        size: Dp? = null,
        context: Context,
        modifier: GlanceModifier = GlanceModifier,
        cornerRadius: Dp = 16.dp
    ) {
        val sizingModifier = if (size != null) modifier.size(size) else modifier
        val widgetDpSize = LocalSize.current

        val imageProvider = bitmapData?.let { data ->
            val cacheKey = AlbumArtBitmapCache.getKey(data)
            var bitmap = AlbumArtBitmapCache.getBitmap(cacheKey)

            if (bitmap == null) {
                try {
                    val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(data, 0, data.size, options)

                    val imageHeight = options.outHeight
                    val imageWidth = options.outWidth
                    var inSampleSize = 1

                    // Determine target size in pixels
                    val targetWidthPx: Int
                    val targetHeightPx: Int
                    with(context.resources.displayMetrics) {
                        if (size != null) {
                            // If size is provided, use it for both width and height (maintains square logic)
                            val targetSizePx = (size.value * density).toInt()
                            targetWidthPx = targetSizePx
                            targetHeightPx = targetSizePx
                        } else {
                            // If size is not provided, use the actual widget size
                            targetWidthPx = (widgetDpSize.width.value * density).toInt()
                            targetHeightPx = (widgetDpSize.height.value * density).toInt()
                        }
                    }

                    if (imageHeight > targetHeightPx || imageWidth > targetWidthPx) {
                        val halfHeight: Int = imageHeight / 2
                        val halfWidth: Int = imageWidth / 2
                        // Calculate the largest inSampleSize value that is a power of 2 and keeps both
                        // height and width larger than the requested height and width.
                        while (halfHeight / inSampleSize >= targetHeightPx && halfWidth / inSampleSize >= targetWidthPx) {
                            inSampleSize *= 2
                        }
                    }

                    options.inSampleSize = inSampleSize
                    options.inJustDecodeBounds = false
                    val sampledBitmap = BitmapFactory.decodeByteArray(data, 0, data.size, options)

                    if (sampledBitmap == null) {
                        return@let null
                    }

                    bitmap = sampledBitmap

                    bitmap.let { AlbumArtBitmapCache.putBitmap(cacheKey, it) }

                } catch (e: Exception) {
                    bitmap = null
                }
            }
            bitmap?.let { ImageProvider(it) }
        } ?: albumArtUri?.let { rawUri ->
            val cacheKey = "uri:$rawUri"
            var bitmap = AlbumArtBitmapCache.getBitmap(cacheKey)
            if (bitmap == null) {
                bitmap = decodeAlbumArtFromUri(
                    context = context,
                    rawUri = rawUri,
                    requestedSize = size,
                    widgetDpSize = widgetDpSize
                )
                bitmap?.let { AlbumArtBitmapCache.putBitmap(cacheKey, it) }
            }
            bitmap?.let { ImageProvider(it) }
        }

        Box(
            modifier = sizingModifier
        ) {
            if (imageProvider != null) {
                Image(
                    provider = imageProvider,
                    contentDescription = context.getString(R.string.widget_album_art),
                    modifier = GlanceModifier.fillMaxSize().cornerRadius(cornerRadius),
                    contentScale = ContentScale.Crop
                )
            } else {
                val placeholderBaseSize = size ?: minOf(widgetDpSize.width, widgetDpSize.height)
                val resolvedPlaceholderBaseSize = when {
                    placeholderBaseSize == Dp.Unspecified || placeholderBaseSize <= 0.dp -> 72.dp
                    else -> placeholderBaseSize
                }

                val placeholderSize = resolvedPlaceholderBaseSize
                    .times(0.65f)
                    .coerceIn(36.dp, 96.dp)

                Box(
                    modifier = GlanceModifier
                        .fillMaxSize()
                        .cornerRadius(cornerRadius)
                        .background(GlanceTheme.colors.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        provider = ImageProvider(R.drawable.ic_music_placeholder),
                        contentDescription = context.getString(R.string.widget_album_art_placeholder),
                        modifier = GlanceModifier.size(placeholderSize),
                        contentScale = ContentScale.Fit,
                        colorFilter = ColorFilter.tint(GlanceTheme.colors.onSurfaceVariant)
                    )
                }
            }
        }
    }

    private fun decodeAlbumArtFromUri(
        context: Context,
        rawUri: String,
        requestedSize: Dp?,
        widgetDpSize: DpSize
    ): Bitmap? {
        val (targetWidthPx, targetHeightPx) = with(context.resources.displayMetrics) {
            if (requestedSize != null) {
                val target = (requestedSize.value * density).toInt().coerceAtLeast(1)
                target to target
            } else {
                val width = (widgetDpSize.width.value * density).toInt().coerceAtLeast(1)
                val height = (widgetDpSize.height.value * density).toInt().coerceAtLeast(1)
                width to height
            }
        }
        return decodeWidgetAlbumArtBitmap(
            context = context,
            rawUri = rawUri,
            targetWidthPx = targetWidthPx,
            targetHeightPx = targetHeightPx,
        )
    }



    @Composable
    fun PlayPauseButtonGlance(
        modifier: GlanceModifier = GlanceModifier,
        isPlaying: Boolean,
        iconColor: ColorProvider = GlanceTheme.colors.onSurfaceVariant,
        backgroundColor: ColorProvider = GlanceTheme.colors.surfaceVariant,
        iconSize: Dp = 24.dp,
        cornerRadius: Dp = 0.dp
    ) {
        val context = LocalContext.current
        val params = actionParametersOf(PlayerActions.key to PlayerActions.PLAY_PAUSE)
        Box(
            modifier = modifier
                .background(backgroundColor)
                .cornerRadius(cornerRadius)
                .clickable(actionRunCallback<PlayerControlActionCallback>(params)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                provider = ImageProvider(if (isPlaying) R.drawable.rounded_pause_24 else R.drawable.rounded_play_arrow_24),
                contentDescription = context.getString(if (isPlaying) R.string.common_pause else R.string.common_play),
                modifier = GlanceModifier.size(iconSize),
                colorFilter = ColorFilter.tint(iconColor)
            )
        }
    }

    @Composable
    fun NextButtonGlance(
        modifier: GlanceModifier = GlanceModifier,
        iconColor: ColorProvider = GlanceTheme.colors.onSurfaceVariant,
        backgroundColor: ColorProvider = GlanceTheme.colors.surfaceVariant,
        iconSize: Dp = 24.dp,
        cornerRadius: Dp = 8.dp
    ) {
        val context = LocalContext.current
        val params = actionParametersOf(PlayerActions.key to PlayerActions.NEXT)
        Box(
            modifier = modifier
                .background(backgroundColor)
                .cornerRadius(cornerRadius)
                .clickable(actionRunCallback<PlayerControlActionCallback>(params)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                provider = ImageProvider(R.drawable.rounded_skip_next_24),
                contentDescription = context.getString(R.string.common_next_track),
                modifier = GlanceModifier.size(iconSize),
                colorFilter = ColorFilter.tint(iconColor)
            )
        }
    }

    @Composable
    fun PreviousButtonGlance(
        modifier: GlanceModifier = GlanceModifier,
        iconColor: ColorProvider = GlanceTheme.colors.onSurfaceVariant,
        backgroundColor: ColorProvider = GlanceTheme.colors.surfaceVariant,
        iconSize: Dp = 24.dp,
        cornerRadius: Dp = 8.dp
    ) {
        val context = LocalContext.current
        val params = actionParametersOf(PlayerActions.key to PlayerActions.PREVIOUS)
        Box(
            modifier = modifier
                .background(backgroundColor)
                .cornerRadius(cornerRadius)
                .clickable(actionRunCallback<PlayerControlActionCallback>(params)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                provider = ImageProvider(R.drawable.rounded_skip_previous_24),
                contentDescription = context.getString(R.string.common_previous_track),
                modifier = GlanceModifier.size(iconSize),
                colorFilter = ColorFilter.tint(iconColor)
            )
        }
    }

    @Composable
    fun EndOfQueuePlaceholder(
        modifier: GlanceModifier = GlanceModifier,
        size: Dp,
        cornerRadius: Dp
    ) {
        Box(
            modifier = modifier
                .size(size)
                .background(GlanceTheme.colors.surfaceVariant)
                .cornerRadius(cornerRadius)
        ) {}
    }
}
