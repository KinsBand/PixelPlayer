package com.theveloper.pixelplay.ui.glancewidget

import android.content.Context
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.content.getSystemService
import androidx.glance.GlanceId
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import com.theveloper.pixelplay.data.preferences.SpinSettings
import com.theveloper.pixelplay.data.preferences.WidgetKind
import com.theveloper.pixelplay.data.preferences.WidgetSpinMode
import dagger.hilt.android.EntryPointAccessors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import timber.log.Timber
import kotlin.math.abs

/**
 * Drives every frame-spun widget: the turntable and the CD.
 *
 * `RemoteViews` has no rotation primitive, so "spinning" means re-rendering at a new angle and
 * publishing again. Two things have to be true for that to actually show up on a home screen,
 * and the previous controller got the first one wrong:
 *
 * 1. **The composition has to see something change.** A plain `update()` makes a live Glance
 *    session re-read its state, but the state store hands back the *same* `PlayerInfo`
 *    instance when nothing changed, and `PlayerInfo` is declared stable in
 *    `compose_stability.conf` — so with strong skipping every composable below the root was
 *    skipped and no new frame was ever drawn. Widgets now collect [frame] and pass the angle
 *    down as a parameter, so each tick is a real parameter change that cannot be skipped.
 * 2. **The loop must be told the truth.** It used to be started from two places with two
 *    different sets of options (the service passed none, so it always used the defaults).
 *    It now reads each widget's own settings from the repository itself, on every [sync].
 *
 * Frames are only produced while they buy something: while audio plays (plus a short coast
 * after pausing), while such a widget is actually placed, while the screen is on, and never
 * in battery saver. Motion has inertia ([SpinMotion]): play spins up over about a second and
 * pause lets the object coast to a stop, the way a platter does.
 */
object SpinClock {

    /** Degrees of rotation per published frame; the frame rate is derived from this. */
    private const val DEGREES_PER_FRAME = 5f

    /** Never faster than 10 fps, never slower than 2 fps. */
    private const val MIN_FRAME_MS = 100L
    private const val MAX_FRAME_MS = 500L

    /** [WidgetSpinMode.TICK] advances in visible steps instead of a continuous turn. */
    private const val TICK_FRAME_MS = 2_000L

    /** Back-off while the screen is off or battery saver is on. */
    private const val IDLE_POLL_MS = 2_000L

    /**
     * Every this many frames each placed widget also gets a plain `update()`. That restarts a
     * Glance session which has timed out — a stopped session is not collecting [frame] — and
     * refreshes the list of placed widgets. It is not what moves the record; [frame] is.
     */
    private const val KEEPALIVE_FRAMES = 25

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mutex = Mutex()

    private val frames: Map<WidgetKind, MutableStateFlow<Long>> =
        WidgetKind.entries.filter { it.isFrameSpun }.associateWith { MutableStateFlow(0L) }

    /**
     * Increments on every frame published for [kind]. Frame-spun widgets collect this inside
     * `provideContent`; reading it there is what makes each frame a recomposition. One flow
     * per kind, so a spinning CD does not make a still turntable redraw, and vice versa.
     */
    fun frame(kind: WidgetKind): StateFlow<Long> = frames[kind] ?: NO_FRAMES

    /** For kinds that never spin; shared so callers always get the same instance. */
    private val NO_FRAMES: StateFlow<Long> = MutableStateFlow(0L)

    private fun tick(kind: WidgetKind) {
        frames[kind]?.let { it.value = it.value + 1 }
    }

    private val motions: Map<WidgetKind, SpinMotion> =
        WidgetKind.entries.filter { it.isFrameSpun }.associateWith { SpinMotion() }

    @Volatile
    private var settings: Map<WidgetKind, SpinSettings> = emptyMap()

    @Volatile
    private var placed: Map<WidgetKind, List<GlanceId>> = emptyMap()

    @Volatile
    private var isPlaying: Boolean = false

    private var loop: Job? = null

    // -------------------------------------------------------------------------------------
    // Reading
    // -------------------------------------------------------------------------------------

    /**
     * The angle, in degrees, to draw [kind] at right now.
     *
     * [WidgetSpinMode.POSITION] derives it from the track position, so it stays correct with
     * no extra updates at all. [WidgetSpinMode.OFF] still returns the parked angle rather than
     * snapping to zero, so switching spinning off leaves the record where it was.
     */
    fun angle(kind: WidgetKind, spin: SpinSettings, positionMs: Long): Float {
        if (spin.mode == WidgetSpinMode.POSITION) {
            return WidgetLayoutMath.normaliseDeg(positionMs * spin.degreesPerMs)
        }
        val motion = motions[kind] ?: return 0f
        return synchronized(motion) { motion.angleAt(now()) }
    }

    /**
     * How fast [kind] is turning right now, in degrees per frame at the current frame rate.
     * Renderers use this to size motion blur so a fast CD reads as spinning, not strobing.
     */
    fun degreesPerFrame(kind: WidgetKind): Float {
        val motion = motions[kind] ?: return 0f
        val velocity = synchronized(motion) { abs(motion.velocityAt(now())) }
        val spin = settings[kind] ?: return 0f
        return velocity * frameIntervalFor(spin, velocity)
    }

    // -------------------------------------------------------------------------------------
    // Control
    // -------------------------------------------------------------------------------------

    /**
     * Reconciles the loop with reality: re-reads every frame-spun widget's settings and which
     * of them are placed, then spins each one up, retunes it, or lets it coast to a stop.
     *
     * Safe to call as often as anything changes — playback state, settings, a widget being
     * placed or removed. Pass [playing] when the caller knows it; otherwise the last known
     * playback state is kept.
     */
    fun sync(context: Context, playing: Boolean? = null) {
        val app = context.applicationContext
        scope.launch {
            mutex.withLock {
                if (playing != null) isPlaying = playing
                val manager = GlanceAppWidgetManager(app)
                val repository = runCatching {
                    EntryPointAccessors
                        .fromApplication(app, WidgetPreferencesEntryPoint::class.java)
                        .widgetPreferencesRepository()
                }.getOrNull()

                val newSettings = mutableMapOf<WidgetKind, SpinSettings>()
                val newPlaced = mutableMapOf<WidgetKind, List<GlanceId>>()
                for (kind in motions.keys) {
                    newPlaced[kind] = runCatching { manager.getGlanceIds(widgetClassFor(kind)) }
                        .getOrDefault(emptyList())
                    newSettings[kind] = runCatching { repository?.readConfigOnce(kind)?.spin }
                        .getOrNull() ?: SpinSettings()
                }
                settings = newSettings
                placed = newPlaced

                val now = now()
                motions.forEach { (kind, motion) -> retarget(kind, motion, now) }

                if (motions.any { (kind, motion) -> needsFrames(kind, motion, now) }) {
                    ensureLoop(app)
                }
            }
        }
    }

    /** Stops everything immediately, with no coast. Used when the last widget is removed. */
    fun haltAll() {
        val now = now()
        motions.values.forEach { synchronized(it) { it.halt(now) } }
        loop?.cancel()
        loop = null
    }

    // -------------------------------------------------------------------------------------
    // Internals
    // -------------------------------------------------------------------------------------

    private fun retarget(kind: WidgetKind, motion: SpinMotion, now: Long) {
        val spin = settings[kind] ?: SpinSettings()
        val isPlaced = placed[kind].orEmpty().isNotEmpty()
        val target = if (isPlaying && isPlaced && spin.mode.isDriven) spin.degreesPerMs else 0f

        synchronized(motion) {
            if (!isPlaced) {
                motion.halt(now)
                return
            }
            if (motion.target == target) return
            val ease = when {
                target == 0f -> SpinMotion.SPIN_DOWN_MS
                motion.target == 0f -> SpinMotion.SPIN_UP_MS
                else -> SpinMotion.RETUNE_MS
            }
            // A tick mode has no visible in-between frames to ease through.
            motion.retarget(now, target, if (spin.mode == WidgetSpinMode.TICK) 0f else ease)
        }
    }

    private fun needsFrames(kind: WidgetKind, motion: SpinMotion, now: Long): Boolean {
        val spin = settings[kind] ?: return false
        if (placed[kind].isNullOrEmpty()) return false
        if (spin.mode == WidgetSpinMode.OFF || spin.mode == WidgetSpinMode.POSITION) return false
        return synchronized(motion) { motion.isMoving(now) }
    }

    private fun ensureLoop(context: Context) {
        if (loop?.isActive == true) return
        loop = scope.launch { runLoop(context) }
    }

    private suspend fun runLoop(context: Context) {
        val power = context.getSystemService<PowerManager>()
        var framesUntilKeepalive = 0
        var wasActive: Set<WidgetKind> = emptySet()
        Timber.tag(TAG).d("Spin loop started")
        try {
            while (scope.isActive) {
                if (power != null && (!power.isInteractive || power.isPowerSaveMode)) {
                    delay(IDLE_POLL_MS)
                    continue
                }

                val now = now()
                val active = motions.filter { (kind, motion) -> needsFrames(kind, motion, now) }
                // A kind that has just come to rest gets one last frame, so its widget shows
                // the exact angle it stopped at rather than the one before.
                (wasActive - active.keys).forEach { tick(it) }
                wasActive = active.keys
                if (active.isEmpty()) break

                val interval = active.keys.minOf { kind ->
                    val motion = motions.getValue(kind)
                    val v = synchronized(motion) { maxOf(abs(motion.velocityAt(now)), abs(motion.target)) }
                    frameIntervalFor(settings[kind] ?: SpinSettings(), v)
                }
                delay(interval)

                active.keys.forEach { tick(it) }

                if (--framesUntilKeepalive <= 0) {
                    framesUntilKeepalive = KEEPALIVE_FRAMES
                    active.keys.forEach { kind -> keepAlive(context, kind) }
                }
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Spin loop failed")
        } finally {
            Timber.tag(TAG).d("Spin loop stopped")
        }
    }

    /** Refreshes the placed list for [kind] and pokes each instance so a dead session restarts. */
    private suspend fun keepAlive(context: Context, kind: WidgetKind) {
        val ids = runCatching {
            GlanceAppWidgetManager(context).getGlanceIds(widgetClassFor(kind))
        }.getOrDefault(emptyList())
        placed = placed + (kind to ids)
        if (ids.isEmpty()) {
            motions[kind]?.let { synchronized(it) { it.halt(now()) } }
            return
        }
        val widget = widgetFor(kind)
        ids.forEach { id -> runCatching { widget.update(context, id) } }
    }

    /**
     * Publish interval: fast enough that each frame moves the object about
     * [DEGREES_PER_FRAME], clamped at both ends. Derived rather than fixed because a fixed rate
     * wastes frames at slow speeds — at 2 rpm an 8 fps loop publishes six frames for every 9°
     * of movement, five of which nobody could tell apart.
     */
    private fun frameIntervalFor(spin: SpinSettings, degreesPerMs: Float): Long {
        if (spin.mode == WidgetSpinMode.TICK) return TICK_FRAME_MS
        if (degreesPerMs <= 0f) return MAX_FRAME_MS
        return (DEGREES_PER_FRAME / degreesPerMs).toLong().coerceIn(MIN_FRAME_MS, MAX_FRAME_MS)
    }

    private fun widgetClassFor(kind: WidgetKind): Class<out GlanceAppWidget> = when (kind) {
        WidgetKind.DISC -> DiscWidget::class.java
        else -> TurntableWidget::class.java
    }

    private fun widgetFor(kind: WidgetKind): GlanceAppWidget = when (kind) {
        WidgetKind.DISC -> DiscWidget()
        else -> TurntableWidget()
    }

    private fun now(): Long = SystemClock.elapsedRealtime()

    private const val TAG = "SpinClock"
}
