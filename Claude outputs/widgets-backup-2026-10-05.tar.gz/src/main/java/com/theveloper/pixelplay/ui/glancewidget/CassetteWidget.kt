package com.theveloper.pixelplay.ui.glancewidget

import android.content.Context
import android.widget.RemoteViews
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.ColorFilter
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalSize
import androidx.glance.action.actionParametersOf
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.AndroidRemoteViews
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.currentState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.ContentScale
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontFamily
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.theveloper.pixelplay.MainActivity
import com.theveloper.pixelplay.R
import com.theveloper.pixelplay.data.model.PlayerInfo
import com.theveloper.pixelplay.data.preferences.CassetteLabel
import com.theveloper.pixelplay.data.preferences.CassetteShell
import com.theveloper.pixelplay.data.preferences.WidgetBackgroundStyle
import com.theveloper.pixelplay.data.preferences.WidgetConfig
import com.theveloper.pixelplay.data.preferences.WidgetContentOptions
import com.theveloper.pixelplay.data.preferences.WidgetKind
import kotlin.math.max
import kotlin.math.min
import androidx.compose.ui.unit.min

/**
 * A compact cassette whose tape winds from one reel to the other as the song plays.
 *
 * Unlike the record and the CD, nothing here is a rendered bitmap. The cassette is a stack of
 * vector layers (`widget_cassette_*`) that share one viewport and so line up exactly at any
 * size, which keeps it pin-sharp and costs nothing to send to the launcher:
 *
 *  shell (tinted) → details → label → window → tape packs → hubs → glass → handwriting.
 *
 * **The reels are animated by the launcher, not by the app.** Each hub is an indeterminate
 * `ProgressBar` whose drawable is a `<rotate>` of the hub, embedded through
 * [AndroidRemoteViews]; the launcher turns it at full frame rate with no wake-ups on our side
 * at all. What the app does do, on ordinary widget updates, is size the two tape packs from
 * playback progress ([WidgetLayoutMath.tapePackRadii] — area-true, so the take-up pack grows
 * fast at first and slowly at the end) and pick each reel's speed from its pack radius: at
 * constant tape speed the emptier reel turns faster, as on a real deck.
 *
 * Tapping the window plays or pauses; tapping anywhere else opens the app.
 */
class CassetteWidget : GlanceAppWidget() {

    override val sizeMode = SizeMode.Exact
    override val stateDefinition = PlayerInfoStateDefinition

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val initial = loadWidgetConfig(context, WidgetKind.CASSETTE)
        provideContent {
            val config = rememberWidgetConfig(context, WidgetKind.CASSETTE, initial)
            val playerInfo = currentState<PlayerInfo>()
            GlanceTheme {
                CassetteContent(context, playerInfo, config, LocalSize.current)
            }
        }
    }

    @Composable
    private fun CassetteContent(context: Context, playerInfo: PlayerInfo, config: WidgetConfig, size: DpSize) {
        val content = config.effectiveContent
        val palette = TurntablePalette.resolve(context, config.appearance, playerInfo)
        val colors = playerInfo.getWidgetColors(config.appearance)
        val framed = config.appearance.backgroundStyle != WidgetBackgroundStyle.TRANSPARENT
        val pad = if (framed) 10.dp else 4.dp
        val inner = DpSize(size.width - pad * 2, size.height - pad * 2)

        // Controls: a vertical strip of deck keys on the right when the cell is wider than a
        // cassette, a row underneath when it is taller, otherwise only the window's tap.
        val wantsKeys = content.showPrevNext || content.showShuffle || content.showRepeat || content.showFavorite
        val key = 40.dp
        val gap = 8.dp
        val naturalWidth = inner.height * ASPECT
        val side = wantsKeys && inner.width - naturalWidth >= key + gap
        val below = wantsKeys && !side && inner.height - inner.width / ASPECT >= key + gap
        val bodyWidth = when {
            side -> min(inner.width - key - gap, naturalWidth)
            below -> min(inner.width, (inner.height - key - gap) * ASPECT)
            else -> min(inner.width, naturalWidth)
        }
        val body = DpSize(bodyWidth, bodyWidth / ASPECT)

        Box(
            modifier = GlanceModifier
                .fillMaxSize()
                .widgetSurface(
                    context = context,
                    appearance = config.appearance,
                    colors = colors,
                    outlineColor = outlineColorFor(context, config.appearance, playerInfo),
                    size = size,
                )
                .padding(pad)
                .clickable(actionStartActivity<MainActivity>()),
            contentAlignment = Alignment.Center,
        ) {
            when {
                side -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Cassette(context, playerInfo, config, content, palette, body)
                    Spacer(GlanceModifier.width(gap))
                    DeckKeys(playerInfo, content, palette, vertical = true, length = body.height, key = key)
                }
                below -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Cassette(context, playerInfo, config, content, palette, body)
                    Spacer(GlanceModifier.height(gap))
                    DeckKeys(playerInfo, content, palette, vertical = false, length = body.width, key = key)
                }
                else -> Cassette(context, playerInfo, config, content, palette, body)
            }
        }
    }

    @Composable
    private fun Cassette(
        context: Context,
        playerInfo: PlayerInfo,
        config: WidgetConfig,
        content: WidgetContentOptions,
        palette: TurntablePalette,
        body: DpSize,
    ) {
        val options = config.cassette
        val w = body.width
        val h = body.height
        val shellColor = when (options.shell) {
            CassetteShell.BLACK -> 0xFF1B1B1E.toInt()
            CassetteShell.SMOKE -> 0xB8282A30.toInt()
            CassetteShell.WHITE -> 0xFFECE9E2.toInt()
            CassetteShell.ACCENT -> ColorMath.atLuminance(palette.accent, 0.42f)
        }
        val lightShell = options.shell == CassetteShell.WHITE ||
            (options.shell == CassetteShell.ACCENT && ColorMath.isLight(shellColor))
        val ink = when {
            options.label != CassetteLabel.NONE -> INK
            lightShell -> 0xFF1A1A1E.toInt()
            else -> 0xEEFFFFFF.toInt()
        }

        val progress = WidgetLayoutMath.progress(playerInfo.currentPositionMs, playerInfo.totalDurationMs)
        val emptyR = w * EMPTY_PACK
        val fullR = h * FULL_PACK
        val (supplyR, takeUpR) = WidgetLayoutMath.tapePackRadii(progress, emptyR.value, fullR.value)
        val hubD = w * HUB_RADIUS * 2f
        val reelY = h * REEL_Y
        val leftX = w * (0.5f - REEL_SPACING / 2f)
        val rightX = w * (0.5f + REEL_SPACING / 2f)
        val spinning = playerInfo.isPlaying && options.spinReels

        Box(modifier = GlanceModifier.size(w, h)) {
            Layer(R.drawable.widget_cassette_shell, tint = shellColor)
            Layer(R.drawable.widget_cassette_details)
            Label(context, playerInfo, options.label, palette, w, h)
            Layer(R.drawable.widget_cassette_window)
            Box(modifier = GlanceModifier.fillMaxSize()) {
                Tape(leftX, reelY, supplyR.dp)
                Tape(rightX, reelY, takeUpR.dp)
            }
            Box(modifier = GlanceModifier.fillMaxSize()) {
                Reel(context, leftX, reelY, hubD, if (spinning) bucketFor(supplyR, emptyR.value) else null)
                Reel(context, rightX, reelY, hubD, if (spinning) bucketFor(takeUpR, emptyR.value) else null)
            }
            Layer(R.drawable.widget_cassette_glass)
            Handwriting(context, playerInfo, content, options.showSide && options.label != CassetteLabel.NONE, ink, w, h)
            // The window itself is the play/pause key.
            Positioned(
                alignment = Alignment.TopStart,
                start = w * (0.5f - WINDOW_W / 2f),
                top = h * (WINDOW_Y - WINDOW_H / 2f),
            ) {
                Box(
                    modifier = GlanceModifier
                        .size(w * WINDOW_W, h * WINDOW_H)
                        .clickable(
                            actionRunCallback<PlayerControlActionCallback>(
                                actionParametersOf(PlayerActions.key to PlayerActions.PLAY_PAUSE),
                            ),
                        ),
                ) {}
            }
        }
    }

    /** One full-size vector layer; every cassette layer shares the same viewport. */
    @Composable
    private fun Layer(res: Int, tint: Int? = null) {
        Image(
            provider = ImageProvider(res),
            contentDescription = null,
            modifier = GlanceModifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds,
            colorFilter = tint?.let { ColorFilter.tint(ColorProvider(Color(it))) },
        )
    }

    @Composable
    private fun Label(
        context: Context,
        playerInfo: PlayerInfo,
        label: CassetteLabel,
        palette: TurntablePalette,
        w: Dp,
        h: Dp,
    ) {
        when (label) {
            CassetteLabel.PAPER -> Box(modifier = GlanceModifier.fillMaxSize()) {
                Layer(R.drawable.widget_cassette_label_paper)
                Layer(R.drawable.widget_cassette_label_stripe, tint = ColorMath.atLuminance(palette.accent, 0.5f))
            }
            CassetteLabel.ART -> Box(modifier = GlanceModifier.fillMaxSize()) {
                Positioned(alignment = Alignment.TopStart, start = w * LABEL_X, top = h * LABEL_Y) {
                    AlbumArtImage(
                        modifier = GlanceModifier.size(w * LABEL_W, h * LABEL_H),
                        bitmapData = playerInfo.albumArtBitmapData,
                        albumArtUri = playerInfo.albumArtUri,
                        size = w * LABEL_W,
                        context = context,
                        cornerRadius = w * 0.018f,
                    )
                }
                Layer(R.drawable.widget_cassette_label_strip)
            }
            CassetteLabel.NONE -> Unit
        }
    }

    @Composable
    private fun Tape(cx: Dp, cy: Dp, r: Dp) {
        Positioned(alignment = Alignment.TopStart, start = cx - r, top = cy - r) {
            Image(
                provider = ImageProvider(R.drawable.widget_cassette_tape),
                contentDescription = null,
                modifier = GlanceModifier.size(r * 2f),
            )
        }
    }

    /**
     * A hub: launcher-animated at the speed of [bucket], or a still image when [bucket] is
     * `null` (paused, or reels switched off).
     */
    @Composable
    private fun Reel(context: Context, cx: Dp, cy: Dp, d: Dp, bucket: Int?) {
        Positioned(alignment = Alignment.TopStart, start = cx - d / 2f, top = cy - d / 2f) {
            if (bucket != null) {
                AndroidRemoteViews(
                    remoteViews = RemoteViews(context.packageName, REEL_LAYOUTS[bucket]),
                    modifier = GlanceModifier.size(d),
                )
            } else {
                Image(
                    provider = ImageProvider(R.drawable.widget_cassette_hub),
                    contentDescription = null,
                    modifier = GlanceModifier.size(d),
                )
            }
        }
    }

    /** Title and artist written on the label, with the side mark in front. */
    @Composable
    private fun Handwriting(
        context: Context,
        playerInfo: PlayerInfo,
        content: WidgetContentOptions,
        showSide: Boolean,
        ink: Int,
        w: Dp,
        h: Dp,
    ) {
        if (!content.showTitle && !content.showArtist && !showSide) return
        val titleSp = (h.value * 0.085f).coerceIn(9f, 22f)
        val artistSp = (h.value * 0.056f).coerceIn(8f, 15f)
        val inkColor = ColorProvider(Color(ink))
        Positioned(alignment = Alignment.TopStart, start = w * 0.095f, top = h * 0.095f, end = w * 0.1f) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (showSide) {
                    Image(
                        provider = ImageProvider(R.drawable.widget_cassette_side_a),
                        contentDescription = context.getString(R.string.widget_cassette_side_a_cd),
                        modifier = GlanceModifier.size(h * 0.085f),
                        colorFilter = ColorFilter.tint(inkColor),
                    )
                    Spacer(GlanceModifier.width(w * 0.018f))
                }
                Column {
                    if (content.showTitle) {
                        Text(
                            text = playerInfo.songTitle.ifEmpty { context.getString(R.string.app_name) },
                            maxLines = 1,
                            style = TextStyle(color = inkColor, fontSize = titleSp.sp, fontFamily = FontFamily.Cursive),
                        )
                    }
                    if (content.showArtist) {
                        Text(
                            text = playerInfo.artistName.ifEmpty { context.getString(R.string.widget_tap_to_open) },
                            maxLines = 1,
                            style = TextStyle(
                                color = ColorProvider(Color(ColorMath.withAlpha(ink, 0.78f))),
                                fontSize = artistSp.sp,
                                fontFamily = FontFamily.Cursive,
                            ),
                        )
                    }
                }
            }
        }
    }

    /** Deck keys beside or under the cassette. Play lives in the window, so it is not repeated. */
    @Composable
    private fun DeckKeys(
        playerInfo: PlayerInfo,
        content: WidgetContentOptions,
        palette: TurntablePalette,
        vertical: Boolean,
        length: Dp,
        key: Dp,
    ) {
        val colors = TransportColors(
            button = ColorProvider(Color(palette.playBadgeBackground)),
            onButton = ColorProvider(Color(palette.playBadgeIcon)),
            play = ColorProvider(Color(palette.playBadgeBackground)),
            onPlay = ColorProvider(Color(palette.playBadgeIcon)),
            active = ColorProvider(Color(palette.playBadgeIcon)),
            onActive = ColorProvider(Color(palette.playBadgeBackground)),
        )
        val slots = WidgetLayoutMath.planTransport(
            prevNext = content.showPrevNext,
            shuffle = content.showShuffle,
            repeat = content.showRepeat,
            favorite = content.showFavorite,
            maxSlots = WidgetLayoutMath.slotsThatFit(length.value, key.value, 6f) + 1,
        ).filter { it != WidgetLayoutMath.TransportSlot.PLAY }
        @Composable
        fun keyCell(slot: WidgetLayoutMath.TransportSlot) {
            Box(modifier = GlanceModifier.size(key + 6.dp).padding(3.dp)) {
                TransportButton(
                    slot = slot,
                    playerInfo = playerInfo,
                    colors = colors,
                    cornerRadius = 12.dp,
                    iconSize = 18.dp,
                )
            }
        }
        if (vertical) {
            Column(verticalAlignment = Alignment.CenterVertically) { slots.forEach { keyCell(it) } }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) { slots.forEach { keyCell(it) } }
        }
    }

    private fun bucketFor(packRadius: Float, emptyRadius: Float): Int {
        val period = REEL_PERIOD_AT_EMPTY_S * packRadius / max(0.001f, emptyRadius)
        return WidgetLayoutMath.nearestBucket(period, REEL_BUCKETS_S)
    }

    internal companion object {
        /** A real cassette is 100.4 × 63.8 mm. */
        const val ASPECT = 1.574f

        // Geometry as fractions of the shell; matches the widget_cassette_* vectors.
        const val LABEL_X = 0.065f
        const val LABEL_Y = 0.075f
        const val LABEL_W = 0.87f
        const val LABEL_H = 0.60f
        const val WINDOW_W = 0.60f
        const val WINDOW_H = 0.31f
        const val WINDOW_Y = 0.43f
        const val REEL_Y = 0.43f
        const val REEL_SPACING = 0.42f
        const val HUB_RADIUS = 0.034f
        const val EMPTY_PACK = 0.040f
        const val FULL_PACK = 0.145f

        /** Ballpoint blue, for writing on the paper label. */
        const val INK = 0xFF1D2A52.toInt()

        /** A nearly empty reel turns once in this long; fuller reels proportionally slower. */
        const val REEL_PERIOD_AT_EMPTY_S = 1.3f

        /** Periods the reel layouts are built for, in seconds per turn. */
        val REEL_BUCKETS_S = listOf(1.3f, 1.7f, 2.1f, 2.5f, 3.0f)

        val REEL_LAYOUTS = intArrayOf(
            R.layout.widget_cassette_reel_1,
            R.layout.widget_cassette_reel_2,
            R.layout.widget_cassette_reel_3,
            R.layout.widget_cassette_reel_4,
            R.layout.widget_cassette_reel_5,
        )
    }
}
