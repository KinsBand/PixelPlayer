package com.theveloper.pixelplay.presentation.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Autorenew
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ColorLens
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Label
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Radio
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material.icons.rounded.Title
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PlainTooltip
import androidx.compose.material3.Text
import androidx.compose.material3.TooltipAnchorPosition
import androidx.compose.material3.TooltipBox
import androidx.compose.material3.TooltipDefaults
import androidx.compose.material3.rememberTooltipState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.theveloper.pixelplay.R
import com.theveloper.pixelplay.data.preferences.CassetteLabel
import com.theveloper.pixelplay.data.preferences.CassetteShell
import com.theveloper.pixelplay.data.preferences.DiscFace
import com.theveloper.pixelplay.data.preferences.DiscOptions
import com.theveloper.pixelplay.data.preferences.DiscPresentation
import com.theveloper.pixelplay.data.preferences.TurntableOptions
import com.theveloper.pixelplay.data.preferences.VinylStyle
import com.theveloper.pixelplay.data.preferences.WidgetAccentSource
import com.theveloper.pixelplay.data.preferences.WidgetAppearance
import com.theveloper.pixelplay.data.preferences.WidgetBackgroundStyle
import com.theveloper.pixelplay.data.preferences.WidgetConfig
import com.theveloper.pixelplay.data.preferences.WidgetFeature
import com.theveloper.pixelplay.data.preferences.WidgetKind
import com.theveloper.pixelplay.data.preferences.WidgetProgressStyle
import com.theveloper.pixelplay.data.preferences.WidgetSpinMode
import com.theveloper.pixelplay.presentation.screens.SettingsSegmentedSelectorItem
import com.theveloper.pixelplay.presentation.screens.SliderSettingsItem
import com.theveloper.pixelplay.presentation.screens.ThemeSelectorItem
import com.theveloper.pixelplay.presentation.viewmodel.VisualWidgetsViewModel
import kotlin.math.roundToInt

/**
 * Visual widgets: how the home-screen widgets look.
 *
 * [WidgetsPinnedHeader] (big live preview + a row of widget names) stays fixed at the top;
 * everything here scrolls under it and applies to the widget picked there.
 *
 * **Every control on this page does something on the selected widget.** Which controls appear
 * is decided by [WidgetKind.features] — the same set each widget reads its flags through
 * (`WidgetConfig.effectiveContent`) — so the page cannot offer a switch the widget ignores.
 * Where a switched-on control can still be left out because the widget is too small for it,
 * the page says so under the switches.
 *
 * Backed by [VisualWidgetsViewModel] rather than the shared `SettingsViewModel`: nothing here
 * reads the 58-field settings state, and keeping it out means opening this page does not touch
 * the file explorer or storage enumeration the way other categories still do.
 */
@Composable
internal fun WidgetsSettingsContent(
    viewModel: VisualWidgetsViewModel = hiltViewModel(),
) {
    val configs by viewModel.configs.collectAsStateWithLifecycle()
    val selectedKind by viewModel.selectedKind.collectAsStateWithLifecycle()
    val config = configs[selectedKind] ?: WidgetConfig(kind = selectedKind)

    AppearanceSection(selectedKind, config, viewModel)
    ContentSection(selectedKind, config, viewModel)

    when (selectedKind) {
        WidgetKind.TURNTABLE -> TurntableSection(config.turntable, viewModel)
        WidgetKind.CASSETTE -> CassetteSection(config, viewModel)
        WidgetKind.DISC -> DiscSection(config.disc, viewModel)
        else -> Unit
    }
}

// -----------------------------------------------------------------------------------------
// Appearance
// -----------------------------------------------------------------------------------------

@Composable
private fun AppearanceSection(kind: WidgetKind, config: WidgetConfig, viewModel: VisualWidgetsViewModel) {
    val context = LocalContext.current
    val appearance = config.appearance
    SettingsSubsection(title = stringResource(R.string.settings_widgets_appearance_section)) {
        if (kind.supports(WidgetFeature.BACKGROUND)) {
            SettingsSegmentedSelectorItem(
                title = stringResource(R.string.settings_widget_background_title),
                subtitle = stringResource(R.string.settings_widget_background_subtitle),
                options = WidgetBackgroundStyle.entries.toList(),
                selectedOption = appearance.backgroundStyle,
                optionLabel = { style: WidgetBackgroundStyle -> stringResource(style.labelRes) },
                onOptionSelected = { viewModel.setBackgroundStyle(kind, it) },
                leadingIcon = { Icon(Icons.Rounded.Palette, null, tint = MaterialTheme.colorScheme.secondary) },
                settingKey = "widget_background",
            )
        }
        // Only meaningful when there is a background to round: on a transparent widget the
        // radius would change nothing visible, so it is not offered.
        if (kind.supports(WidgetFeature.CORNER_RADIUS) &&
            appearance.backgroundStyle != WidgetBackgroundStyle.TRANSPARENT
        ) {
            SliderSettingsItem(
                label = stringResource(R.string.settings_widget_corner_title),
                value = appearance.cornerRadiusDp.toFloat(),
                valueRange = WidgetAppearance.MIN_CORNER_RADIUS_DP.toFloat()..
                    WidgetAppearance.MAX_CORNER_RADIUS_DP.toFloat(),
                steps = 0,
                onValueChange = { viewModel.setCornerRadius(kind, it.roundToInt()) },
                // valueText is a plain lambda, not a composable one, so the string is
                // resolved through the context rather than with stringResource.
                valueText = { value -> context.getString(R.string.settings_widget_corner_value, value.roundToInt()) },
                settingKey = "widget_corner",
            )
        }
        if (kind.supports(WidgetFeature.ACCENT)) {
            SettingsSegmentedSelectorItem(
                title = stringResource(R.string.settings_widget_accent_title),
                subtitle = stringResource(R.string.settings_widget_accent_subtitle),
                options = WidgetAccentSource.entries.toList(),
                selectedOption = appearance.accentSource,
                optionLabel = { source: WidgetAccentSource -> stringResource(source.labelRes) },
                onOptionSelected = { viewModel.setAccentSource(kind, it) },
                leadingIcon = { Icon(Icons.Rounded.ColorLens, null, tint = MaterialTheme.colorScheme.secondary) },
                settingKey = "widget_accent",
            )
            if (appearance.accentSource == WidgetAccentSource.FIXED) {
                FixedColourPicker(
                    selected = appearance.fixedAccentColor,
                    onSelect = { viewModel.setFixedAccentColor(kind, it) },
                )
            }
        }
    }

    if (!kind.supports(WidgetFeature.CORNER_RADIUS)) {
        Note(stringResource(R.string.settings_widget_corner_fixed_note))
    }
}

/**
 * The fixed accent colour. It used to be selectable as a source with no way to choose the
 * colour, so "Fixed" always meant the default indigo.
 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun FixedColourPicker(selected: Int, onSelect: (Int) -> Unit) {
    val highlighted = com.theveloper.pixelplay.presentation.screens.LocalHighlightSettingKey.current
        ?.equals(ACCENT_COLOR_KEY, ignoreCase = true) == true
    Text(
        text = stringResource(R.string.settings_widget_accent_color_title),
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp),
    )
    androidx.compose.foundation.layout.FlowRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .then(
                if (highlighted) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                else Modifier
            ),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp),
    ) {
        WidgetAppearance.FIXED_ACCENT_SWATCHES.forEachIndexed { index, swatch ->
            val isSelected = swatch == selected
            val colour = Color(swatch)
            val label = stringResource(R.string.settings_widget_accent_swatch_cd, index + 1)
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(colour)
                    .border(
                        width = if (isSelected) 3.dp else 1.dp,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                        shape = CircleShape,
                    )
                    .clickable { onSelect(swatch) }
                    .semantics {
                        contentDescription = label
                        this.selected = isSelected
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (isSelected) {
                    Icon(
                        Icons.Rounded.Check,
                        contentDescription = null,
                        tint = if (colour.luminance() > 0.5f) Color.Black else Color.White,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------------------
// Controls and content
// -----------------------------------------------------------------------------------------

@Composable
private fun ContentSection(kind: WidgetKind, config: WidgetConfig, viewModel: VisualWidgetsViewModel) {
    val content = config.content
    val toggles = listOf(
        WidgetFeature.TITLE, WidgetFeature.ARTIST, WidgetFeature.PREV_NEXT,
        WidgetFeature.SHUFFLE, WidgetFeature.REPEAT, WidgetFeature.FAVORITE,
    ).filter(kind::supports)
    if (toggles.isEmpty() && !kind.supports(WidgetFeature.PROGRESS)) return

    SettingsSubsection(title = stringResource(R.string.settings_widgets_content_section)) {
        WidgetToggleRow {
            toggles.forEach { feature ->
                when (feature) {
                    WidgetFeature.TITLE -> WidgetIconToggle(
                        icon = Icons.Rounded.Title,
                        label = stringResource(R.string.settings_widget_show_title),
                        checked = content.showTitle,
                        onCheckedChange = { viewModel.setShowTitle(kind, it) },
                        settingKey = "widget_show_title",
                    )
                    WidgetFeature.ARTIST -> WidgetIconToggle(
                        icon = Icons.Rounded.Person,
                        label = stringResource(R.string.settings_widget_show_artist),
                        checked = content.showArtist,
                        onCheckedChange = { viewModel.setShowArtist(kind, it) },
                        settingKey = "widget_show_artist",
                    )
                    WidgetFeature.PREV_NEXT -> WidgetIconToggle(
                        icon = Icons.Rounded.SkipNext,
                        label = stringResource(R.string.settings_widget_show_prev_next),
                        checked = content.showPrevNext,
                        onCheckedChange = { viewModel.setShowPrevNext(kind, it) },
                        settingKey = "widget_show_prev_next",
                    )
                    WidgetFeature.SHUFFLE -> WidgetIconToggle(
                        icon = Icons.Rounded.Shuffle,
                        label = stringResource(R.string.settings_widget_show_shuffle),
                        checked = content.showShuffle,
                        onCheckedChange = { viewModel.setShowShuffle(kind, it) },
                        settingKey = "widget_show_shuffle",
                    )
                    WidgetFeature.REPEAT -> WidgetIconToggle(
                        icon = Icons.Rounded.Repeat,
                        label = stringResource(R.string.settings_widget_show_repeat),
                        checked = content.showRepeat,
                        onCheckedChange = { viewModel.setShowRepeat(kind, it) },
                        settingKey = "widget_show_repeat",
                    )
                    WidgetFeature.FAVORITE -> WidgetIconToggle(
                        icon = Icons.Rounded.Favorite,
                        label = stringResource(R.string.settings_widget_show_favorite),
                        checked = content.showFavorite,
                        onCheckedChange = { viewModel.setShowFavorite(kind, it) },
                        settingKey = "widget_show_favorite",
                    )
                    else -> Unit
                }
            }
        }
        if (kind.supports(WidgetFeature.PROGRESS)) {
            SettingsSegmentedSelectorItem(
                title = stringResource(R.string.settings_widget_progress_title),
                options = WidgetProgressStyle.entries.toList(),
                selectedOption = content.progressStyle,
                optionLabel = { style: WidgetProgressStyle -> stringResource(style.labelRes) },
                onOptionSelected = { viewModel.setProgressStyle(kind, it) },
                leadingIcon = { Icon(Icons.Rounded.Visibility, null, tint = MaterialTheme.colorScheme.secondary) },
                settingKey = "widget_progress",
            )
        }
    }

    if (kind.sizeDependentControls) {
        Note(stringResource(R.string.settings_widget_size_dependent_note))
    }
}

// -----------------------------------------------------------------------------------------
// Turntable
// -----------------------------------------------------------------------------------------

@Composable
private fun TurntableSection(turntable: TurntableOptions, viewModel: VisualWidgetsViewModel) {
    val context = LocalContext.current
    SettingsSubsection(title = stringResource(R.string.settings_widgets_turntable_section)) {
        ThemeSelectorItem(
            label = stringResource(R.string.settings_vinyl_style_title),
            description = stringResource(R.string.settings_vinyl_style_subtitle),
            options = VinylStyle.entries.associate { it.storageKey to stringResource(it.labelRes) },
            selectedKey = turntable.style.storageKey,
            onSelectionChanged = { viewModel.setVinylStyle(VinylStyle.fromStorageKey(it)) },
            leadingIcon = { Icon(Icons.Rounded.Style, null, tint = MaterialTheme.colorScheme.secondary) },
            settingKey = "turntable_style",
        )
        SpinControls(
            mode = turntable.spinMode,
            rpm = turntable.spinRpm,
            rpmRange = TurntableOptions.MIN_SPIN_RPM..TurntableOptions.MAX_SPIN_RPM,
            clockwise = turntable.clockwise,
            onMode = viewModel::setSpinMode,
            onRpm = viewModel::setSpinRpm,
            onClockwise = viewModel::setClockwise,
            modeKey = SearchKey(settingKey = "turntable_spin_mode"),
            speedKey = SearchKey(settingKey = "turntable_spin_speed"),
            directionKey = SearchKey(settingKey = "turntable_direction"),
        )
        SliderSettingsItem(
            label = stringResource(R.string.settings_turntable_disc_scale_title),
            value = turntable.discScale,
            valueRange = TurntableOptions.MIN_DISC_SCALE..TurntableOptions.MAX_DISC_SCALE,
            onValueChange = viewModel::setDiscScale,
            valueText = { value -> context.percentText(value) },
            settingKey = "turntable_disc_size",
        )
        // A 7" single has a fixed, wide label around its big centre hole.
        if (turntable.style != VinylStyle.SINGLE && turntable.style != VinylStyle.PICTURE) {
            SliderSettingsItem(
                label = stringResource(R.string.settings_turntable_label_scale_title),
                value = turntable.labelScale,
                valueRange = TurntableOptions.MIN_LABEL_SCALE..TurntableOptions.MAX_LABEL_SCALE,
                onValueChange = viewModel::setLabelScale,
                valueText = { value -> context.percentText(value) },
                settingKey = "turntable_label_size",
            )
        }
        WidgetToggleRow {
            WidgetIconToggle(
                icon = Icons.Rounded.PlayCircle,
                label = stringResource(R.string.settings_turntable_badges_title),
                checked = turntable.showBadges,
                onCheckedChange = viewModel::setShowBadges,
                settingKey = "turntable_badges",
            )
            WidgetIconToggle(
                icon = Icons.Rounded.Timeline,
                label = stringResource(R.string.settings_turntable_tonearm_title),
                checked = turntable.showTonearm,
                onCheckedChange = viewModel::setShowTonearm,
                settingKey = "turntable_tonearm",
            )
            WidgetIconToggle(
                icon = Icons.Rounded.Album,
                label = stringResource(R.string.settings_turntable_grooves_title),
                checked = turntable.showGrooves,
                onCheckedChange = viewModel::setShowGrooves,
                settingKey = "turntable_grooves",
            )
            WidgetIconToggle(
                icon = Icons.Rounded.Lightbulb,
                label = stringResource(R.string.settings_turntable_sheen_title),
                checked = turntable.showSheen,
                onCheckedChange = viewModel::setShowSheen,
                settingKey = "turntable_sheen",
            )
        }
    }
    if (turntable.spinMode == WidgetSpinMode.SMOOTH) Note(stringResource(R.string.settings_widget_battery_note))
}

/** Spin mode, speed and direction; shared by the turntable and the CD. */
@Composable
private fun SpinControls(
    mode: WidgetSpinMode,
    rpm: Float,
    rpmRange: ClosedFloatingPointRange<Float>,
    clockwise: Boolean,
    onMode: (WidgetSpinMode) -> Unit,
    onRpm: (Float) -> Unit,
    onClockwise: (Boolean) -> Unit,
    modeKey: SearchKey,
    speedKey: SearchKey,
    directionKey: SearchKey,
) {
    val context = LocalContext.current
    ThemeSelectorItem(
        label = stringResource(R.string.settings_turntable_spin_mode_title),
        description = stringResource(mode.descriptionRes),
        options = WidgetSpinMode.entries.associate { it.storageKey to stringResource(it.labelRes) },
        selectedKey = mode.storageKey,
        onSelectionChanged = { key -> onMode(WidgetSpinMode.fromStorageKey(key)) },
        leadingIcon = { Icon(Icons.Rounded.RotateRight, null, tint = MaterialTheme.colorScheme.secondary) },
        settingKey = modeKey.settingKey,
    )
    // Speed and direction mean nothing to a record that does not turn.
    if (mode != WidgetSpinMode.OFF) {
        SliderSettingsItem(
            label = stringResource(R.string.settings_turntable_spin_speed_title),
            value = rpm,
            valueRange = rpmRange,
            onValueChange = onRpm,
            valueText = { value -> context.getString(R.string.settings_turntable_spin_speed_value, value.roundToInt()) },
            settingKey = speedKey.settingKey,
        )
        SettingsSegmentedSelectorItem(
            title = stringResource(R.string.settings_turntable_direction_title),
            options = listOf(true, false),
            selectedOption = clockwise,
            optionLabel = { cw: Boolean ->
                stringResource(if (cw) R.string.settings_turntable_clockwise else R.string.settings_turntable_counter_clockwise)
            },
            onOptionSelected = onClockwise,
            leadingIcon = { Icon(Icons.Rounded.Radio, null, tint = MaterialTheme.colorScheme.secondary) },
            settingKey = directionKey.settingKey,
        )
    }
}

// -----------------------------------------------------------------------------------------
// Cassette
// -----------------------------------------------------------------------------------------

@Composable
private fun CassetteSection(config: WidgetConfig, viewModel: VisualWidgetsViewModel) {
    val cassette = config.cassette
    SettingsSubsection(title = stringResource(R.string.settings_widgets_cassette_section)) {
        ThemeSelectorItem(
            label = stringResource(R.string.settings_cassette_shell_title),
            description = stringResource(R.string.settings_cassette_shell_subtitle),
            options = CassetteShell.entries.associate { it.storageKey to stringResource(it.labelRes) },
            selectedKey = cassette.shell.storageKey,
            onSelectionChanged = { viewModel.setCassetteShell(CassetteShell.fromStorageKey(it)) },
            leadingIcon = { Icon(Icons.Rounded.Layers, null, tint = MaterialTheme.colorScheme.secondary) },
            settingKey = "cassette_shell",
        )
        SettingsSegmentedSelectorItem(
            title = stringResource(R.string.settings_cassette_label_title),
            options = CassetteLabel.entries.toList(),
            selectedOption = cassette.label,
            optionLabel = { label: CassetteLabel -> stringResource(label.labelRes) },
            onOptionSelected = viewModel::setCassetteLabel,
            leadingIcon = { Icon(Icons.Rounded.Label, null, tint = MaterialTheme.colorScheme.secondary) },
            settingKey = "cassette_label",
        )
        WidgetToggleRow {
            WidgetIconToggle(
                icon = Icons.Rounded.Autorenew,
                label = stringResource(R.string.settings_cassette_reels_title),
                checked = cassette.spinReels,
                onCheckedChange = viewModel::setCassetteSpinReels,
                settingKey = "cassette_reels",
            )
            // The side mark is written on the label, so it needs one.
            if (cassette.label != CassetteLabel.NONE) {
                WidgetIconToggle(
                    icon = Icons.Rounded.Title,
                    label = stringResource(R.string.settings_cassette_side_title),
                    checked = cassette.showSide,
                    onCheckedChange = viewModel::setCassetteShowSide,
                    settingKey = "cassette_side",
                )
            }
        }
    }
    Note(stringResource(R.string.settings_cassette_reels_note))
}

// -----------------------------------------------------------------------------------------
// CD
// -----------------------------------------------------------------------------------------

@Composable
private fun DiscSection(disc: DiscOptions, viewModel: VisualWidgetsViewModel) {
    val context = LocalContext.current
    SettingsSubsection(title = stringResource(R.string.settings_widgets_disc_section)) {
        SettingsSegmentedSelectorItem(
            title = stringResource(R.string.settings_disc_face_title),
            options = DiscFace.entries.toList(),
            selectedOption = disc.face,
            optionLabel = { face: DiscFace -> stringResource(face.labelRes) },
            onOptionSelected = viewModel::setDiscFace,
            leadingIcon = { Icon(Icons.Rounded.Album, null, tint = MaterialTheme.colorScheme.secondary) },
            settingKey = "disc_face",
        )
        SettingsSegmentedSelectorItem(
            title = stringResource(R.string.settings_disc_presentation_title),
            options = DiscPresentation.entries.toList(),
            selectedOption = disc.presentation,
            optionLabel = { presentation: DiscPresentation -> stringResource(presentation.labelRes) },
            onOptionSelected = viewModel::setDiscPresentation,
            leadingIcon = { Icon(Icons.Rounded.Style, null, tint = MaterialTheme.colorScheme.secondary) },
            settingKey = "disc_presentation",
        )
        SpinControls(
            mode = disc.spinMode,
            rpm = disc.spinRpm,
            rpmRange = DiscOptions.MIN_SPIN_RPM..DiscOptions.MAX_SPIN_RPM,
            clockwise = disc.clockwise,
            onMode = viewModel::setDiscSpinMode,
            onRpm = viewModel::setDiscSpinRpm,
            onClockwise = viewModel::setDiscClockwise,
            modeKey = SearchKey(settingKey = "disc_spin_mode"),
            speedKey = SearchKey(settingKey = "disc_spin_speed"),
            directionKey = SearchKey(settingKey = "disc_direction"),
        )
        // The case and the player fix the disc's size themselves.
        if (disc.presentation == DiscPresentation.DISC) {
            SliderSettingsItem(
                label = stringResource(R.string.settings_disc_size_title),
                value = disc.discScale,
                valueRange = DiscOptions.MIN_DISC_SCALE..DiscOptions.MAX_DISC_SCALE,
                onValueChange = viewModel::setCdDiscScale,
                valueText = { value -> context.percentText(value) },
                settingKey = "disc_size",
            )
        }
        WidgetToggleRow {
            WidgetIconToggle(
                icon = Icons.Rounded.PlayCircle,
                label = stringResource(R.string.settings_turntable_badges_title),
                checked = disc.showBadges,
                onCheckedChange = viewModel::setDiscShowBadges,
                settingKey = "disc_badges",
            )
        }
    }
    if (disc.spinMode == WidgetSpinMode.SMOOTH) Note(stringResource(R.string.settings_widget_battery_note))
}

// -----------------------------------------------------------------------------------------
// Small pieces
// -----------------------------------------------------------------------------------------

@Composable
private fun Note(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp),
    )
}

/**
 * A settings-search key handed to a helper that renders more than one row. Written with the
 * `settingKey =` name at the call site so every key on this page is visible to the registry
 * parity check, which scans for that form.
 */
private data class SearchKey(val settingKey: String)

/** Search key for the fixed-colour swatches. */
private val ACCENT_COLOR_KEY = SearchKey(settingKey = "widget_accent_color").settingKey

/** Formats a 0..1 scale as a whole percentage, e.g. 0.82 becomes "82%". */
private fun android.content.Context.percentText(value: Float): String =
    getString(R.string.settings_turntable_disc_scale_value, (value * 100f).roundToInt())

/** Fixed top of the Widgets page: the selected widget, large, and the row of widget names. */
@Composable
internal fun WidgetsPinnedHeader(
    modifier: Modifier = Modifier,
    viewModel: VisualWidgetsViewModel = hiltViewModel(),
) {
    val configs by viewModel.configs.collectAsStateWithLifecycle()
    val selectedKind by viewModel.selectedKind.collectAsStateWithLifecycle()
    val playerInfo by viewModel.playerInfo.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Column(modifier = modifier.fillMaxWidth()) {
        WidgetMainPreview(
            kind = selectedKind,
            config = configs[selectedKind] ?: WidgetConfig(kind = selectedKind),
            playerInfo = playerInfo,
        )
        WidgetKindSelector(selectedKind = selectedKind, onSelect = viewModel::selectKind)
    }
}

/** Reset for the selected widget: an icon in the top bar, with a confirmation. */
@Composable
internal fun WidgetResetAction(viewModel: VisualWidgetsViewModel = hiltViewModel()) {
    val selectedKind by viewModel.selectedKind.collectAsStateWithLifecycle()
    var confirm by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val widgetName = stringResource(selectedKind.labelRes)
    androidx.compose.material3.IconButton(onClick = { confirm = true }) {
        Icon(Icons.Rounded.Restore, contentDescription = stringResource(R.string.settings_widget_reset_title))
    }
    if (confirm) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirm = false },
            icon = { Icon(Icons.Rounded.Restore, null) },
            title = { Text(stringResource(R.string.settings_widget_reset_confirm_title, widgetName)) },
            text = { Text(stringResource(R.string.settings_widget_reset_confirm_body)) },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    confirm = false
                    viewModel.resetKind(selectedKind)
                }) { Text(stringResource(R.string.settings_widget_reset_confirm_action)) }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { confirm = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
            },
        )
    }
}

/** Icon toggles wrap onto as many lines as they need. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun WidgetToggleRow(content: @Composable () -> Unit) {
    androidx.compose.foundation.layout.FlowRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp),
    ) { content() }
}

/**
 * An on/off option as just its icon: filled when on, outlined when off. The label is read by
 * TalkBack and shown on long press, so the row stays compact.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun WidgetIconToggle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    settingKey: String,
) {
    val highlighted = com.theveloper.pixelplay.presentation.screens.LocalHighlightSettingKey.current
        ?.equals(settingKey, ignoreCase = true) == true
    TooltipBox(
        positionProvider = TooltipDefaults.rememberTooltipPositionProvider(
            TooltipAnchorPosition.Above
        ),
        tooltip = { PlainTooltip { Text(label) } },
        state = rememberTooltipState(),
    ) {
        androidx.compose.material3.FilledIconToggleButton(
            checked = checked,
            onCheckedChange = onCheckedChange,
            shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
            colors = androidx.compose.material3.IconButtonDefaults.filledIconToggleButtonColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                contentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                checkedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                checkedContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
            ),
            modifier = Modifier
                .size(56.dp)
                .then(
                    if (highlighted) Modifier.border(
                        2.dp, MaterialTheme.colorScheme.primary,
                        androidx.compose.foundation.shape.RoundedCornerShape(18.dp)
                    ) else Modifier
                )
                .semantics { stateDescription = if (checked) "Shown" else "Hidden" },
        ) {
            Icon(icon, contentDescription = label)
        }
    }
}
