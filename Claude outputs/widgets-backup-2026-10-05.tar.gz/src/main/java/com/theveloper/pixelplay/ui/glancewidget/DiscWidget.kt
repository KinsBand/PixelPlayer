package com.theveloper.pixelplay.ui.glancewidget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.LocalSize
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.state.getAppWidgetState
import androidx.glance.background
import androidx.glance.currentState
import androidx.glance.layout.Box
import androidx.glance.layout.size
import com.theveloper.pixelplay.R
import com.theveloper.pixelplay.data.model.PlayerInfo
import com.theveloper.pixelplay.data.preferences.DiscPresentation
import com.theveloper.pixelplay.data.preferences.WidgetConfig
import com.theveloper.pixelplay.data.preferences.WidgetKind
import timber.log.Timber
import kotlin.math.max

/**
 * A compact disc, spinning while music plays — on its own, half out of its jewel case, or
 * seen through the lid of a portable player. Drawn by [DiscRenderer], turned by [SpinClock],
 * laid out by [SpinStage], exactly like the turntable.
 */
class DiscWidget : GlanceAppWidget() {

    override val sizeMode = SizeMode.Exact
    override val stateDefinition = PlayerInfoStateDefinition

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val initial = loadWidgetConfig(context, WidgetKind.DISC)
        runCatching {
            val state = getAppWidgetState(context, PlayerInfoStateDefinition, id)
            SpinClock.sync(context, state.isPlaying)
        }.onFailure { Timber.tag(TAG).d(it, "Could not reconcile spin state") }

        provideContent {
            val config = rememberWidgetConfig(context, WidgetKind.DISC, initial)
            val playerInfo = currentState<PlayerInfo>()
            val frame = SpinClock.frame(WidgetKind.DISC).collectAsState().value
            val angle = SpinClock.angle(WidgetKind.DISC, config.disc.spin, playerInfo.currentPositionMs)
            val blur = SpinClock.degreesPerFrame(WidgetKind.DISC)
            GlanceTheme {
                DiscContent(context, playerInfo, config, angle, blur, frame)
            }
        }
    }

    @Composable
    private fun DiscContent(
        context: Context,
        playerInfo: PlayerInfo,
        config: WidgetConfig,
        angle: Float,
        degreesPerFrame: Float,
        @Suppress("UNUSED_PARAMETER") frame: Long,
    ) {
        val options = config.disc
        val palette = TurntablePalette.resolve(context, config.appearance, playerInfo)
        val density = context.resources.displayMetrics.density
        val progress = WidgetLayoutMath.progress(playerInfo.currentPositionMs, playerInfo.totalDurationMs)

        fun specFor(stagePx: Int) = DiscRenderer.DiscSpec(
            sizePx = stagePx,
            face = options.face,
            presentation = options.presentation,
            discScale = options.discScale,
            accent = palette.accent,
            artworkKey = artworkKey(playerInfo),
            title = playerInfo.songTitle,
        )
        val placement = specFor(1).placement

        SpinStage.Content(
            context = context,
            playerInfo = playerInfo,
            config = config,
            palette = palette,
            size = LocalSize.current,
            bubbles = {
                when (options.presentation) {
                    DiscPresentation.DISC -> SpinStage.edgeBubbles(placement, play = options.showBadges)
                    // Clear of the case: favourite above it on the left, play below the disc.
                    DiscPresentation.JEWEL_CASE -> SpinStage.Bubbles(
                        play = if (options.showBadges) SpinStage.Spot(0.85f, 0.85f) else null,
                        favorite = SpinStage.Spot(0.14f, 0.14f),
                        discDiameterFraction = 0.62f,
                    )
                    // In the corners the round player leaves free.
                    DiscPresentation.PORTABLE -> SpinStage.Bubbles(
                        play = if (options.showBadges) SpinStage.Spot(0.87f, 0.87f) else null,
                        favorite = SpinStage.Spot(0.88f, 0.12f),
                        discDiameterFraction = 0.6f,
                    )
                }
            },
            frame = { stage: Dp ->
                val stagePx = (stage.value * density).toInt().coerceIn(1, DiscRenderer.MAX_RENDER_PX)
                val spec = specFor(stagePx)
                DiscRenderer.renderFrame(spec, angle, degreesPerFrame, progress) {
                    val artPx = max(1, (spec.radiusPx * 2f).toInt())
                    TurntableRenderer.prepareArtwork(resolveTurntableArtwork(context, playerInfo, artPx), artPx)
                }
            },
            fallback = { stage ->
                val disc = stage * placement.radius * 2f
                Box(
                    modifier = GlanceModifier
                        .size(disc)
                        .background(Color(0xFFC9CDD4))
                        .cornerRadius(disc / 2),
                ) {}
            },
            objectDescription = context.getString(R.string.widget_disc_object_cd),
        )
    }

    private companion object {
        private const val TAG = "DiscWidget"
    }
}
