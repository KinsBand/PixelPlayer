package com.theveloper.pixelplay.ui.glancewidget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.LocalSize
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.provideContent
import androidx.glance.currentState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import com.theveloper.pixelplay.MainActivity
import com.theveloper.pixelplay.R
import com.theveloper.pixelplay.data.model.PlayerInfo
import com.theveloper.pixelplay.data.preferences.WidgetConfig
import com.theveloper.pixelplay.data.preferences.WidgetKind

/**
 * Artwork and track details on top, a full row of transport controls underneath.
 *
 * The favourite heart sits beside the title rather than in the transport row, so switching it
 * on never costs shuffle or repeat their place.
 */
class ControlWidget4x2 : GlanceAppWidget() {

    override val sizeMode = SizeMode.Exact
    override val stateDefinition = PlayerInfoStateDefinition

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val initial = loadWidgetConfig(context, WidgetKind.CONTROL_4X2)
        provideContent {
            val config = rememberWidgetConfig(context, WidgetKind.CONTROL_4X2, initial)
            val playerInfo = currentState<PlayerInfo>()
            GlanceTheme {
                ControlWidget4x2Content(
                    playerInfo = playerInfo,
                    context = context,
                    config = config,
                    size = LocalSize.current
                )
            }
        }
    }

    @Composable
    private fun ControlWidget4x2Content(
        playerInfo: PlayerInfo,
        context: Context,
        config: WidgetConfig,
        size: DpSize
    ) {
        val content = config.effectiveContent
        val title = playerInfo.songTitle.ifEmpty { context.getString(R.string.app_name) }
        val artist = playerInfo.artistName.ifEmpty { context.getString(R.string.widget_tap_to_open) }
        val colors = playerInfo.getWidgetColors(config.appearance)
        val transport = colors.transportColors()
        val padding = 16.dp

        Box(
            modifier = GlanceModifier
                .fillMaxSize()
                .widgetSurface(
                    context = context,
                    appearance = config.appearance,
                    colors = colors,
                    outlineColor = outlineColorFor(context, config.appearance, playerInfo),
                    size = size
                )
                .padding(padding)
                .clickable(actionStartActivity<MainActivity>())
        ) {
            Column(
                modifier = GlanceModifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = GlanceModifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    AlbumArtImage(
                        modifier = GlanceModifier.size(80.dp),
                        bitmapData = playerInfo.albumArtBitmapData,
                        albumArtUri = playerInfo.albumArtUri,
                        size = 80.dp,
                        context = context,
                        cornerRadius = 16.dp
                    )

                    Spacer(GlanceModifier.width(8.dp))

                    Column(
                        modifier = GlanceModifier.defaultWeight(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (content.showTitle) {
                            Text(
                                text = title,
                                style = TextStyle(
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.onSurface
                                ),
                                maxLines = 2
                            )
                        }
                        if (content.showTitle && content.showArtist) {
                            Spacer(GlanceModifier.height(2.dp))
                        }
                        if (content.showArtist) {
                            Text(
                                text = artist,
                                style = TextStyle(
                                    fontSize = 14.sp,
                                    color = colors.artist
                                ),
                                maxLines = 1
                            )
                        }
                    }

                    if (content.showFavorite) {
                        Spacer(GlanceModifier.width(6.dp))
                        FavoriteButton(
                            modifier = GlanceModifier.size(36.dp),
                            isFavorite = playerInfo.isFavorite,
                            backgroundColor = transport.button,
                            iconColor = transport.onButton,
                            cornerRadius = 18.dp,
                            iconSize = 18.dp,
                        )
                    }
                }

                WidgetProgressBar(
                    context = context,
                    appearance = config.appearance,
                    playerInfo = playerInfo,
                    style = content.progressStyle,
                    widthDp = size.width - padding * 2
                )

                Spacer(GlanceModifier.defaultWeight())

                TransportRow(
                    playerInfo = playerInfo,
                    content = content,
                    colors = transport,
                    availableWidth = size.width - padding * 2,
                    buttonHeight = 48.dp,
                    minButtonWidth = 40.dp,
                    cornerRadius = 16.dp,
                    playCornerRadius = if (playerInfo.isPlaying) 16.dp else 20.dp,
                    includeFavorite = false,
                    modifier = GlanceModifier.fillMaxWidth(),
                )
            }
        }
    }
}
