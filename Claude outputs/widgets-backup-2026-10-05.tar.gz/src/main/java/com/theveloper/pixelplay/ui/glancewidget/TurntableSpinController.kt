package com.theveloper.pixelplay.ui.glancewidget

import android.content.Context

/**
 * Superseded by [SpinClock], which drives the turntable and the CD from one loop and reads
 * each widget's own settings instead of trusting its caller to pass them.
 *
 * Kept as a thin forwarding shim so anything still calling it keeps working; new code should
 * call [SpinClock] directly.
 */
@Deprecated("Use SpinClock", ReplaceWith("SpinClock"))
object TurntableSpinController {

    fun onPlaybackStateChanged(context: Context, isPlaying: Boolean) =
        SpinClock.sync(context, isPlaying)

    /** The options argument is ignored: [SpinClock] reads the saved settings itself. */
    @Suppress("UNUSED_PARAMETER")
    fun onPlaybackStateChanged(
        context: Context,
        isPlaying: Boolean,
        options: com.theveloper.pixelplay.data.preferences.TurntableOptions,
    ) = SpinClock.sync(context, isPlaying)

    fun currentAngle(
        options: com.theveloper.pixelplay.data.preferences.TurntableOptions,
        positionMs: Long,
    ): Float = SpinClock.angle(
        com.theveloper.pixelplay.data.preferences.WidgetKind.TURNTABLE,
        options.spin,
        positionMs,
    )

    fun stop() = SpinClock.haltAll()

    fun invalidateRendering() {
        TurntableRenderer.clearCache()
        DiscRenderer.clearCache()
    }
}
