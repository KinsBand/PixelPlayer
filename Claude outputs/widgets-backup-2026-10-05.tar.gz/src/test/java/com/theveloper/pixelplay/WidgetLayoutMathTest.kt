package com.theveloper.pixelplay.ui.glancewidget

import com.theveloper.pixelplay.ui.glancewidget.WidgetLayoutMath.TransportSlot.FAVORITE
import com.theveloper.pixelplay.ui.glancewidget.WidgetLayoutMath.TransportSlot.NEXT
import com.theveloper.pixelplay.ui.glancewidget.WidgetLayoutMath.TransportSlot.PLAY
import com.theveloper.pixelplay.ui.glancewidget.WidgetLayoutMath.TransportSlot.PREVIOUS
import com.theveloper.pixelplay.ui.glancewidget.WidgetLayoutMath.TransportSlot.REPEAT
import com.theveloper.pixelplay.ui.glancewidget.WidgetLayoutMath.TransportSlot.SHUFFLE
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import kotlin.math.abs
import kotlin.math.hypot

/**
 * The pure rules behind the widgets: which controls fit, where things sit, how much tape is
 * on each reel, where the stylus is, and how a record spins up and coasts down.
 *
 * Lives at this shallower path (rather than under ui/glancewidget/) only because deeper test
 * folders could not be reached when it was written; the package is the widgets' own.
 */
class WidgetLayoutMathTest {

    private val m = WidgetLayoutMath

    @Test fun `every switched-on control appears when there is room`() {
        assertEquals(listOf(FAVORITE, SHUFFLE, PREVIOUS, PLAY, NEXT, REPEAT), m.planTransport(true, true, true, true, 6))
    }

    @Test fun `controls drop in a fixed order when space runs out`() {
        assertEquals(listOf(FAVORITE, SHUFFLE, PREVIOUS, PLAY, NEXT), m.planTransport(true, true, true, true, 5))
        assertEquals(listOf(FAVORITE, PREVIOUS, PLAY, NEXT), m.planTransport(true, true, true, true, 4))
        assertEquals(listOf(PREVIOUS, PLAY, NEXT), m.planTransport(true, true, true, true, 3))
        // Previous and next go together: a lone "next" reads as a bug.
        assertEquals(listOf(PLAY), m.planTransport(true, true, true, true, 2))
    }

    @Test fun `play is always kept and switched-off controls never appear`() {
        assertEquals(listOf(PLAY), m.planTransport(false, false, false, false, 0))
        assertEquals(listOf(PLAY, REPEAT), m.planTransport(false, false, true, false, 6))
        assertFalse(m.planTransport(false, true, false, false, 6).contains(PREVIOUS))
    }

    @Test fun `slot counting includes the gaps`() {
        assertEquals(4, m.slotsThatFit(200f, 40f, 6f))
        assertEquals(0, m.slotsThatFit(10f, 40f, 6f))
    }

    @Test fun `tape area is conserved and packs are equal halfway`() {
        for (p in listOf(0f, 0.1f, 0.25f, 0.5f, 0.75f, 0.9f, 1f)) {
            val (supply, takeUp) = m.tapePackRadii(p, 10f, 25f)
            assertEquals(10f * 10f + 25f * 25f, supply * supply + takeUp * takeUp, 0.01f)
        }
        val (a, b) = m.tapePackRadii(0.5f, 10f, 25f)
        assertEquals(a, b, 1e-4f)
        assertEquals(25f to 10f, m.tapePackRadii(0f, 10f, 25f))
        assertEquals(10f to 25f, m.tapePackRadii(1f, 10f, 25f))
    }

    @Test fun `the emptier reel turns faster`() {
        assertTrue(m.reelPeriodSeconds(10f, 5f) < m.reelPeriodSeconds(25f, 5f))
        assertEquals(1, m.nearestBucket(1.6f, listOf(1.3f, 1.7f, 2.1f)))
    }

    @Test fun `stylus walks inwards and the arm tip lands on that groove`() {
        assertTrue(m.stylusRadius(0f) > m.stylusRadius(0.5f))
        assertTrue(m.stylusRadius(0.5f) > m.stylusRadius(1f))
        val place = m.vinylPlacement(0.82f, tonearm = true)
        val cx = place.centreX
        val cy = place.centreY
        val r = place.radius
        val px = cx + m.TONEARM_PIVOT_X * r
        val py = cy + m.TONEARM_PIVOT_Y * r
        val length = m.TONEARM_LENGTH * r
        for (p in listOf(0f, 0.5f, 1f)) {
            val target = m.stylusRadius(p) * r
            val tip = m.tonearmTip(px, py, cx, cy, length, target)
            assertNotNull(tip, "arm must reach progress $p")
            assertEquals(target, hypot(tip!!.first - cx, tip.second - cy), 1e-4f)
            assertEquals(length, hypot(tip.first - px, tip.second - py), 1e-4f)
        }
    }

    @Test fun `with a tonearm the record and arm stay inside the stage`() {
        val place = m.vinylPlacement(1f, tonearm = true)
        assertTrue(place.centreX - place.radius >= 0f)
        assertTrue(place.centreX + m.TONEARM_REACH * place.radius <= 1f)
    }

    @Test fun `spin eases up, never jumps on a speed change, and coasts to a stop`() {
        val motion = SpinMotion()
        motion.retarget(0, 0.048f, SpinMotion.SPIN_UP_MS)
        assertTrue(motion.velocityAt(1_000) > 0.045f)
        val before = motion.angleAt(5_000)
        motion.retarget(5_000, 0.096f, SpinMotion.RETUNE_MS)
        assertEquals(before, motion.angleAt(5_000), 1e-3f)
        motion.retarget(6_000, 0f, SpinMotion.SPIN_DOWN_MS)
        assertTrue(motion.isMoving(6_000))
        assertFalse(motion.isMoving(9_000))
        val parked = motion.angleAt(9_000)
        assertTrue(abs(motion.angleAt(60_000) - parked) < 1e-3f)
    }
}
